# CONTEXTO PJM — Estado de Sesión Persistente

> **INSTRUCCIÓN:** Leer este archivo AL INICIO de cada sesión. Actualizar AL FINAL de cada sesión.

**Última actualización:** 2026-05-05

---

## 1. IDENTIDAD

| Campo | Valor |
|-------|-------|
| Agente | Memory Service Project Manager (PJM) |
| UUID | `0ff63a29-0bc0-465a-b9bd-5f71476bc91d` |
| Email | `pjm@memory-service.vtt.ai` |
| API VTT | `http://77.42.88.106:3000` |
| Proyecto ID | `d0fc276d-e764-4a83-96e9-d65f086ed803` |
| Project Key | MS |
| SERVICE_KEY | `hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d` |

---

## 2. ESTADO DEL PROYECTO

| Fase | Estado |
|------|--------|
| Phase 1 — Project Setup | ✅ Completada |
| Phase 2 — Discovery | 🔵 En curso |
| Phase 3 — Planning | ⏳ Pendiente |
| Phase 4 — Analysis | ⏳ Pendiente |

**Release actual:** Release 2.0 (Memory Service MVP)

---

## 3. SNAPSHOT ANTERIOR

*(consultar VTT al iniciar sesión y comparar contra este snapshot)*

```bash
TOKEN=$(curl -s -X POST "http://77.42.88.106:3000/api/auth/service-token" \
  -H "Content-Type: application/json" \
  -d '{"userId":"0ff63a29-0bc0-465a-b9bd-5f71476bc91d","serviceKey":"hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d"}' \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['data']['token'])")

curl -s "http://77.42.88.106:3000/api/tasks?projectId=d0fc276d-e764-4a83-96e9-d65f086ed803&limit=200" \
  -H "Authorization: Bearer $TOKEN"
```

---

## 4. DOCUMENTOS CLAVE

| # | Documento | Propósito |
|---|-----------|-----------|
| 1 | `.claude/agents/OPERATIVO_PJM_MEMORY_SERVICE.md` | **Central** — identidad, comandos, flujo |
| 2 | `knowledge/PROJECT_MEMORY.md` | Contexto del proyecto |
| 3 | `INDICE_MAESTRO_DOCUMENTOS.md` | Mapa completo de documentos |
| 4 | `memory-service-project/00-agent-setup/03.standard/11_GUIA_AGENTES_MODELO_DINAMICO_V4.md` | API VTT completa |

---

## 5. CÓMO ACTUALIZAR ESTE ARCHIVO

Al terminar sesión actualizar:
- Sección 2: estado de fases si cambió
- Sección 3: snapshot del estado actual (status counts)
- Fecha de última actualización

---

**Mantenido por:** PJM
**Versión:** 1.0 | **Fecha:** 2026-05-05
