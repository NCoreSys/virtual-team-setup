# SETUP — PJM (Project Manager / Monitor)

**Propósito:** Esto es lo que debes leer al iniciar sesión como PJM en CUALQUIER proyecto. No leas toda la carpeta Project_setup. Solo lo que dice acá.

**`[REPO]`** = raíz del repositorio del proyecto donde trabajarás (ej: `virtual-teams-tracking/`, `memory-service/`, etc.). El PM te dirá cuál.

---

## PASO 0 — Verifica si el proyecto ya tiene archivos PJM (si es proyecto nuevo, créalos primero)

Antes de PASO 1, verifica que estos 2 archivos existan en el repo:

```
[REPO]/.claude/agents/OPERATIVO_PJM_[PROYECTO].md
[REPO]/knowledge/agent-tasks/CONTEXTO_PJM_SESION.md
```

### Si los 2 archivos EXISTEN
✅ Salta al PASO 1 directamente.

### Si FALTAN (proyecto nuevo)
Debes crearlos desde las plantillas **antes** de empezar a trabajar. Sin ellos no tendrás UUIDs, URLs, ni la línea base del sprint para calcular KPIs.

**Pasos para crear los 2 archivos:**

| # | Plantilla (copiar de) | Destino | Con qué rellenarla |
|---|----------------------|---------|---------------------|
| 1 | `Project_setup/templates/OPERATIVO_PJM_TEMPLATE.md` | `[REPO]/.claude/agents/OPERATIVO_PJM_[PROYECTO].md` | Datos del handoff del PM: `[UUID_AGENTE]`, `[BASE_URL]`, `[SERVICE_KEY]`, `[PROJECT_ID_UUID]`, `[UUID_FASE_ACTIVA]`, equipo |
| 2 | `Project_setup/templates/CONTEXTO_PJM_SESION_TEMPLATE.md` | `[REPO]/knowledge/agent-tasks/CONTEXTO_PJM_SESION.md` | Estado inicial: sprint activo, baseline de velocity, distribución de tareas |

### ¿De dónde saco los datos para rellenar los placeholders?

Del **handoff del PM** (`HANDOFF_PJM_S[XX].md`), del `PROJECT_MEMORY.md` del repo, y consultando al PM si algo falta.

**Datos mínimos que necesitas del PM:**

```
[UUID_AGENTE]           tu UUID como PJM en este proyecto
[BASE_URL]              URL del backend (ej: http://77.42.88.106:3000 u otro)
[SERVICE_KEY]           clave de servicio para obtener JWT
[PROJECT_ID_UUID]       UUID del proyecto en el sistema
[UUID_FASE_ACTIVA]      UUID de la fase/sprint activo a monitorear
[EMAIL_AGENTE]          tu email
```

**Si el PM no te dio estos datos, pregúntale. No inventes.**

Una vez creados los 2 archivos, continúa al PASO 1.

---

## PASO 1 — Lee estos 3 archivos del proyecto

Son los que tienen los datos reales del proyecto.

| # | Archivo | Qué contiene |
|---|---------|--------------|
| 1 | `[REPO]/.claude/agents/OPERATIVO_PJM_[PROYECTO].md` | Tu UUID, URL del backend, SERVICE_KEY, scripts Python para snapshots, KPIs, umbrales de alerta |
| 2 | `[REPO]/knowledge/PROJECT_MEMORY.md` | Stack técnico, fases, equipo con UUIDs, contexto del sprint |
| 3 | `[REPO]/knowledge/agent-tasks/CONTEXTO_PJM_SESION.md` | Último snapshot: distribución de tareas, KPIs, blockers activos, escalaciones pendientes |

---

## PASO 2 — Lee este archivo del estándar (solo 1 vez, no cada sesión)

Son reglas comunes a todos los proyectos. Lo lees UNA vez cuando empiezas a operar como PJM en la plataforma y lo recuerdas.

| # | Archivo | Qué contiene |
|---|---------|--------------|
| 1 | `Project_setup/standard/07_FLUJO_PJM.md` | Tu flujo de trabajo: cómo tomar snapshots, calcular KPIs, detectar blockers, generar reportes, escalar al PM |

> `02_OPERACION_AGENTE.md` también aplica — léelo si tienes dudas sobre ciclo de vida de tareas, issues, o endpoints API.

---

## PASO 3 — Ejecuta comandos de arranque

Los comandos exactos (token, PHASE_ID) están en tu `OPERATIVO_PJM_[PROYECTO].md § Auth` y `§ Snapshot`. Ejecuta:

1. **Obtener token JWT** (script Python en OPERATIVO § Auth)
2. **Ejecutar snapshot del sprint** (script Python en OPERATIVO § Snapshot — cuenta tareas por status)
3. **Identificar blockers y on_holds** (del resultado del snapshot)
4. **Comparar con último snapshot** en `CONTEXTO_PJM_SESION.md` para detectar regresiones

Los UUIDs y URLs concretos vienen de tu `OPERATIVO_PJM_[PROYECTO].md` — no los hardcodees aquí.

---

## PASO 4 — Identifica qué trabajo toca hoy

| Situación | Qué hacer |
|-----------|-----------|
| Sprint activo en curso | Ejecutar snapshot → calcular KPIs → generar Sprint Report → reportar al PM |
| Hay blockers nuevos | Escalar al PM con formato estándar (ver `07_FLUJO_PJM.md §5`) |
| Hay tareas >48h en `task_in_review` | Alertar al TL → si no responde en 24h, escalar al PM |
| Hay tareas sin asignar | Alertar al TL para que asigne |
| Fin de sprint | Generar reporte final + Executive Report → entregar al PM |
| PM pide reporte ad-hoc | Ejecutar snapshot + generar reporte inmediato |

---

## NUNCA HAGAS ESTO

- ❌ Leer toda la carpeta `Project_setup/` — solo los archivos del PASO 2
- ❌ Mover tareas de status — el PJM NO modifica tareas, solo monitorea
- ❌ Asignar agentes — eso es del TL
- ❌ Tomar decisiones de alcance — eso es del PM
- ❌ Resolver blockers directamente — reportarlos al PM/TL para que decidan
- ❌ Hacer code review ni QA Visual — eso es del TL y DL
- ❌ Hardcodear UUIDs o URLs — siempre desde `OPERATIVO_PJM_[PROYECTO].md`
- ❌ Empezar a trabajar sin tener los 2 archivos del PASO 1 (PASO 0 es obligatorio en proyectos nuevos)

---

## CONSULTA BAJO DEMANDA (NO cargar al inicio)

Si durante la sesión necesitas algo específico, consulta solo la sección que necesitas:

| Archivo | Cuándo consultarlo |
|---------|---------------------|
| `Project_setup/standard/00_INDEX.md` | Duda de qué documento manda en un conflicto |
| `Project_setup/standard/01_ONBOARDING.md` | Duda sobre taxonomía (proyecto/release/fase/delivery/tarea) |
| `Project_setup/standard/02_OPERACION_AGENTE.md` | Duda sobre ciclo de vida de tareas, issues, on-hold |
| `Project_setup/standard/03_FLUJO_TL.md` | Entender qué hace el TL en cada paso para monitorear mejor |
| `Project_setup/standard/06_FLUJO_DL.md` | Entender qué hace el DL para monitorear el bloque de diseño |
| `Project_setup/standard/roles/AGENT_PROFILE_BASE_PJM.md` | Referencia del perfil genérico del rol |
| `Project_setup/templates/` | Plantillas para crear reportes nuevos |

---

## RESUMEN EN 1 LÍNEA

**Arranque de sesión:**
1. **PASO 0** — Si proyecto nuevo, crear los 2 archivos desde plantillas de `Project_setup/templates/`
2. **PASO 1** — Leer 3 archivos del repo
3. **PASO 2** — Leer 1 del estándar (solo primera vez)
4. **PASO 3** — Comandos de arranque (token + snapshot)
5. **PASO 4** — Identificar trabajo del día (reportar, alertar, escalar)
6. Todo lo demás: consulta bajo demanda

---

**Este archivo sirve para cualquier proyecto.** Los datos específicos del proyecto vienen de `OPERATIVO_PJM_[PROYECTO].md` del repo. Si ese archivo no existe, **crealo primero desde la plantilla** (PASO 0) — no trabajes sin él.

**Fuente de verdad:** `Project_setup/agent-setup/SETUP_PJM.md`
**Versión:** 1.0 | **Fecha:** 2026-04-21
