# CLOSURE: Sprint S7 — Deploy Staging

**Documento:** CLOSURE_S7.md
**Versión:** 1.0
**Sprint:** S7 — Deploy Staging

---

## 0. FIRMAS

**2 firmas** (TL + AR). Sin FE → sin DL.

---

## 1. VERIFICACIÓN DE DELIVERABLES

### DO — DEL_DO_S7

| # | Criterio | Estado |
|---|----------|--------|
| DO-01 | Servidor Hetzner provisionado y accesible | ⬜ |
| DO-02 | Firewall: solo puertos 80/443/22 expuestos | ⬜ |
| DO-03 | shared-postgres + memory_service_db en staging | ⬜ |
| DO-04 | SSL certificate activo | ⬜ |
| DO-05 | CI Pipeline: push → lint → test → build → push Docker | ⬜ |
| DO-06 | CD Pipeline: deploy automático a staging | ⬜ |
| DO-07 | Staging live en 77.42.88.106 | ⬜ |
| DO-08 | GET /api/health OK en staging | ⬜ |

### DB — DEL_DB_S7

| # | Criterio | Estado |
|---|----------|--------|
| DB-01 | prisma migrate deploy ejecutado en staging | ⬜ |
| DB-02 | 29 tablas verificadas en staging | ⬜ |

### QA — DEL_QA_S7

| # | Criterio | Estado |
|---|----------|--------|
| QA-01 | Smoke: POST /import OK en staging | ⬜ |
| QA-02 | Smoke: GET /context OK en staging | ⬜ |
| QA-03 | Smoke: GET /conversations OK en staging | ⬜ |
| QA-04 | Smoke test sign-off (6.4.3) | ⬜ |

---

## 2. FIRMA TL

```python
body = {"userId": TL, "role": "tech_lead",
    "comment": "S7 completado. Staging live. CI/CD activo. Smoke tests OK."}
req = urllib.request.Request(
    f'{BASE_URL}/api/sprints/{SPRINT_S7_ID}/stages/development/sign',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
urllib.request.urlopen(req)
```

**Firma TL:** ⬜ ___________________ — Fecha: ___________

---

## 3. FIRMA AR

```python
body = {"userId": AR, "role": "architect",
    "comment": "Integration Audit S7 completado. Infra alineada con 3B.8.1. CI/CD funcional."}
req = urllib.request.Request(
    f'{BASE_URL}/api/sprints/{SPRINT_S7_ID}/stages/integration/sign',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
urllib.request.urlopen(req)
```

**Firma AR:** ⬜ ___________________ — Fecha: ___________

---

## 4. MILESTONE M6

| # | Criterio | Estado |
|---|----------|--------|
| M6-01 | Staging live en 77.42.88.106 | ⬜ |
| M6-02 | Smoke tests OK | ⬜ |
| M6-03 | CI/CD activo | ⬜ |

---

## 5. GATE PM

```
[ ] TL firmó §2
[ ] AR firmó §3
[ ] M6 verificado §4
[ ] Staging accesible
[ ] Smoke tests pass
[ ] CIERRE-S7 en task_completed
```

```python
body = {"statusId": "aa5ceb90-5209-42a2-b874-a8cbee597a97"}
req = urllib.request.Request(f'{BASE_URL}/api/tasks/{APR_S7}/status',
    data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
urllib.request.urlopen(req)
print("APR-S7 → task_completed. Sprint S7 CERRADO ✅")
```

---

## 6. FIRMAS DE CIERRE

| Rol | Firma | Fecha |
|-----|-------|-------|
| **TL** | ⬜ | ___________ |
| **AR** | ⬜ | ___________ |
| **PM** | ⬜ (APR-S7) | ___________ |

---

**FIN DEL CLOSURE S7**
