# HANDOFF TL: Memory Service — Sprint S1

**Documento:** HANDOFF_TL_S1.md
**Versión:** 2.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-19
**Sprint:** S1 — Infra & BD Foundation
**Estado:** 📋 READY
**Prerrequisitos:** Phase 3B completada (MS-047 ✅)

> **Nota:** S1 no requiere HANDOFF_DL, HANDOFF_FE ni HANDOFF_QA. Solo TL coordina DO, BE, DB. Firmas de cierre: 2 (TL + AR).

---

## 0. RESUMEN EJECUTIVO

Sprint S1 establece la foundation completa del proyecto:

- **DO (19h):** Docker Compose con API:3002, UI:3003, PostgreSQL, Redis. Setup guide, env vars, Makefile
- **TL (10h):** IDE, linter (ESLint), formatter (Prettier), pre-commit hooks, Git config
- **BE (13h):** Error handling (AppError + jerarquía MEM-ERR-xxx) y logging (Winston + correlationId)
- **DB (19h):** Migración inicial 29 entidades, schema migrations workflow, constraints únicos

Sin este sprint, nada más puede implementarse. Es el nodo raíz de todo el desarrollo.

**Duración total:** ~69h
**Milestone M1:** Containers UP, BD migrada, AppError compilando

---

## 1. DECISIONES CERRADAS QUE APLICAN EN S1

| # | Decisión | Aplica en | Fuente |
|---|----------|-----------|--------|
| D-MEM-04 | Constraints únicos Turn/Block | 4.2.6 | HO PM §4 |
| D-MEM-08 | Error codes MEM-ERR-xxx jerarquía | 4.3.14 | HO PM §4 |
| D-MEM-10 | Prisma schema fuente de verdad, IDs TEXT | 4.2.1, 4.2.2, 4.2.6 | HO PM §4 |
| D-MEM-36 | Infraestructura Hetzner single-node | 4.1.1, 4.1.4, 4.1.5 | HO PM §4 |
| D-MEM-37 | Puertos: API 3002, UI 3003, PG 5432, Redis 6379 | 4.1.1, 4.1.3 | HO PM §4 |
| D-MEM-38 | Logging: structured JSON + correlationId | 4.3.15, 4.1.3 | HO PM §4 |
| D-MEM-39 | Docker Compose standalone | 4.1.4 | HO PM §4 |
| D-MEM-40 | Error handling: AppError class | 4.3.14 | HO PM §4 |
| D-MEM-41 | Coding standards TypeScript strict | 4.1.6..4.1.10 | HO PM §4 |
| D-MEM-42 | @@unique constraints compuestos | 4.2.6 | HO PM §4 |

---

## 2. BRIEFS POR TAREA — CON RUTEO A DOCUMENTACIÓN FUENTE

### 2.1 DevOps Engineer — 19h

#### 4.1.1 Development Environment (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Containers, networking, volumes para desarrollo local |
| **Spec Source** | `3B.8.1_infra_plan.md` §stack, §puertos, §servicios |
| **Decisiones** | D-MEM-36 (Hetzner single-node), D-MEM-37 (puertos) |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.3_server_specs.md`, `3B.8.5_env_matrix.md` |
| **Depende de** | SETUP-S1 |

#### 4.1.2 Environment Setup Guide (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | README de cómo levantar el proyecto desde cero |
| **Spec Source** | `3B.8.1_infra_plan.md` + `3B.8.5_env_matrix.md` §setup inicial |
| **Decisiones** | D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.5`, deliverable `4.1.1` |
| **Depende de** | 4.1.1 |

#### 4.1.3 Environment Variables (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | .env.example con todas las variables del proyecto |
| **Spec Source** | `3B.8.5_env_matrix.md` completo |
| **Decisiones** | D-MEM-37 (puertos), D-MEM-38 (logging vars) |
| **Docs que el agente debe leer** | `3B.8.5`, `3B.8.8` |
| **Depende de** | SETUP-S1 |

#### 4.1.4 Docker Compose (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | docker-compose.yml con API, UI, PostgreSQL, Redis |
| **Spec Source** | `3B.8.1_infra_plan.md` §docker, §servicios compartidos |
| **Decisiones** | D-MEM-36, D-MEM-39 (standalone) |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.3`, `3B.8.4_network_config.md` |
| **Depende de** | SETUP-S1 |

#### 4.1.5 Makefile/Scripts (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | make up, make down, make migrate, make seed |
| **Spec Source** | `3B.8.1_infra_plan.md` §automatización |
| **Decisiones** | D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.1`, deliverable `4.1.4` |
| **Depende de** | 4.1.4 |

---

### 2.2 TL (Dev Tooling) — 10h

#### 4.1.6 IDE Configuration (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | .vscode/settings.json + extensions.json |
| **Spec Source** | `3B.2.2_coding_standards.md` §editor, §formatter |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.1_folder_structure.md`, `3B.2.2` |
| **Depende de** | SETUP-S1 |

#### 4.1.8 Git Configuration (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | .gitignore, branch naming, commit format |
| **Spec Source** | `3B.2.2_coding_standards.md` §git-flow, §branching |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.2`, `3B.2.5_naming_conventions.md` |
| **Depende de** | SETUP-S1 |

#### 4.1.9 Linter Configuration (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | ESLint config para TypeScript strict |
| **Spec Source** | `3B.2.2_coding_standards.md` §eslint, §typescript |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.1`, `3B.2.2` |
| **Depende de** | SETUP-S1 |

#### 4.1.10 Formatter Configuration (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Prettier config |
| **Spec Source** | `3B.2.2_coding_standards.md` §prettier |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.1`, `3B.2.2` |
| **Depende de** | SETUP-S1 |

#### 4.1.7 Pre-commit Hooks (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | husky + lint-staged (lint + format on commit) |
| **Spec Source** | `3B.2.2_coding_standards.md` §pre-commit, §linting |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.2`, deliverables `4.1.9`, `4.1.10` |
| **Depende de** | 4.1.9, 4.1.10 |

---

### 2.3 Backend Engineer — 13h

#### 4.3.14 Error Handling — AppError + MEM-ERR-xxx (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | AppError class + jerarquía de error codes MEM-ERR-xxx + errorHandler middleware |
| **Spec Source** | `3B.4.5_error_codes.md` + `3B.2.6_error_handling_strategy.md` completo |
| **Decisiones** | D-MEM-08 (error codes), D-MEM-40 (AppError class) |
| **Docs que el agente debe leer** | `3B.4.5`, `3B.2.6`, `3B.7.4` |
| **Depende de** | SETUP-S1 |

#### 4.3.15 Logging — Winston + correlationId (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Winston logger con structured JSON, correlationId, niveles |
| **Spec Source** | `3B.2.2_coding_standards.md` + `3B.7.10_security_logging.md` §Winston + correlationId |
| **Decisiones** | D-MEM-41, D-MEM-38 (structured logging) |
| **Docs que el agente debe leer** | `3B.2.2`, `3B.7.10`, `3B.8.11_monitoring_strategy.md` |
| **Depende de** | SETUP-S1 |

---

### 2.4 Database Engineer — 19h

#### 4.2.1 Initial Migration — 29 entidades (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Migración Prisma con las 29 entidades del ERD |
| **Spec Source** | `3B.3.2_schema_prisma.md` completo |
| **Decisiones** | D-MEM-10 (Prisma fuente de verdad, IDs TEXT), D-MEM-41, D-MEM-42 |
| **Docs que el agente debe leer** | `3B.3.1_erd.md`, `3B.3.2`, `3B.3.5` |
| **Depende de** | 4.1.4 Docker Compose (necesita PostgreSQL container) |

#### 4.2.2 Schema Migrations Setup (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Workflow de prisma migrate dev, naming conventions, rollback |
| **Spec Source** | `3B.3.6_migration_strategy.md` completo |
| **Decisiones** | D-MEM-10, D-MEM-41 |
| **Docs que el agente debe leer** | `3B.3.6`, `3B.3.2`, deliverable `4.2.1` |
| **Depende de** | 4.2.1 |

#### 4.2.6 Constraints — unique en Turn/Block (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | @@unique constraints en ConversationTurn y TurnBlock |
| **Spec Source** | `3B.3.2_schema_prisma.md` + `3B.3.3_table_specs.md` §unique constraints |
| **Decisiones** | D-MEM-10, D-MEM-04 (constraints Turn/Block) |
| **Docs que el agente debe leer** | `3B.3.2`, `3B.3.3` |
| **Depende de** | 4.2.1 |

---

## 3. TAREAS DEL SPRINT

| ID | Tarea | Agente | Horas | Complejidad | Spec Source |
|----|-------|--------|:-----:|:-----------:|-------------|
| 4.1.1 | Development Environment | DO | 5 | MEDIUM | `3B.8.1` §stack,§puertos |
| 4.1.2 | Environment Setup Guide | DO | 3 | LOW | `3B.8.1` + `3B.8.5` |
| 4.1.3 | Environment Variables | DO | 3 | LOW | `3B.8.5` completo |
| 4.1.4 | Docker Compose | DO | 5 | MEDIUM | `3B.8.1` §docker |
| 4.1.5 | Makefile/Scripts | DO | 3 | LOW | `3B.8.1` §automatización |
| 4.1.6 | IDE Configuration | TL | 2 | LOW | `3B.2.2` §editor |
| 4.1.7 | Pre-commit Hooks | TL | 2 | LOW | `3B.2.2` §pre-commit |
| 4.1.8 | Git Configuration | TL | 2 | LOW | `3B.2.2` §git-flow |
| 4.1.9 | Linter Configuration | TL | 2 | LOW | `3B.2.2` §eslint |
| 4.1.10 | Formatter Configuration | TL | 2 | LOW | `3B.2.2` §prettier |
| 4.3.14 | Error Handling | BE | 8 | HIGH | `3B.4.5` + `3B.2.6` |
| 4.3.15 | Logging | BE | 5 | MEDIUM | `3B.2.2` + `3B.7.10` |
| 4.2.1 | Initial Migration | DB | 8 | HIGH | `3B.3.2` completo |
| 4.2.2 | Schema Migrations | DB | 8 | HIGH | `3B.3.6` completo |
| 4.2.6 | Constraints | DB | 3 | LOW | `3B.3.2` + `3B.3.3` |
| TL-S1 | Code Review | TL | 3 | MEDIUM | — |
| AR-S1 | Integration Audit | AR | 2 | MEDIUM | — |
| CIERRE-S1 | Cierre Sprint S1 | TL | 2 | MEDIUM | — |
| APR-S1 | Aprobación PM | PM | 1 | LOW | — |

---

## 4. DEPENDENCIAS ENTRE TAREAS

| Tarea | Depende de | Tipo |
|-------|-----------|------|
| 4.1.1 | SETUP-S1 | FS |
| 4.1.2 | 4.1.1 | FS |
| 4.1.3 | SETUP-S1 | FS |
| 4.1.4 | SETUP-S1 | FS |
| 4.1.5 | 4.1.4 | FS |
| 4.1.6 | SETUP-S1 | FS |
| 4.1.7 | 4.1.9, 4.1.10 | FS |
| 4.1.8 | SETUP-S1 | FS |
| 4.1.9 | SETUP-S1 | FS |
| 4.1.10 | SETUP-S1 | FS |
| 4.3.14 | SETUP-S1 | FS |
| 4.3.15 | SETUP-S1 | FS |
| 4.2.1 | 4.1.4 | FS |
| 4.2.2 | 4.2.1 | FS |
| 4.2.6 | 4.2.1 | FS |
| TL-S1 | 4.1.5, 4.1.7, 4.3.14, 4.3.15, 4.2.2, 4.2.6 | FS |
| AR-S1 | TL-S1 | FS |
| CIERRE-S1 | AR-S1 | FS |
| APR-S1 | CIERRE-S1 | FS |

---

## 5. VTT PLANNING DATA

| Tarea | estimatedHours | complexity | category | deliveryId | dependsOn |
|-------|:--------------:|:----------:|:--------:|:----------:|-----------|
| 4.1.1 | 5 | MEDIUM | deployment | DEL_DO | SETUP-S1 |
| 4.1.2 | 3 | LOW | deployment | DEL_DO | 4.1.1 |
| 4.1.3 | 3 | LOW | deployment | DEL_DO | SETUP-S1 |
| 4.1.4 | 5 | MEDIUM | deployment | DEL_DO | SETUP-S1 |
| 4.1.5 | 3 | LOW | deployment | DEL_DO | 4.1.4 |
| 4.1.6 | 2 | LOW | documentation | DEL_TL | SETUP-S1 |
| 4.1.7 | 2 | LOW | documentation | DEL_TL | 4.1.9, 4.1.10 |
| 4.1.8 | 2 | LOW | documentation | DEL_TL | SETUP-S1 |
| 4.1.9 | 2 | LOW | documentation | DEL_TL | SETUP-S1 |
| 4.1.10 | 2 | LOW | documentation | DEL_TL | SETUP-S1 |
| 4.3.14 | 8 | HIGH | development | DEL_BE | SETUP-S1 |
| 4.3.15 | 5 | MEDIUM | development | DEL_BE | SETUP-S1 |
| 4.2.1 | 8 | HIGH | development | DEL_DB | 4.1.4 |
| 4.2.2 | 8 | HIGH | development | DEL_DB | 4.2.1 |
| 4.2.6 | 3 | LOW | development | DEL_DB | 4.2.1 |
| TL-S1 | 3 | MEDIUM | review | DEL_REV | all deliverables |
| AR-S1 | 2 | MEDIUM | review | DEL_REV | TL-S1 |
| CIERRE-S1 | 2 | MEDIUM | review | DEL_REV | AR-S1 |
| APR-S1 | 1 | LOW | review | DEL_REV | CIERRE-S1 |

**Total S1:** 69h

---

## 6. DoD — TL

### Gate M1 verificado:
- [ ] Docker containers UP (verificar contra `3B.8.1` §servicios)
- [ ] BD migrada — 29 tablas (verificar contra `3B.3.2`)
- [ ] Constraints activos — @@unique (verificar contra `3B.3.3`)
- [ ] AppError compilando (verificar contra `3B.4.5` + `3B.2.6`)
- [ ] **NUNCA** mover tarea a `task_approved`

---

## 7. REFERENCIAS

| Documento | Propósito |
|-----------|-----------|
| `3B.9.10_routing_index.md` | Índice de ruteo deliverable → spec source |
| `3B.8.1_infra_plan.md` | Arquitectura infra (DO) |
| `3B.2.2_coding_standards.md` | Standards y tooling (TL) |
| `3B.4.5_error_codes.md` | Error codes (BE) |
| `3B.3.2_schema_prisma.md` | Schema Prisma (DB) |

---

## 8. HISTORIAL DE VERSIONES

| Versión | Fecha | Cambios |
|---------|-------|---------|
| 1.0 | 2026-05-12 | Versión inicial |
| 2.0 | 2026-05-19 | Cada tarea con tabla de ruteo desde 3B.9.10. Sin contenido inventado. |

---

**FIN DEL HANDOFF TL S1**
