# HANDOFF TL: Memory Service — Sprint S2

**Documento:** HANDOFF_TL_S2.md
**Versión:** 2.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-19
**Sprint:** S2 — Core Backend
**Estado:** 📋 READY
**Prerrequisitos:** Sprint S1 completado (APR-S1 ✅)

> **Nota:** S2 no requiere HANDOFF_DL, HANDOFF_FE ni HANDOFF_QA. Solo TL coordina BE y DB. Firmas de cierre: 2 (TL + AR).

---

## 0. RESUMEN EJECUTIVO

Sprint S2 construye la capa de backend completa sobre la foundation de S1. Al completarlo, el sistema tiene toda la lógica de negocio implementada — solo faltan los endpoints HTTP (S3).

**Tracks paralelos:**

- **DB (29h):** Seed de 10 catálogos, test data, indexes (partial + GIN + composite), migration guide, rollback scripts
- **BE (42h):** Middlewares (Auth + Validation + RateLimit + ErrorHandler), Models (Prisma singleton + catalogCache), DTOs/Schemas Zod, ConversationRepository (6 queries), 5 Services (Import, ContextQuery, Classifier, CostCalculator, Storage), Utils

**Deliverable más crítico:** 4.3.2 Services (13h, VERY HIGH) — converge todo lo de S2. Si falla, S3 no arranca.

**Duración total:** ~81h
**Milestone M2:** Auth MW activo (X-Service-Key), catalogCache cargado, Zod schemas OK, ConversationRepository testeado

---

## 1. ARQUITECTURA DEL SPRINT

```
DB (29h) → DEL_DB_S2               BE (42h) → DEL_BE_S2
┌─────────────────────┐             ┌──────────────────────────────┐
│ 4.2.3 Seed (8h)     │────┐        │ 4.3.7 Middlewares (8h)      │──┐
│ 4.2.4 Test Data (5h)│    │        │ 4.3.5 DTOs/Schemas (5h)     │  │
│ 4.2.5 Indexes (8h)  │    ├───────▶│ 4.3.3 Models (5h)           │  │
│ 4.2.9 Mig Guide (3h)│    │        │ 4.3.4 Repositories (8h)     │  ├──▶
│ 4.2.10 Rollback (5h)│    │        │ 4.3.2 Services (13h) ◄──────┘  │
└─────────────────────┘    │        │ 4.3.8 Utils (3h)               │
                           │        └──────────────────────────────┘
                           └──▶ 4.3.2 depende de 4.2.3 (catalogCache)
```

---

## 2. DECISIONES CERRADAS QUE APLICAN EN S2

| # | Decisión | Aplica en | Fuente |
|---|----------|-----------|--------|
| D-MEM-03 | Orquestación ImportService (5 capas + compensación) | 4.3.2 | HO PM §4 |
| D-MEM-05 | Idempotencia (sourceId + externalSessionId) → ALREADY_INDEXED | 4.3.2, 4.3.5 | HO PM §4 |
| D-MEM-06 | SLA GET /context <500ms (Promise.race + MEM-ERR-504) | 4.3.2 | HO PM §4 |
| D-MEM-07 | API contracts — 11 endpoints | 4.3.5 | HO PM §4 |
| D-MEM-09 | Auth R1 = X-Service-Key (header), JWT en R2 | 4.3.7 | HO PM §4 |
| D-MEM-10 | Prisma schema como fuente de verdad, IDs TEXT | 4.3.3, 4.3.4, 4.2.5 | HO PM §4 |
| D-MEM-11 | Cleanup job cron 5min, retry ≤3 | 4.3.2 (prep S3) | HO PM §4 |
| D-MEM-14 | 5 sources: CLAUDE_SDK/CLI/WEB, CHATGPT, VTT_CHANNEL | 4.2.3 | HO PM §4 |
| D-MEM-17/18 | Prisma client singleton + catalogCache Maps en startup | 4.3.3 | HO PM §4 |
| D-MEM-20 | Catálogos dinámicos en BD, extensibles con INSERT | 4.2.3, 4.3.3 | HO PM §4 |
| D-MEM-26/27/28 | Auth middleware + validation + rate limiting specs | 4.3.7 | HO PM §4 |
| D-MEM-30/31 | Partial indexes + composite para context query | 4.2.5 | HO PM §4 |
| D-MEM-41 | Coding standards y toolchain TypeScript strict | 4.3.8 | HO PM §4 |

---

## 3. BRIEFS POR TAREA — CON RUTEO A DOCUMENTACIÓN FUENTE

### 3.1 DB Engineer — 29h

#### 4.2.3 Seed Data — 10 catálogos (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Script de seed que inserta datos iniciales de los 10 catálogos en orden FK correcto |
| **Spec Source** | `3B.3.7_seed_plan.md` §catálogos — 10 tablas |
| **Decisiones** | D-MEM-14 (5 sources), D-MEM-20 (catálogos dinámicos), D-MEM-16 |
| **Docs que el agente debe leer** | `3B.3.7`, `3B.3.2_schema_prisma.md`, `3B.3.5` |
| **Depende de** | 4.2.1 Initial Migration (S1 ✅) |

#### 4.2.4 Test Data (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Script de test data con conversaciones de prueba representativas para desarrollo local |
| **Spec Source** | `3B.3.7_seed_plan.md` §datos de prueba |
| **Decisiones** | D-MEM-14 |
| **Docs que el agente debe leer** | `3B.3.7`, deliverable `4.2.3` (catálogos deben existir) |
| **Depende de** | 4.2.3 Seed Data |

#### 4.2.5 Indexes — partial + GIN + composite (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Archivo SQL manual con indexes que Prisma no puede generar desde el schema |
| **Spec Source** | `3B.3.4_index_strategy.md` completo — partial + GIN |
| **Decisiones** | D-MEM-30 (partial indexes cleanup), D-MEM-31 (composite context query) |
| **Docs que el agente debe leer** | `3B.3.4`, `3B.3.2_schema_prisma.md`, `3B.3.8_query_patterns.md` |
| **Depende de** | 4.2.1 Initial Migration (S1 ✅) |
| **Nota** | D-MEM-43: SQL manual fuera de Prisma schema (migrations/manual/partial_indexes.sql) |

#### 4.2.9 Migration Guide (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Documento con workflow completo de migraciones Prisma + partial indexes |
| **Spec Source** | `3B.3.6_migration_strategy.md` §guía operativa |
| **Decisiones** | D-MEM-10 |
| **Docs que el agente debe leer** | `3B.3.6` |
| **Depende de** | SETUP-S2 |

#### 4.2.10 Rollback Scripts (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Scripts de rollback para cada migración + procedimiento documentado |
| **Spec Source** | `3B.3.6_migration_strategy.md` §rollback |
| **Decisiones** | D-MEM-10 |
| **Docs que el agente debe leer** | `3B.3.6`, deliverable `4.2.2` (S1) |
| **Depende de** | SETUP-S2 |

---

### 3.2 Backend Engineer — 42h

#### 4.3.7 Middlewares — Auth + Validation + RateLimit + ErrorHandler (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | 4 middlewares Express: auth (X-Service-Key), validation (Zod factory), rateLimit (Redis), errorHandler (AppError → JSON) |
| **Spec Source** | `3B.4.6_auth_spec.md` + `3B.4.7_authz_spec.md` + `3B.4.8_rate_limiting.md` + `3B.2.6_error_handling_strategy.md` |
| **Decisiones** | D-MEM-09 (X-Service-Key R1), D-MEM-26, D-MEM-27, D-MEM-28 |
| **Docs que el agente debe leer** | `3B.4.6`, `3B.4.7`, `3B.4.8`, `3B.7.2`, `3B.7.9_input_validation.md`, `3B.2.6` |
| **Depende de** | 4.3.14 Error Handling (S1 ✅) — errorHandler usa AppError |
| **Nota** | Rate limiting con fallback: si Redis down → skip + log warning (no bloquear requests) |

#### 4.3.5 DTOs/Schemas — Zod (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Schemas Zod para request/response de los 11 endpoints |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.4.3_request_response_examples.md` |
| **Decisiones** | D-MEM-05 (idempotencia), D-MEM-07 (API contracts) |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.4.3`, `3B.7.9_input_validation.md` |
| **Depende de** | SETUP-S2 |

#### 4.3.3 Models — Prisma client singleton + catalogCache (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Prisma client singleton (connect/disconnect) + cache de 10 catálogos en Maps al startup |
| **Spec Source** | `3B.3.2_schema_prisma.md` completo |
| **Decisiones** | D-MEM-10 (Prisma fuente de verdad), D-MEM-17/18 (singleton + cache startup) |
| **Docs que el agente debe leer** | `3B.3.2`, `3B.3.3_table_specs.md`, `3B.3.5` |
| **Depende de** | 4.2.1 Initial Migration (S1 ✅) |
| **Nota** | Fail-fast: si catálogos no cargan → process.exit(1). Maps sin TTL en R1 |

#### 4.3.4 Repositories — ConversationRepository (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Repository con 6 queries especializadas usando Prisma client singleton |
| **Spec Source** | `3B.3.1_erd.md` + `3B.3.8_query_patterns.md` §ConversationRepository + 6 queries |
| **Decisiones** | D-MEM-10 (Prisma), D-MEM-30 (indexes para queries) |
| **Docs que el agente debe leer** | `3B.3.1`, `3B.3.8`, `3B.3.4_index_strategy.md`, `3B.2.3_design_patterns.md` |
| **Depende de** | 4.3.3 Models |
| **Nota** | Las 6 queries están definidas en 3B.3.8. No N+1. Cursor-based pagination (no offset) |

#### 4.3.2 Services — 5 services completos (13h, VERY HIGH → HIGH en API)

| Campo | Valor |
|-------|-------|
| **Qué producir** | 5 services: ImportService, ContextQueryService, ClassifierService, CostCalculatorService, StorageService |
| **Spec Source** | `3B.1.4` (architecture) §5 services + `3B.5.3_business_flows.md` |
| **Decisiones** | D-MEM-03 (orquestación import), D-MEM-06 (SLA <500ms), D-MEM-07 (contracts), D-MEM-11 (cleanup prep) |
| **Docs que el agente debe leer** | `3B.5.3`, `3B.5.5_integration_flows.md`, `3B.4.2`, `3B.3.8`, `ADDENDUM` |
| **Depende de** | 4.2.3 (catalogCache), 4.3.4 (repositories), 4.3.5 (DTOs), 4.3.7 (middlewares) |
| **Nota** | Convergencia de todo S2. Los 5 services y sus flujos están detallados en 3B.5.3 |

#### 4.3.8 Utils — path sanitization + correlationId (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Utilidades compartidas: sanitización de paths para storage, generación de correlationId |
| **Spec Source** | `3B.2.2_coding_standards.md` + `3B.7.9_input_validation.md` |
| **Decisiones** | D-MEM-41 (coding standards), D-MEM-26 |
| **Docs que el agente debe leer** | `3B.2.2`, `3B.7.9`, `3B.2.5_naming_conventions.md` |
| **Depende de** | SETUP-S2 |

---

## 4. VARIABLES DE ENTORNO

Sin variables nuevas respecto a S1. Relevancia por deliverable:

| Variable | Usado por |
|----------|-----------|
| SERVICE_KEY | 4.3.7 Auth middleware |
| REDIS_URL + REDIS_PREFIX | 4.3.7 RateLimit middleware |
| DATABASE_URL | 4.3.3 Prisma client singleton |
| STORAGE_PATH | 4.3.2 StorageService (via 4.3.8 pathSanitizer) |

---

## 5. RIESGOS Y MITIGACIONES

| Riesgo | Prob. | Impacto | Deliverable | Mitigación |
|--------|:-----:|:-------:|:-----------:|------------|
| R-05: P2002 concurrente en import | 0.30 | MEDIUM | 4.3.2 | Ver 3B.5.3 §import-flow — retry + ALREADY_INDEXED |
| R-06: Partial indexes no cubren queries | 0.25 | HIGH | 4.2.5 | Ver 3B.3.4 — verificar con EXPLAIN ANALYZE |
| R-07: TS strict rework en Prisma types | 0.35 | MEDIUM | 4.3.3, 4.3.4 | Ejecutar prisma generate y leer types ANTES |
| R-09: Redis no disponible | 0.15 | LOW | 4.3.7 | Ver 3B.4.8 — fallback: skip rate limit + log warning |
| R-13: Seed FK order incorrecto | 0.25 | LOW | 4.2.3 | Ver 3B.3.7 — orden documentado |

---

## 6. TAREAS DEL SPRINT

| ID | Tarea | Agente | Horas | Complejidad | Spec Source |
|----|-------|--------|:-----:|:-----------:|-------------|
| 4.2.3 | Seed Data — 10 catálogos | DB | 8 | HIGH | 3B.3.7 §catálogos |
| 4.2.4 | Test Data | DB | 5 | MEDIUM | 3B.3.7 §datos de prueba |
| 4.2.5 | Indexes — partial + GIN + composite | DB | 8 | HIGH | 3B.3.4 completo |
| 4.2.9 | Migration Guide | DB | 3 | LOW | 3B.3.6 §guía operativa |
| 4.2.10 | Rollback Scripts | DB | 5 | MEDIUM | 3B.3.6 §rollback |
| 4.3.7 | Middlewares | BE | 8 | HIGH | 3B.4.6 + 3B.4.7 + 3B.4.8 + 3B.2.6 |
| 4.3.5 | DTOs/Schemas — Zod | BE | 5 | MEDIUM | 3B.4.2 + 3B.4.3 |
| 4.3.3 | Models — Prisma + catalogCache | BE | 5 | MEDIUM | 3B.3.2 completo |
| 4.3.4 | Repositories — 6 queries | BE | 8 | HIGH | 3B.3.1 + 3B.3.8 |
| 4.3.2 | Services — 5 services | BE | 13 | HIGH | 3B.1.4 + 3B.5.3 |
| 4.3.8 | Utils | BE | 3 | LOW | 3B.2.2 + 3B.7.9 |
| TL-S2 | Reviews + Coordinación | TL | 4 | MEDIUM | — |
| AR-S2 | Integration Audit | AR | 3 | MEDIUM | — |
| CIERRE-S2 | Cierre Sprint S2 | TL | 2 | MEDIUM | — |
| APR-S2 | Aprobación PM | PM | 1 | LOW | — |

---

## 7. DEPENDENCIAS ENTRE TAREAS

| Tarea | Depende de | Tipo |
|-------|-----------|------|
| SETUP-S2 | CIERRE-S1 | FS |
| 4.2.3 | 4.2.1 (S1) | FS |
| 4.2.4 | 4.2.3 | FS |
| 4.2.5 | 4.2.1 (S1) | FS |
| 4.2.9 | SETUP-S2 | FS |
| 4.2.10 | SETUP-S2 | FS |
| 4.3.7 | 4.3.14 (S1) | FS |
| 4.3.5 | SETUP-S2 | FS |
| 4.3.3 | 4.2.1 (S1) | FS |
| 4.3.4 | 4.3.3 | FS |
| 4.3.8 | SETUP-S2 | FS |
| 4.3.2 | 4.2.3, 4.3.4, 4.3.5, 4.3.7 | FS |
| TL-S2 | 4.2.4, 4.2.5, 4.2.9, 4.2.10, 4.3.2, 4.3.8 | FS |
| AR-S2 | TL-S2 | FS |
| CIERRE-S2 | AR-S2 | FS |
| APR-S2 | CIERRE-S2 | FS |

---

## 8. VTT PLANNING DATA

| Tarea | estimatedHours | complexity | category | deliveryId | dependsOn |
|-------|:--------------:|:----------:|:--------:|:----------:|-----------|
| 4.2.3 | 8 | HIGH | development | DEL_DB_S2 | 4.2.1 (S1) |
| 4.2.4 | 5 | MEDIUM | development | DEL_DB_S2 | 4.2.3 |
| 4.2.5 | 8 | HIGH | development | DEL_DB_S2 | 4.2.1 (S1) |
| 4.2.9 | 3 | LOW | development | DEL_DB_S2 | SETUP-S2 |
| 4.2.10 | 5 | MEDIUM | development | DEL_DB_S2 | SETUP-S2 |
| 4.3.7 | 8 | HIGH | development | DEL_BE_S2 | 4.3.14 (S1) |
| 4.3.5 | 5 | MEDIUM | development | DEL_BE_S2 | SETUP-S2 |
| 4.3.3 | 5 | MEDIUM | development | DEL_BE_S2 | 4.2.1 (S1) |
| 4.3.4 | 8 | HIGH | development | DEL_BE_S2 | 4.3.3 |
| 4.3.2 | 13 | HIGH | development | DEL_BE_S2 | 4.2.3, 4.3.4, 4.3.5, 4.3.7 |
| 4.3.8 | 3 | LOW | development | DEL_BE_S2 | SETUP-S2 |
| TL-S2 | 4 | MEDIUM | review | DEL_TL_S2 | all deliverables |
| AR-S2 | 3 | MEDIUM | review | DEL_REV_S2 | TL-S2 |
| CIERRE-S2 | 2 | MEDIUM | review | DEL_REV_S2 | AR-S2 |
| APR-S2 | 1 | LOW | review | DEL_REV_S2 | CIERRE-S2 |

**Total S2:** 81h

---

## 9. DoD — TL

### Gate M2 verificado:
- [ ] Auth MW activo: request sin X-Service-Key → 401 (verificar contra 3B.4.6)
- [ ] catalogCache cargado: 10 Maps en memoria al startup (verificar contra 3B.3.7)
- [ ] Zod schemas validan: request inválido → 400 con detalle (verificar contra 3B.4.3)
- [ ] ConversationRepository: 6 queries OK con test data, sin N+1 (verificar contra 3B.3.8)
- [ ] **NUNCA** mover tarea a task_approved

---

## 10. GATES DE APROBACIÓN

| Gate | Condición |
|------|-----------|
| DB puede arrancar | SETUP-S2 + S1 cerrado |
| BE MW + DTOs | SETUP-S2 + 4.3.14 (S1) completado |
| BE Models | 4.2.1 (S1) completado |
| BE Repositories | 4.3.3 completado |
| BE Services | 4.2.3 + 4.3.4 + 4.3.5 + 4.3.7 completados |
| Code Review | Todos los deliverables completados |
| Integration Audit | TL Review completado |
| Cierre | AR completado |
| Aprobación PM | CIERRE completado |

---

## 11. REFERENCIAS

| Documento | Propósito |
|-----------|-----------|
| 3B.9.10_routing_index.md | Índice de ruteo deliverable → spec source (fuente de §3) |
| 3B.9.9_capacity_plan.md | Sprint assignment y milestones |
| 3B.9.7_dependencies_map.md | Dependencias cross-sprint |
| HO_PJM_EJECUCION_FASES_4-7.md | Decisiones D-MEM-xx (§4) y modelo de datos (§7) |
| CONTEXTO_S1.md | IDs de tareas S1 para dependencias cross-sprint |
| 2.8.1_traceability_matrix.md | RF → US → AC → Test (para validación de CAs) |

---

## 12. HISTORIAL DE VERSIONES

| Versión | Fecha | Cambios |
|---------|-------|---------|
| 1.0 | 2026-05-12 | Versión inicial — tareas + horas sin ruteo a docs fuente |
| 2.0 | 2026-05-19 | Cada tarea con tabla de ruteo: Spec Source, Sección, Decisiones, Docs para el agente. Sin contenido técnico inventado. |

---

**FIN DEL HANDOFF TL S2**
