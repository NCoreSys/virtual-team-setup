# HANDOFF TL: Memory Service — Sprint S3

**Documento:** HANDOFF_TL_S3.md
**Versión:** 2.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-19
**Sprint:** S3 — Features BE + FE Start
**Estado:** 📋 READY
**Prerrequisitos:** Sprint S2 completado (APR-S2 ✅)

> **Nota:** S3 es el primer sprint con FE. Firmas de cierre: 3 (TL + AR + DL). DL revisa foundation visual.

---

## 0. RESUMEN EJECUTIVO

Sprint S3 tiene dos tracks paralelos:

- **BE (42h):** Exponer los 11 endpoints HTTP sobre los services de S2, implementar Cleanup Job, codificar las 3 integraciones externas (Runtime v1.1, PB v1.3, Hook Manager), API clients, webhooks, third-party SDKs
- **FE (32h):** Foundation completa — componentes base, layout shell, API client con X-Service-Key, hooks de data fetching, state management (React Context), types compartidos, Tailwind setup

Al terminar S3: API funcional end-to-end (POST /import → GET /context → GET /conversations) y SPA FE con foundation desplegada (sin páginas — esas van en S4).

**Deliverable más crítico:** `4.3.1 API Endpoints` (13h, VERY HIGH) — 11 endpoints, GET /context con SLA <500ms.

**Duración total:** ~85h
**Milestone M3:** POST /import e2e OK, JSONL procesado, estado IMPORTED en BD, FE foundation desplegada

---

## 1. ARQUITECTURA DEL SPRINT

```
BE (42h) → DEL_BE_S3                    FE (32h) → DEL_FE_S3
┌──────────────────────────┐             ┌──────────────────────────┐
│ 4.3.1 Endpoints (13h)   │             │ 4.4.8 Styles (3h)       │
│ 4.3.6 Cleanup Job (8h)  │             │ 4.4.7 Types (3h)        │
│ 4.5.1 Integration (8h)──┐             │         │         │      │
│ 4.5.2 API Clients (5h)◄─┤             │         ▼         ▼      │
│ 4.5.3 Webhooks (5h)  ◄──┘             │ 4.4.1 Components (8h)   │
│ 4.5.5 SDKs (3h)         │             │ 4.4.3 Layouts (3h)      │
└──────────────────────────┘             │ 4.4.6 API Client (5h)   │
                                         │ 4.4.4 Hooks (5h)        │
     ↑ depende de S2                     │ 4.4.5 State Mgmt (5h)   │
     (Services, Middlewares)             └──────────────────────────┘
```

---

## 2. DECISIONES CERRADAS QUE APLICAN EN S3

| # | Decisión | Aplica en | Fuente |
|---|----------|-----------|--------|
| D-MEM-01 | Integración Runtime v1.1 → POST /import | 4.5.1 | HO PM §4 |
| D-MEM-02 | Integración Prompt Builder v1.3 → GET /context | 4.5.1 | HO PM §4 |
| D-MEM-03 | Integración Hook Manager → POST /import-review | 4.5.3 | HO PM §4 |
| D-MEM-05 | Idempotencia en POST /import → ALREADY_INDEXED | 4.3.1 | HO PM §4 |
| D-MEM-07 | API contracts — 11 endpoints, SLA <500ms | 4.3.1 | HO PM §4 |
| D-MEM-09 | Auth X-Service-Key en API Client FE | 4.4.6 | HO PM §4 |
| D-MEM-11 | Cleanup job cron 5min, retry ≤3 | 4.3.6 | HO PM §4 |
| D-MEM-22/25 | Webhook VTT_CHANNEL para import-review | 4.5.3 | HO PM §4 |
| D-MEM-27 | ioredis, node-cron, multer como deps | 4.5.5 | HO PM §4 |
| D-MEM-35 | Cleanup job timing y retry policy | 4.3.6 | HO PM §4 |
| D-MEM-41 | Coding standards TypeScript strict | 4.4.1..4.4.9 | HO PM §4 |
| D-MEM-43 | FE standalone UI en puerto 3003 | 4.4.x | HO PM §4 |

---

## 3. BRIEFS POR TAREA — CON RUTEO A DOCUMENTACIÓN FUENTE

### 3.1 Backend Engineer — 42h

#### 4.3.1 API Endpoints — 11 endpoints (13h, VERY HIGH → HIGH en API)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Routes + controllers para 11 endpoints HTTP sobre los services de S2 |
| **Spec Source** | `3B.4.2_endpoints_list.md` completo — 11 endpoints, SLA <500ms |
| **Decisiones** | D-MEM-07 (contracts), D-MEM-05 (idempotencia), D-MEM-01 (Runtime), D-MEM-02 (PB) |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.4.1_openapi_spec.md`, `3B.4.3_request_response_examples.md`, `3B.5.3_business_flows.md`, `3B.2.1_folder_structure.md` |
| **Depende de** | 4.3.2 Services (S2), 4.3.7 Middlewares (S2), 4.2.5 Indexes (S2) |

#### 4.3.6 Workers — Cleanup Job (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Worker node-cron que detecta conversaciones stuck y aplica retry/error |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.5.6_async_flows.md` §Cleanup Job |
| **Decisiones** | D-MEM-11 (cron 5min), D-MEM-35 (retry ≤3, luego ERROR) |
| **Docs que el agente debe leer** | `3B.5.6`, `3B.4.2`, `3B.8.1_infra_plan.md` |
| **Depende de** | 4.3.2 Services (S2) |

#### 4.5.1 Integration Code — 3 integraciones (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Código de integración con 3 sistemas externos: Runtime v1.1, Prompt Builder v1.3, Hook Manager VTT |
| **Spec Source** | `ADDENDUM` + `3B.5.5_integration_flows.md` §Runtime, §PB, §HM |
| **Decisiones** | D-MEM-01 (Runtime POST /import), D-MEM-02 (PB GET /context), D-MEM-03 (HM POST /import-review) |
| **Docs que el agente debe leer** | `ADDENDUM`, `3B.5.5`, `3B.4.2`, `3B.5.3_business_flows.md` |
| **Depende de** | 4.3.2 Services (S2) |

#### 4.5.2 API Clients — consumidores (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Clientes HTTP para consumidores externos de Memory Service |
| **Spec Source** | `3B.4.11_api_guidelines.md` + `ADDENDUM` §clientes HTTP |
| **Decisiones** | D-MEM-01, D-MEM-02 |
| **Docs que el agente debe leer** | `3B.4.11`, `ADDENDUM`, `3B.4.6_auth_spec.md` |
| **Depende de** | 4.5.1 |

#### 4.5.3 Webhooks — POST /import-review (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Webhook para VTT_CHANNEL vía Hook Manager |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `ADDENDUM` §POST /import-review |
| **Decisiones** | D-MEM-22, D-MEM-25 |
| **Docs que el agente debe leer** | `3B.4.2`, `ADDENDUM`, `3B.5.5_integration_flows.md`, `3B.5.6_async_flows.md` |
| **Depende de** | 4.5.1 |

#### 4.5.5 Third-party SDKs (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Instalación y configuración de dependencias npm: ioredis 5.x, node-cron, multer |
| **Spec Source** | `3B.8.1_infra_plan.md` + `SPEC §dependencias` |
| **Decisiones** | D-MEM-11 (node-cron), D-MEM-27 (ioredis), D-MEM-35 (cleanup) |
| **Docs que el agente debe leer** | `3B.8.1`, `SPEC §dependencias` |
| **Depende de** | SETUP-S3 |

---

### 3.2 Frontend Developer — 32h

#### 4.4.1 Components — shared + layout shell + nav (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Componentes base: AppShell, Sidebar, Header, Card, Table, Badge, Button, StatusIndicator |
| **Spec Source** | `3B.2.1_folder_structure.md` + Design Handoff §shared components, §layout shell, §nav |
| **Decisiones** | D-MEM-41, D-MEM-43 |
| **Docs que el agente debe leer** | `3B.2.1`, `3A.9.1_handoff_document.md`, `3A.7.6_component_library.md` |
| **Depende de** | 4.4.8 Styles (Tailwind tokens necesarios) |

#### 4.4.3 Layouts (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | MainLayout con sidebar + content area |
| **Spec Source** | `3B.2.1_folder_structure.md` + `3A.9.1_handoff_document.md` §layout shell |
| **Decisiones** | D-MEM-41, D-MEM-43 |
| **Docs que el agente debe leer** | `3B.2.1`, `3A.9.1_handoff_document.md` |
| **Depende de** | 4.4.1 Components |

#### 4.4.4 Hooks — useConversations, useContext, useCosts (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Custom hooks para data fetching con estados loading/error/data |
| **Spec Source** | `3B.4.2_endpoints_list.md` §useConversations, §useContext, §useCosts |
| **Decisiones** | D-MEM-43 |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.4.3_request_response_examples.md`, `3B.2.3_design_patterns.md` |
| **Depende de** | 4.4.6 API Client FE (fetch wrapper) |

#### 4.4.5 State Management (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | React Context para global state: AuthContext, FilterContext |
| **Spec Source** | `3B.2.3_design_patterns.md` §React Context / local state |
| **Decisiones** | D-MEM-43 |
| **Docs que el agente debe leer** | `3B.2.3`, `3B.2.4_module_dependencies.md` |
| **Depende de** | 4.4.1 Components |

#### 4.4.6 API Client FE (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Fetch wrapper con X-Service-Key header, error handling, base URL config |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.4.6_auth_spec.md` §fetch + X-Service-Key + error handling |
| **Decisiones** | D-MEM-05 (contracts), D-MEM-09 (X-Service-Key) |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.4.6`, `3B.4.5_error_codes.md`, `3B.4.4` |
| **Depende de** | 4.4.7 Types/Interfaces |

#### 4.4.7 Types/Interfaces — @NCoreSys/api-types (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Shared types package entre backend y frontend |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.4.3_request_response_examples.md` §types package |
| **Decisiones** | D-MEM-43 |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.4.3` |
| **Depende de** | SETUP-S3 |

#### 4.4.8 Styles — Tailwind setup (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Tailwind CSS 3.x config con design tokens del design system |
| **Spec Source** | Design System tokens §Tailwind CSS 3.x |
| **Decisiones** | D-MEM-43 |
| **Docs que el agente debe leer** | `3A.7.1_design_tokens.md`, `3A.7.4_spacing_system.md`, `3A.9.4_css_variables.md` |
| **Depende de** | SETUP-S3 |

---

## 4. VARIABLES DE ENTORNO

Nuevas para FE:

| Variable | Usado por |
|----------|-----------|
| `VITE_API_URL` | 4.4.6 API Client FE — se conecta al backend |
| `VITE_SERVICE_KEY` | 4.4.6 API Client FE — envía X-Service-Key |

---

## 5. RIESGOS Y MITIGACIONES

| Riesgo | Prob. | Impacto | Deliverable | Mitigación |
|--------|:-----:|:-------:|:-----------:|------------|
| R-01: GET /context >500ms en dev | 0.30 | HIGH | 4.3.1 | SLA check preliminar en S3. Si >400ms alertar. Ver `3B.4.2` §SLA |
| R-02: Runtime v1.1 contrato incompleto | 0.25 | MEDIUM | 4.5.1 | Ver `ADDENDUM` — mock si Runtime no disponible |
| R-04: Hook Manager formato cambia | 0.20 | MEDIUM | 4.5.3 | Ver `ADDENDUM` — mock para integración |
| R-10: Renovate no bumps api-types | 0.20 | LOW | 4.4.7 | Bump manual si Renovate falla |

---

## 6. TAREAS DEL SPRINT

| ID | Tarea | Agente | Horas | Complejidad | Spec Source |
|----|-------|--------|:-----:|:-----------:|-------------|
| 4.3.1 | API Endpoints — 11 endpoints | BE | 13 | HIGH | `3B.4.2` completo |
| 4.3.6 | Workers — Cleanup Job | BE | 8 | HIGH | `3B.5.6` §Cleanup |
| 4.5.1 | Integration Code — 3 integraciones | BE | 8 | HIGH | `ADDENDUM` + `3B.5.5` |
| 4.5.2 | API Clients | BE | 5 | MEDIUM | `3B.4.11` + `ADDENDUM` |
| 4.5.3 | Webhooks — POST /import-review | BE | 5 | MEDIUM | `3B.4.2` + `ADDENDUM` |
| 4.5.5 | Third-party SDKs | BE | 3 | LOW | `3B.8.1` + `SPEC §deps` |
| 4.4.1 | Components — shared + layout | FE | 8 | HIGH | `3B.2.1` + `3A.9.1` + `3A.7.6` |
| 4.4.3 | Layouts | FE | 3 | LOW | `3B.2.1` + `3A.9.1` |
| 4.4.4 | Hooks | FE | 5 | MEDIUM | `3B.4.2` + `3B.4.3` + `3B.2.3` |
| 4.4.5 | State Management | FE | 5 | MEDIUM | `3B.2.3` + `3B.2.4` |
| 4.4.6 | API Client FE | FE | 5 | MEDIUM | `3B.4.2` + `3B.4.6` |
| 4.4.7 | Types/Interfaces | FE | 3 | LOW | `3B.4.2` + `3B.4.3` |
| 4.4.8 | Styles — Tailwind | FE | 3 | LOW | `3A.7.1` + `3A.7.4` + `3A.9.4` |
| TL-S3 | Reviews + SLA Check | TL | 3 | MEDIUM | — |
| AR-S3 | Integration Audit | AR | 3 | MEDIUM | — |
| DL-S3 | Visual Review FE Foundation | DL | 2 | LOW | — |
| CIERRE-S3 | Cierre Sprint S3 | TL | 2 | MEDIUM | — |
| APR-S3 | Aprobación PM | PM | 1 | LOW | — |

---

## 7. DEPENDENCIAS ENTRE TAREAS

| Tarea | Depende de | Tipo |
|-------|-----------|------|
| SETUP-S3 | CIERRE-S2 | FS |
| 4.3.1 | 4.3.2 (S2), 4.3.7 (S2), 4.2.5 (S2) | FS |
| 4.3.6 | 4.3.2 (S2) | FS |
| 4.5.1 | 4.3.2 (S2) | FS |
| 4.5.2 | 4.5.1 | FS |
| 4.5.3 | 4.5.1 | FS |
| 4.5.5 | SETUP-S3 | FS |
| 4.4.7 | SETUP-S3 | FS |
| 4.4.8 | SETUP-S3 | FS |
| 4.4.1 | 4.4.8 | FS |
| 4.4.3 | 4.4.1 | FS |
| 4.4.6 | 4.4.7 | FS |
| 4.4.4 | 4.4.6 | FS |
| 4.4.5 | 4.4.1 | FS |
| TL-S3 | 4.3.1, 4.3.6, 4.5.2, 4.5.3, 4.4.4, 4.4.5 | FS |
| DL-S3 | 4.4.1, 4.4.3, 4.4.8 | FS |
| AR-S3 | TL-S3 | FS |
| CIERRE-S3 | AR-S3, DL-S3 | FS |
| APR-S3 | CIERRE-S3 | FS |

---

## 8. VTT PLANNING DATA

| Tarea | estimatedHours | complexity | category | deliveryId | dependsOn |
|-------|:--------------:|:----------:|:--------:|:----------:|-----------|
| 4.3.1 | 13 | HIGH | development | DEL_BE_S3 | 4.3.2(S2), 4.3.7(S2), 4.2.5(S2) |
| 4.3.6 | 8 | HIGH | development | DEL_BE_S3 | 4.3.2(S2) |
| 4.5.1 | 8 | HIGH | development | DEL_BE_S3 | 4.3.2(S2) |
| 4.5.2 | 5 | MEDIUM | development | DEL_BE_S3 | 4.5.1 |
| 4.5.3 | 5 | MEDIUM | development | DEL_BE_S3 | 4.5.1 |
| 4.5.5 | 3 | LOW | development | DEL_BE_S3 | SETUP-S3 |
| 4.4.1 | 8 | HIGH | development | DEL_FE_S3 | 4.4.8 |
| 4.4.3 | 3 | LOW | development | DEL_FE_S3 | 4.4.1 |
| 4.4.4 | 5 | MEDIUM | development | DEL_FE_S3 | 4.4.6 |
| 4.4.5 | 5 | MEDIUM | development | DEL_FE_S3 | 4.4.1 |
| 4.4.6 | 5 | MEDIUM | development | DEL_FE_S3 | 4.4.7 |
| 4.4.7 | 3 | LOW | development | DEL_FE_S3 | SETUP-S3 |
| 4.4.8 | 3 | LOW | development | DEL_FE_S3 | SETUP-S3 |
| TL-S3 | 3 | MEDIUM | review | DEL_TL_S3 | 4.3.1,4.3.6,4.5.2,4.5.3,4.4.4,4.4.5 |
| AR-S3 | 3 | MEDIUM | review | DEL_REV_S3 | TL-S3 |
| DL-S3 | 2 | LOW | review | DEL_REV_S3 | 4.4.1,4.4.3,4.4.8 |
| CIERRE-S3 | 2 | MEDIUM | review | DEL_REV_S3 | AR-S3, DL-S3 |
| APR-S3 | 1 | LOW | review | DEL_REV_S3 | CIERRE-S3 |

**Total S3:** 85h

---

## 9. DoD — TL

### Gate M3 verificado:
- [ ] POST /import e2e OK — JSONL → IMPORTED (verificar contra `3B.5.3` §import-flow)
- [ ] GET /context retorna JSON estructurado (verificar contra `3B.4.2` §GET /context)
- [ ] Cleanup Job ejecuta cada 5min sin error (verificar contra `3B.5.6`)
- [ ] FE foundation desplegada — SPA levanta en localhost:3003 (verificar contra `3B.2.1`)
- [ ] DL review de FE foundation coordinado
- [ ] **NUNCA** mover tarea a `task_approved`

---

## 10. GATES DE APROBACIÓN

| Gate | Condición |
|------|-----------|
| BE puede arrancar | SETUP-S3 + S2 cerrado |
| FE puede arrancar | SETUP-S3 + Design Handoff (3A) completado |
| TL Review | Todos los deliverables BE + FE completados |
| DL Review | FE foundation (components, layouts, styles) completada |
| AR Audit | TL Review completado |
| Cierre | AR + DL completados |
| APR PM | CIERRE completado |

---

## 11. REFERENCIAS

| Documento | Propósito |
|-----------|-----------|
| `3B.9.10_routing_index.md` | Índice de ruteo deliverable → spec source (fuente de §3) |
| `3B.4.2_endpoints_list.md` | Contratos de 11 endpoints |
| `ADDENDUM` | Contratos de 3 integraciones externas |
| `3B.5.3_business_flows.md` | Flujos de negocio (import, context, cleanup) |
| `3A.9.1_handoff_document.md` | Design Handoff para FE |
| `3A.7.6_component_library.md` | Component library del design system |
| `CONTEXTO_S2.md` | IDs de tareas S2 para dependencias cross-sprint |

---

## 12. HISTORIAL DE VERSIONES

| Versión | Fecha | Cambios |
|---------|-------|---------|
| 1.0 | 2026-05-12 | Versión inicial — tareas + horas sin ruteo a docs fuente |
| 2.0 | 2026-05-19 | Cada tarea con tabla de ruteo desde 3B.9.10. Sin contenido técnico inventado. |

---

**FIN DEL HANDOFF TL S3**
