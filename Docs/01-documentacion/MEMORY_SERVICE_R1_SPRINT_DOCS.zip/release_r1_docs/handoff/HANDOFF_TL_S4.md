# HANDOFF TL: Memory Service — Sprint S4

**Documento:** HANDOFF_TL_S4.md
**Versión:** 2.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-19
**Sprint:** S4 — FE Features + Context SLA
**Estado:** 📋 READY
**Prerrequisitos:** Sprint S3 completado (APR-S3 ✅)

> **Nota:** S4 tiene FE. Firmas de cierre: 3 (TL + AR + DL). Último sprint de Fase 4 Development. Milestone M4 es el de mayor riesgo técnico.

---

## 0. RESUMEN EJECUTIVO

Sprint S4 cierra Fase 4 con dos tracks paralelos:

- **FE (32h):** Las 8 pantallas completas, responsive, unit tests FE, component tests, README FE
- **BE (37h):** Error handling de integraciones + retry logic, integration tests, Swagger, Postman collection, unit tests BE (≥80% coverage)

**Deliverable más crítico:** `4.4.2 Pages` (13h, VERY HIGH) — 8 pantallas con data fetching, cursor pagination, filtros. Y el gate M4: GET /context <500ms p95.

**Duración total:** ~82h
**Milestone M4:** GET /context <500ms p95, 8 pantallas FE renderizan, unit tests BE passing ≥80%

> **Contingencia M4:** Si GET /context no cumple <500ms p95 → EXPLAIN ANALYZE en staging → índice adicional → re-test k6. Ver `3B.9.9` §12.

---

## 1. ARQUITECTURA DEL SPRINT

```
FE (32h) → DEL_FE_S4                    BE (37h) → DEL_BE_S4
┌──────────────────────────┐             ┌──────────────────────────┐
│ 4.4.2 Pages (13h) ──┐    │             │ 4.5.8 Error Integ (5h)  │
│ 4.4.9 Utils (2h)    │    │             │ 4.5.9 Retry Logic (5h)  │
│ 4.4.15 Responsive(5h)◄┘  │             │ 4.5.6 Integ Tests (8h)  │
│ 4.4.10 Unit Tests (5h)   │             │ 4.5.7 Integ Docs (3h)   │
│ 4.4.11 Comp Tests (5h)   │             │ 4.3.11 Swagger (5h)     │
│ 4.4.13 README (2h)       │             │ 4.3.12 Postman (3h)     │
└──────────────────────────┘             │ 4.3.9 Unit Tests (8h)   │
                                         └──────────────────────────┘
     ↑ depende de S3                          ↑ depende de S3/S2
     (Components, Layouts,                    (Endpoints, Integration
      API Client, Hooks)                       Code, Services)
```

---

## 2. DECISIONES CERRADAS QUE APLICAN EN S4

| # | Decisión | Aplica en | Fuente |
|---|----------|-----------|--------|
| D-MEM-01/02/03 | 3 integraciones externas (retry + error handling) | 4.5.8, 4.5.9, 4.5.6 | HO PM §4 |
| D-MEM-07 | API contracts — 11 endpoints (Swagger, Postman) | 4.3.11, 4.3.12, 4.3.9 | HO PM §4 |
| D-MEM-08 | Error codes MEM-ERR-xxx | 4.5.8, 4.3.9 | HO PM §4 |
| D-MEM-11/40 | Retry con backoff exponencial | 4.5.9 | HO PM §4 |
| D-MEM-41 | Coding standards (tests, README) | 4.4.10, 4.4.11, 4.4.13, 4.3.9 | HO PM §4 |
| D-MEM-43 | FE standalone — 8 pantallas + responsive | 4.4.2, 4.4.15 | HO PM §4 |

---

## 3. BRIEFS POR TAREA — CON RUTEO A DOCUMENTACIÓN FUENTE

### 3.1 Frontend Developer — 32h

#### 4.4.2 Pages — 8 pantallas (13h, VERY HIGH → HIGH en API)

| Campo | Valor |
|-------|-------|
| **Qué producir** | 8 pantallas completas: Dashboard, AgentTimeline, ConversationsList, ConversationViewer, CostReportProject, CostReportAgent, ImportManual, Health |
| **Spec Source** | Wireframes por pantalla (8 docs midfi + specs) |
| **Decisiones** | D-MEM-43 |
| **Docs que el agente debe leer** | `3A.5.1b_dashboard_wireframe_midfi.md`, `3A.5.2b_timeline_wireframe_midfi.md`, `3A.5.3b_viewer_wireframe_midfi.md`, `3A.5.4a..4b_cost_wireframe_midfi.md`, `3A.5.5a_conversations_list_wireframe_midfi.md`, `3A.5.6a_upload_wireframe_midfi.md`, `3A.5.7a_health_wireframe_midfi.md` + specs `3A.5.x_c_specs.md` por pantalla |
| **Depende de** | 4.4.1 Components (S3), 4.4.6 API Client (S3), 4.4.3 Layouts (S3) |

#### 4.4.9 Utils FE (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Utilidades frontend: formatters, date helpers, path utils |
| **Spec Source** | `3B.2.2_coding_standards.md` §formatters, §date utils |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.2`, `3B.2.5_naming_conventions.md` |
| **Depende de** | SETUP-S4 |

#### 4.4.15 Responsive Implementation (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Media queries + breakpoints para 8 pantallas |
| **Spec Source** | `3A.6.3_responsive_breakpoints.md` completo — Tailwind breakpoints mobile + desktop |
| **Decisiones** | D-MEM-43 |
| **Docs que el agente debe leer** | `3A.6.3_responsive_breakpoints.md`, `3A.7.4_spacing_system.md` |
| **Depende de** | 4.4.2 Pages, 4.4.1 Components (S3) |

#### 4.4.10 Unit Tests FE (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Tests unitarios de hooks, utils, state management (Vitest + RTL) |
| **Spec Source** | `3B.2.2_coding_standards.md` §Vitest + RTL — componentes clave |
| **Decisiones** | D-MEM-41, D-MEM-43 |
| **Docs que el agente debe leer** | `3B.2.2`, deliverables `4.4.1` (S3), `4.4.2` |
| **Depende de** | 4.4.4 Hooks (S3), 4.4.9 Utils |

#### 4.4.11 Component Tests (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Tests de componentes con Testing Library — props, events, renders, estados |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.2.2_coding_standards.md` §RTL — páginas con mocks de API |
| **Decisiones** | D-MEM-41, D-MEM-43 |
| **Docs que el agente debe leer** | `3B.2.2`, `3B.4.3_request_response_examples.md` |
| **Depende de** | 4.4.1 Components (S3) |

#### 4.4.13 Frontend README (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Documentación del frontend: setup, estructura, componentes, hooks, comandos |
| **Spec Source** | `3B.2.1_folder_structure.md` §estructura FE + comandos |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.1`, `3B.2.2` |
| **Depende de** | 4.4.2 Pages |

---

### 3.2 Backend Engineer — 37h

#### 4.5.8 Error Handling Integration (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Error handling específico para integraciones externas (Runtime, PB, HM) |
| **Spec Source** | `3B.4.5_error_codes.md` + `3B.2.6_error_handling_strategy.md` §retry logic + fallback |
| **Decisiones** | D-MEM-08 (MEM-ERR-xxx), D-MEM-40 |
| **Docs que el agente debe leer** | `3B.2.6`, `3B.4.5`, `ADDENDUM §errores` |
| **Depende de** | 4.5.1 Integration Code (S3) |

#### 4.5.9 Retry Logic (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Retry con backoff exponencial para integraciones fallidas |
| **Spec Source** | `3B.5.5_integration_flows.md` + `ADDENDUM` §backoff exponencial en ImportService |
| **Decisiones** | D-MEM-11, D-MEM-40 |
| **Docs que el agente debe leer** | `3B.5.5`, `ADDENDUM`, `3B.2.6_error_handling_strategy.md` |
| **Depende de** | 4.5.8 |

#### 4.5.6 Integration Tests (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Tests de integración para 3 integraciones externas + contratos |
| **Spec Source** | `3B.5.5_integration_flows.md` §3 integraciones × happy path + error path |
| **Decisiones** | D-MEM-01, D-MEM-02, D-MEM-03 |
| **Docs que el agente debe leer** | `3B.5.5`, `3B.5.4`, `ADDENDUM`, `3B.4.5_error_codes.md` |
| **Depende de** | 4.5.1 Integration Code (S3) |

#### 4.5.7 Integration Docs (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Documentación de cada integración: contrato, auth, error codes, retry policy |
| **Spec Source** | `ADDENDUM` + `3B.5.5_integration_flows.md` §contratos de las 3 integraciones |
| **Decisiones** | D-MEM-01, D-MEM-02, D-MEM-03 |
| **Docs que el agente debe leer** | `ADDENDUM`, `3B.5.5`, `3B.4.2` |
| **Depende de** | 4.5.1 Integration Code (S3) |

#### 4.3.11 API Documentation — Swagger (5h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Swagger UI auto-generado con 11 endpoints documentados en /api-docs |
| **Spec Source** | `3B.4.1_openapi_spec.md` completo — 11 endpoints Swagger/OpenAPI |
| **Decisiones** | D-MEM-07 |
| **Docs que el agente debe leer** | `3B.4.1`, `3B.4.2`, `3B.4.3`, `3B.4.5` |
| **Depende de** | 4.3.1 API Endpoints (S3) |

#### 4.3.12 Postman Collection (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Collection Postman actualizada con endpoints reales + examples |
| **Spec Source** | `3B.4.10_postman_collection.md` completo |
| **Decisiones** | D-MEM-07 |
| **Docs que el agente debe leer** | `3B.4.10`, `3B.4.2`, `3B.4.3` |
| **Depende de** | 4.3.1 API Endpoints (S3) |

#### 4.3.9 Unit Tests BE (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Tests unitarios de 5 services + repositories + middlewares. Target ≥80% coverage |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.4.5_error_codes.md` §casos de prueba por endpoint |
| **Decisiones** | D-MEM-07, D-MEM-08 |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.4.5`, `3B.2.2_coding_standards.md`, deliverables `4.3.1`..`4.3.7` |
| **Depende de** | 4.3.2 Services (S2) |

---

## 4. VARIABLES DE ENTORNO

Sin variables nuevas respecto a S3.

---

## 5. RIESGOS Y MITIGACIONES

| Riesgo | Prob. | Impacto | Deliverable | Mitigación |
|--------|:-----:|:-------:|:-----------:|------------|
| R-01: GET /context >500ms p95 | 0.40 | HIGH | M4 gate | Ver `3B.9.9` §12 — EXPLAIN ANALYZE + índice adicional |
| R-07: TS strict rework en pages | 0.25 | MEDIUM | 4.4.2 | Types de S3 (4.4.7) ya definidos |
| R-14: Component tests flaky | 0.20 | LOW | 4.4.11 | `waitFor` en vez de `sleep`. Retry en CI |

---

## 6. TAREAS DEL SPRINT

| ID | Tarea | Agente | Horas | Complejidad | Spec Source |
|----|-------|--------|:-----:|:-----------:|-------------|
| 4.4.2 | Pages — 8 pantallas | FE | 13 | HIGH | Wireframes `3A.5.x` |
| 4.4.9 | Utils FE | FE | 2 | LOW | `3B.2.2` §formatters |
| 4.4.15 | Responsive | FE | 5 | MEDIUM | `3A.6.3` completo |
| 4.4.10 | Unit Tests FE | FE | 5 | MEDIUM | `3B.2.2` §Vitest+RTL |
| 4.4.11 | Component Tests | FE | 5 | MEDIUM | `3B.2.2` + `3B.4.3` |
| 4.4.13 | Frontend README | FE | 2 | LOW | `3B.2.1` §FE |
| 4.5.8 | Error Handling Integ | BE | 5 | MEDIUM | `3B.4.5` + `3B.2.6` |
| 4.5.9 | Retry Logic | BE | 5 | MEDIUM | `3B.5.5` + `ADDENDUM` |
| 4.5.6 | Integration Tests | BE | 8 | HIGH | `3B.5.5` §3 integ |
| 4.5.7 | Integration Docs | BE | 3 | LOW | `ADDENDUM` + `3B.5.5` |
| 4.3.11 | Swagger | BE | 5 | MEDIUM | `3B.4.1` completo |
| 4.3.12 | Postman Collection | BE | 3 | LOW | `3B.4.10` completo |
| 4.3.9 | Unit Tests BE | BE | 8 | HIGH | `3B.4.2` + `3B.4.5` |
| TL-S4 | Reviews + SLA Validation | TL | 4 | MEDIUM | — |
| AR-S4 | Integration Audit | AR | 3 | MEDIUM | — |
| DL-S4 | Visual Review 8 Pantallas | DL | 3 | MEDIUM | — |
| CIERRE-S4 | Cierre Sprint S4 (Fin F4) | TL | 2 | MEDIUM | — |
| APR-S4 | Aprobación PM | PM | 1 | LOW | — |

---

## 7. DEPENDENCIAS ENTRE TAREAS

| Tarea | Depende de | Tipo |
|-------|-----------|------|
| SETUP-S4 | CIERRE-S3 | FS |
| 4.4.2 | 4.4.1 (S3), 4.4.6 (S3), 4.4.3 (S3) | FS |
| 4.4.9 | SETUP-S4 | FS |
| 4.4.15 | 4.4.2, 4.4.1 (S3) | FS |
| 4.4.10 | 4.4.4 (S3), 4.4.9 | FS |
| 4.4.11 | 4.4.1 (S3) | FS |
| 4.4.13 | 4.4.2 | FS |
| 4.5.8 | 4.5.1 (S3) | FS |
| 4.5.9 | 4.5.8 | FS |
| 4.5.6 | 4.5.1 (S3) | FS |
| 4.5.7 | 4.5.1 (S3) | FS |
| 4.3.11 | 4.3.1 (S3) | FS |
| 4.3.12 | 4.3.1 (S3) | FS |
| 4.3.9 | 4.3.2 (S2) | FS |
| TL-S4 | 4.4.2, 4.4.15, 4.4.10, 4.4.11, 4.5.9, 4.5.6, 4.3.9, 4.3.11 | FS |
| DL-S4 | 4.4.2, 4.4.15 | FS |
| AR-S4 | TL-S4 | FS |
| CIERRE-S4 | AR-S4, DL-S4 | FS |
| APR-S4 | CIERRE-S4 | FS |

---

## 8. VTT PLANNING DATA

| Tarea | estimatedHours | complexity | category | deliveryId | dependsOn |
|-------|:--------------:|:----------:|:--------:|:----------:|-----------|
| 4.4.2 | 13 | HIGH | development | DEL_FE_S4 | 4.4.1(S3), 4.4.6(S3), 4.4.3(S3) |
| 4.4.9 | 2 | LOW | development | DEL_FE_S4 | SETUP-S4 |
| 4.4.15 | 5 | MEDIUM | development | DEL_FE_S4 | 4.4.2, 4.4.1(S3) |
| 4.4.10 | 5 | MEDIUM | development | DEL_FE_S4 | 4.4.4(S3), 4.4.9 |
| 4.4.11 | 5 | MEDIUM | development | DEL_FE_S4 | 4.4.1(S3) |
| 4.4.13 | 2 | LOW | development | DEL_FE_S4 | 4.4.2 |
| 4.5.8 | 5 | MEDIUM | development | DEL_BE_S4 | 4.5.1(S3) |
| 4.5.9 | 5 | MEDIUM | development | DEL_BE_S4 | 4.5.8 |
| 4.5.6 | 8 | HIGH | development | DEL_BE_S4 | 4.5.1(S3) |
| 4.5.7 | 3 | LOW | development | DEL_BE_S4 | 4.5.1(S3) |
| 4.3.11 | 5 | MEDIUM | development | DEL_BE_S4 | 4.3.1(S3) |
| 4.3.12 | 3 | LOW | development | DEL_BE_S4 | 4.3.1(S3) |
| 4.3.9 | 8 | HIGH | development | DEL_BE_S4 | 4.3.2(S2) |
| TL-S4 | 4 | MEDIUM | review | DEL_TL_S4 | all deliverables |
| AR-S4 | 3 | MEDIUM | review | DEL_REV_S4 | TL-S4 |
| DL-S4 | 3 | MEDIUM | review | DEL_REV_S4 | 4.4.2, 4.4.15 |
| CIERRE-S4 | 2 | MEDIUM | review | DEL_REV_S4 | AR-S4, DL-S4 |
| APR-S4 | 1 | LOW | review | DEL_REV_S4 | CIERRE-S4 |

**Total S4:** 82h

---

## 9. DoD — TL

### Gate M4 verificado (mayor riesgo técnico):
- [ ] GET /context <500ms p95 (verificar contra `3B.4.2` §SLA + `3B.9.9` §12 contingencia)
- [ ] 8 pantallas FE renderizan (verificar contra wireframes `3A.5.x`)
- [ ] Unit tests BE ≥80% coverage (verificar contra `3B.2.2` §coverage gate)
- [ ] Integration tests passing (verificar contra `3B.5.5`)
- [ ] DL review de 8 pantallas + responsive coordinado
- [ ] **NUNCA** mover tarea a `task_approved`

---

## 10. GATES DE APROBACIÓN

| Gate | Condición |
|------|-----------|
| FE puede arrancar | SETUP-S4 + Components/Layouts/API Client de S3 completados |
| BE puede arrancar | SETUP-S4 + Integration Code/Endpoints/Services de S3/S2 completados |
| TL Review | Todos los deliverables FE + BE completados |
| DL Review | Pages + Responsive completados |
| AR Audit | TL Review completado |
| Cierre | AR + DL completados |
| APR PM | CIERRE completado — **cierra Fase 4** |

---

## 11. REFERENCIAS

| Documento | Propósito |
|-----------|-----------|
| `3B.9.10_routing_index.md` | Índice de ruteo deliverable → spec source (fuente de §3) |
| `3B.4.2_endpoints_list.md` | Contratos de 11 endpoints (Swagger, Postman, unit tests) |
| `ADDENDUM` | Contratos de 3 integraciones (error handling, retry) |
| `3A.5.x` wireframes | Specs de 8 pantallas (Pages, DL review) |
| `3A.6.3_responsive_breakpoints.md` | Breakpoints para responsive |
| `3B.9.9` §12 | Plan de contingencia M4 (SLA <500ms) |
| `CONTEXTO_S3.md` | IDs de tareas S3 para dependencias cross-sprint |

---

## 12. HISTORIAL DE VERSIONES

| Versión | Fecha | Cambios |
|---------|-------|---------|
| 1.0 | 2026-05-12 | Versión inicial — tareas + horas sin ruteo |
| 2.0 | 2026-05-19 | Cada tarea con tabla de ruteo desde 3B.9.10. Sin contenido técnico inventado. |

---

**FIN DEL HANDOFF TL S4**
