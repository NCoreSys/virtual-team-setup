# HANDOFF TL: Memory Service — Sprint S7

**Documento:** HANDOFF_TL_S7.md
**Versión:** 2.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Sprint:** S7 — Deploy Staging
**Prerrequisitos:** Sprint S6 completado, Fase 5 cerrada (APR-S6 ✅)

> **Nota:** S7 sin FE → 2 firmas (TL + AR). DO es el rol dominante. Primer sprint de Fase 6.

---

## 0. RESUMEN EJECUTIVO

- **DO (~62h):** Infra Hetzner, CI/CD pipelines (GitHub Actions 4 repos), staging deploy, health check
- **DB (3h):** Migration run en staging
- **QA (6h):** Smoke tests en staging (critical paths)

**Duración total:** ~73h
**Milestone M6:** Staging live en 77.42.88.106, smoke tests OK, CI/CD activo

---

## 1. BRIEFS POR TAREA — CON RUTEO

### 1.1 DevOps Engineer — ~62h

#### 6.1.1-4 Infrastructure Ready + Servers + Network + Security Groups (16h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Servidor Hetzner provisionado, networking, firewall, security groups |
| **Spec Source** | `3B.8.1_infra_plan.md` §Hetzner + `3B.8.3_server_specs.md` + `3B.8.4_network_config.md` + `3B.7.1_security_plan.md` |
| **Decisiones** | D-MEM-36 (single-node), D-MEM-37 (puertos), D-MEM-09 (security groups) |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.2`, `3B.8.3`, `3B.8.4`, `3B.7.1` |
| **Depende de** | SETUP-S7 |

#### 6.1.6+8 Database Ready + SSL Certificates (8h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | shared-postgres + memory_service_db en staging + SSL certs |
| **Spec Source** | `3B.8.1_infra_plan.md` + `3B.3.6_migration_strategy.md` + `3B.8.4_network_config.md` §SSL |
| **Decisiones** | D-MEM-10 (Prisma), D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.3.6`, `3B.8.3`, `3B.8.4`, `3B.7.5` |
| **Depende de** | 6.1.1-4 |

#### 6.2.1 CI Pipeline (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | GitHub Actions para 4 repos: lint → type-check → test → build → push Docker |
| **Spec Source** | `3B.8.1_infra_plan.md` §GitHub Actions — 4 repos separados |
| **Decisiones** | D-MEM-36, D-MEM-41 (coding standards en CI) |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.2.2_coding_standards.md`, `3B.8.5_env_matrix.md` |
| **Depende de** | 6.1.1-4 |

#### 6.2.2 CD Pipeline (8h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Deploy automático a staging/prod con health checks y rollback |
| **Spec Source** | `3B.8.1_infra_plan.md` §deploy automático |
| **Decisiones** | D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.7_backup_plan.md` |
| **Depende de** | 6.2.1 |

#### 6.2.3-6 Build Scripts + Deploy Scripts + Env Configs + Docs (13h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Scripts de build/deploy, configs de entorno para CI/CD, documentación del pipeline |
| **Spec Source** | `3B.8.1` §docker build + `3B.8.7` §deploy + `3B.8.5` §secrets GitHub Actions |
| **Decisiones** | D-MEM-36, D-MEM-37, D-MEM-38, D-MEM-39 |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.5`, `3B.8.7`, `3B.7.8`, deliverables `6.2.1`, `6.2.2` |
| **Depende de** | 6.2.1 |

#### 6.3.1-2 Staging Deploy + URL (7h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Deploy a staging en 77.42.88.106 + URL pública |
| **Spec Source** | `3B.8.1_infra_plan.md` + `3B.8.4_network_config.md` §URL |
| **Decisiones** | D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.4`, deliverables `6.2.1`, `6.2.2` |
| **Depende de** | 6.2.2, 6.1.6+8 |

#### 6.3.4 Health Check staging (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | GET /api/health OK en staging |
| **Spec Source** | `3B.4.2_endpoints_list.md` §GET /health |
| **Decisiones** | D-MEM-07 |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.8.11_monitoring_strategy.md` |
| **Depende de** | 6.3.3 Migration Run |

---

### 1.2 Database Engineer — 3h

#### 6.3.3 Migration Run en staging (3h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | prisma migrate deploy en staging + verificar 29 tablas |
| **Spec Source** | `3B.3.6_migration_strategy.md` §prisma migrate deploy |
| **Decisiones** | D-MEM-10 |
| **Docs que el agente debe leer** | `3B.3.6`, deliverable `6.3.1` |
| **Depende de** | 6.3.1-2 Staging Deploy |

---

### 1.3 QA Engineer — 6h

#### 6.4.1-3 Smoke Test Results + Critical Paths + Sign-off (6h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Smoke tests en staging: import → context → list, resultados, sign-off |
| **Spec Source** | `3B.4.2_endpoints_list.md` + `3B.5.3_business_flows.md` §flujos críticos |
| **Decisiones** | D-MEM-01 (import), D-MEM-07 (contracts) |
| **Docs que el agente debe leer** | `3B.4.2`, `3B.5.3`, deliverable `6.3.4` |
| **Depende de** | 6.3.4 Health Check |

---

## 2. TAREAS DEL SPRINT

| ID | Tarea | Agente | Horas | Complejidad | Spec Source |
|----|-------|--------|:-----:|:-----------:|-------------|
| 6.1.1-4 | Infrastructure + Network + Security | DO | 16 | HIGH | `3B.8.1` + `3B.8.3` + `3B.8.4` |
| 6.1.6+8 | Database Ready + SSL | DO | 8 | MEDIUM | `3B.8.1` + `3B.3.6` + `3B.8.4` |
| 6.2.1 | CI Pipeline | DO | 8 | HIGH | `3B.8.1` §GitHub Actions |
| 6.2.2 | CD Pipeline | DO | 8 | HIGH | `3B.8.1` §deploy auto |
| 6.2.3-6 | Build/Deploy Scripts + Docs | DO | 13 | MEDIUM | `3B.8.1` + `3B.8.5` + `3B.8.7` |
| 6.3.1-2 | Staging Deploy + URL | DO | 7 | MEDIUM | `3B.8.1` + `3B.8.4` |
| 6.3.4 | Health Check staging | DO | 2 | LOW | `3B.4.2` §health |
| 6.3.3 | Migration Run staging | DB | 3 | LOW | `3B.3.6` §deploy |
| 6.4.1-3 | Smoke Tests + Sign-off | QA | 6 | MEDIUM | `3B.4.2` + `3B.5.3` |
| TL-S7 | Coordinación | TL | 2 | MEDIUM | — |
| AR-S7 | Integration Audit | AR | 2 | MEDIUM | — |
| CIERRE-S7 | Cierre Sprint S7 | TL | 2 | MEDIUM | — |
| APR-S7 | Aprobación PM | PM | 1 | LOW | — |

---

## 3. DoD — TL

### Gate M6 verificado:
- [ ] Staging live en 77.42.88.106 (verificar contra `3B.8.1`)
- [ ] Smoke tests OK — import → context → list (verificar contra `3B.5.3`)
- [ ] CI/CD activo — push → build → deploy automático (verificar contra `3B.8.1`)
- [ ] Health check OK en staging (verificar contra `3B.4.2`)
- [ ] **NUNCA** mover tarea a `task_approved`

---

## 4. REFERENCIAS

| Documento | Propósito |
|-----------|-----------|
| `3B.9.10_routing_index.md` | Índice de ruteo |
| `3B.8.1_infra_plan.md` | Arquitectura infra (DO) |
| `3B.8.4_network_config.md` | Networking + SSL |
| `3B.5.3_business_flows.md` | Critical paths (smoke tests) |

---

**FIN DEL HANDOFF TL S7**
