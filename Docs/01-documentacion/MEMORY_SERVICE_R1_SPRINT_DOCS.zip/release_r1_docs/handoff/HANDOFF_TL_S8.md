# HANDOFF TL: Memory Service — Sprint S8

**Documento:** HANDOFF_TL_S8.md
**Versión:** 2.0
**Sprint:** S8 — Deploy Prod + Operations Inicio
**Prerrequisitos:** Sprint S7 completado (APR-S7 ✅)

> **Nota:** S8 sin FE → 2 firmas (TL + AR). Último sprint de R1. Cierra Fase 6 + inicia Fase 7.

---

## 0. RESUMEN EJECUTIVO

- **DO (~36h):** Production deploy, monitoring dashboard + alerts, post-deploy report 24h, rollback plan completo
- **TL (~23h):** Operations setup — uptime/performance/error reports, support process + SLA, hotfix process

**Duración total:** ~62h
**Milestone M7:** Producción live, monitoring activo, rollback probado, equipo en operations

---

## 1. BRIEFS POR TAREA — CON RUTEO

### 1.1 DevOps Engineer — ~36h

#### 6.5.1-6 Production Deploy + URL + DNS + SSL + Release Notes + Log (13h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Deploy a producción, URL pública, DNS, SSL, release notes v1.0, deployment log |
| **Spec Source** | `3B.8.1_infra_plan.md` + `3B.8.4_network_config.md` + `3B.9.3` + `SPEC §scope` |
| **Decisiones** | D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.1`, `3B.8.4`, `3B.9.3`, `SPEC §scope`, deliverables `6.2.2`, `6.4.3` (smoke sign-off), `5.10.5` (UAT sign-off) |
| **Depende de** | SETUP-S8 |
| **Nota** | Gate previo obligatorio: smoke sign-off (6.4.3) + UAT sign-off (5.10.5) + security sign-off (5.8.7) |

#### 6.6.1-2 Monitoring Dashboard + Alerts (8h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Dashboard de métricas (uptime, CPU, memory) + alertas de caída |
| **Spec Source** | `3B.8.11_monitoring_strategy.md` |
| **Decisiones** | D-MEM-36, D-MEM-38 |
| **Docs que el agente debe leer** | `3B.8.11`, `3B.8.1`, `3B.8.10_sla_spec.md` |
| **Depende de** | 6.5.1-6 |

#### 6.6.6 Post-Deploy Report 24h (2h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Reporte de las primeras 24h en producción |
| **Spec Source** | `3B.8.11_monitoring_strategy.md` §reporte post-deploy |
| **Decisiones** | D-MEM-36 |
| **Docs que el agente debe leer** | `3B.8.11`, deliverable `6.5.1` |
| **Depende de** | 6.5.1-6 |

#### 6.7.1-5 Rollback Plan + Scripts + Tested + Runbook + Criteria (13h, HIGH)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Plan de rollback, scripts, validación en staging, runbook operativo, criterios de activación |
| **Spec Source** | `3B.8.7_backup_plan.md` + `3B.8.8_disaster_recovery.md` + `3B.3.6_migration_strategy.md` + `3B.8.10_sla_spec.md` |
| **Decisiones** | D-MEM-10 (migrations rollback), D-MEM-36, D-MEM-05 (SLA criteria) |
| **Docs que el agente debe leer** | `3B.8.7`, `3B.8.8`, `3B.3.6`, `3B.8.10`, `3B.8.11` |
| **Depende de** | SETUP-S8 |

---

### 1.2 TL — ~23h

#### 7.1.1-4 Uptime + Performance + Error + Weekly Reports (12h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | 4 reportes operativos: uptime por servicio, métricas p95 por endpoint, error digest, reporte semanal consolidado |
| **Spec Source** | `3B.8.11_monitoring_strategy.md` + `3B.8.10_sla_spec.md` + `3B.7.10_security_logging.md` |
| **Decisiones** | D-MEM-36, D-MEM-05 (SLA), D-MEM-30 (performance), D-MEM-38/08 (error codes) |
| **Docs que el agente debe leer** | `3B.8.11`, `3B.8.10`, `3B.7.10`, `3B.4.5_error_codes.md` |
| **Depende de** | 6.6.1-2 Monitoring Dashboard |

#### 7.2.1+3+4 Support Process + SLA Definitions + Metrics (7h, MEDIUM)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Proceso de soporte interno VTT, SLAs definidos, métricas de soporte |
| **Spec Source** | `SPEC §operaciones` + `3B.4.2_endpoints_list.md` + `3B.8.10_sla_spec.md` |
| **Decisiones** | D-MEM-05 (SLA) |
| **Docs que el agente debe leer** | `SPEC §operaciones`, `3B.8.10`, `3B.4.2` |
| **Depende de** | 6.5.1-6 Production Deploy |

#### 7.3.1+3 Hotfix Process + Bug Tracking (4h, LOW)

| Campo | Valor |
|-------|-------|
| **Qué producir** | Proceso de hotfix en producción + sistema de bug tracking en VTT |
| **Spec Source** | `3B.2.2_coding_standards.md` §hotfix |
| **Decisiones** | D-MEM-41 |
| **Docs que el agente debe leer** | `3B.2.2`, `3B.8.8_disaster_recovery.md` |
| **Depende de** | 6.5.1-6 Production Deploy |

---

## 2. TAREAS DEL SPRINT

| ID | Tarea | Agente | Horas | Complejidad | Spec Source |
|----|-------|--------|:-----:|:-----------:|-------------|
| 6.5.1-6 | Prod Deploy + URL + DNS + SSL + Notes + Log | DO | 13 | HIGH | `3B.8.1` + `3B.8.4` |
| 6.6.1-2 | Monitoring Dashboard + Alerts | DO | 8 | MEDIUM | `3B.8.11` |
| 6.6.6 | Post-Deploy Report 24h | DO | 2 | LOW | `3B.8.11` |
| 6.7.1-5 | Rollback Plan completo | DO | 13 | HIGH | `3B.8.7` + `3B.8.8` + `3B.8.10` |
| 7.1.1-4 | Ops Reports (uptime+perf+error+weekly) | TL | 12 | MEDIUM | `3B.8.11` + `3B.8.10` |
| 7.2.1+3+4 | Support Process + SLA + Metrics | TL | 7 | MEDIUM | `SPEC §ops` + `3B.8.10` |
| 7.3.1+3 | Hotfix Process + Bug Tracking | TL | 4 | LOW | `3B.2.2` + `3B.8.8` |
| TL-S8 | Release Sign-off | TL | 3 | MEDIUM | — |
| AR-S8 | Integration Audit | AR | 2 | MEDIUM | — |
| CIERRE-S8 | Cierre Sprint S8 (Release R1) | TL | 2 | MEDIUM | — |
| APR-S8 | Aprobación PM (Release R1) | PM | 1 | LOW | — |

---

## 3. DoD — TL

### Gate M7 verificado (Release R1):
- [ ] Producción live en 77.42.88.106 (verificar contra `3B.8.1`)
- [ ] Monitoring activo — dashboard + alerts (verificar contra `3B.8.11`)
- [ ] Rollback probado en staging (verificar contra `3B.8.8`)
- [ ] Equipo en operations — support + hotfix process documentados
- [ ] Post-deploy report 24h sin incidentes P0
- [ ] **NUNCA** mover tarea a `task_approved`

---

## 4. REFERENCIAS

| Documento | Propósito |
|-----------|-----------|
| `3B.9.10_routing_index.md` | Índice de ruteo |
| `3B.8.1_infra_plan.md` | Arquitectura prod |
| `3B.8.7_backup_plan.md` | Backup + rollback |
| `3B.8.8_disaster_recovery.md` | DR plan |
| `3B.8.10_sla_spec.md` | SLAs |
| `3B.8.11_monitoring_strategy.md` | Monitoring |

---

**FIN DEL HANDOFF TL S8**
