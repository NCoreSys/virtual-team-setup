# SETUP: Sprint S1 — Infra & BD Foundation

**Documento:** SETUP_S1.md
**Versión:** 2.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-12
**Sprint:** S1 — Infra & BD Foundation
**Propósito:** Instrucciones para crear estructura y tareas del Sprint S1 en VTT

---

## 0. RESUMEN EJECUTIVO

Este documento contiene las instrucciones para que TL configure el Sprint S1 en VTT. Al completar este setup:

- ✅ Release R1 verificado/creado
- ✅ Sprint S1 creado en VTT
- ✅ 5 Deliveries creados y vinculados a Sprint S1
- ✅ 18 tareas creadas y asociadas a sus Deliveries
- ✅ Dependencias configuradas
- ✅ Contexto documentado

**Tiempo estimado:** 2 horas
**Prerrequisito:** Phase 3B completada (MS-047 = task_completed ✅)

---

## 1. PRERREQUISITOS

| # | Prerrequisito | Estado |
|---|---------------|--------|
| 1 | Phase 3B completada | ⬜ |
| 2 | Acceso a VTT API | ⬜ |
| 3 | HANDOFF_TL_S1.md disponible | ⬜ |
| 4 | CLOSURE_S1.md disponible | ⬜ |

---

## 2. CONSTANTES DE SESIÓN

```python
import urllib.request, json, time, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://77.42.88.106:3000"
PROJECT_ID = "d0fc276d-e764-4a83-96e9-d65f086ed803"
PHASE_DEV = "c5f9f305-de20-4d09-b939-39a84654362c"

# Auth
req = urllib.request.Request(
    f'{BASE_URL}/api/auth/service-token',
    data=json.dumps({
        'userId': '92225290-6b6b-4c1f-a940-dcb4262507aa',
        'serviceKey': 'hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d'
    }).encode(),
    headers={'Content-Type': 'application/json'}, method='POST')
TOKEN = json.loads(urllib.request.urlopen(req).read())['data']['token']
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

# Agentes
TL = "92225290-6b6b-4c1f-a940-dcb4262507aa"
BE = "ebbe3cee-abed-4b3b-860d-0a81f632b08a"
DB = "6fae26f0-fc87-42d3-9a9e-eb6b1dbe6dd7"
DO = "322e3745-9756-4a7c-af11-44b33edef44d"
AR = "e9403c25-c1f8-4b64-b2ef-f447d53115e2"
PM_ID = "350831b2-e1ae-4dbe-b2eb-7e023ec2e103"

# Prioridades
PRI_HIGH = "1a617554-6319-4c56-826f-8ef49a0ff9cc"
PRI_MED  = "d0b619ef-27e7-42d8-8879-41030a602eed"
```

---

## 3. PASO 1: CREAR/VERIFICAR RELEASE R1

```python
# Verificar si ya existe R1
req = urllib.request.Request(
    f'{BASE_URL}/api/projects/{PROJECT_ID}/releases',
    headers=HEADERS)
releases = json.loads(urllib.request.urlopen(req).read())['data']
R1 = next((r for r in releases if r['name'] == 'R1'), None)

if not R1:
    body = {
        "name": "R1",
        "description": "Memory Service Release 1 — 8 sprints, 719h, Fases 4-7",
        "startDate": "2026-06-01T00:00:00Z",
        "endDate": "2026-09-20T00:00:00Z",
        "createdBy": TL
    }
    req = urllib.request.Request(
        f'{BASE_URL}/api/projects/{PROJECT_ID}/releases',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    R1 = json.loads(urllib.request.urlopen(req).read())['data']
    print(f"Release R1 CREADO: {R1['id']}")
else:
    print(f"Release R1 ya existe: {R1['id']}")

RELEASE_ID = R1['id']
```

**Registrar:**
```
RELEASE_ID: ________________________________
```

---

## 4. PASO 2: CREAR SPRINT S1

```python
body = {
    "number": 1,
    "name": "S1 — Infra & BD Foundation",
    "goal": "Containers UP, BD migrada con 29 entidades, AppError + Logging funcionales",
    "startDate": "2026-06-01T00:00:00Z",
    "endDate": "2026-06-14T00:00:00Z"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/releases/{RELEASE_ID}/sprints',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SPRINT_S1_ID = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SPRINT_S1_ID: {SPRINT_S1_ID}")
```

**Registrar:**
```
SPRINT_S1_ID: ________________________________
```

---

## 5. PASO 3: CREAR TAREA SETUP

```python
body = {
    "title": "SETUP-S1: Setup Sprint 1 — Infra & BD Foundation",
    "description": "Configuración inicial del Sprint S1. Crear Release, Sprint, Deliveries, tareas y dependencias.",
    "assigneeId": TL,
    "estimatedHours": 2,
    "priorityId": PRI_MED,
    "complexity": "MEDIUM",
    "category": "documentation"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
resp = json.loads(urllib.request.urlopen(req).read())
SETUP_ID = resp['data']['id']
print(f"SETUP_ID: {SETUP_ID}")
```

**Registrar:**
```
SETUP_ID: ________________________________
```

---

## 6. PASO 4: CREAR 5 DELIVERIES

Un Delivery por módulo/rol dentro del sprint. Las tareas heredan el sprint a través del Delivery.

```python
def create_delivery(name, order):
    body = {
        "phaseId": PHASE_DEV,
        "name": name,
        "order": order,
        "createdBy": TL
    }
    req = urllib.request.Request(
        f'{BASE_URL}/api/deliveries',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    return json.loads(urllib.request.urlopen(req).read())['data']['id']

DEL_DO  = create_delivery("DO-S1: Environment Setup",       1)
DEL_TL  = create_delivery("TL-S1: Dev Tooling",             2)
DEL_BE  = create_delivery("BE-S1: Foundation (Error+Log)",   3)
DEL_DB  = create_delivery("DB-S1: Migration + Schema",      4)
DEL_REV = create_delivery("REV-S1: Validación + Cierre",    5)

print(f"DEL_DO:  {DEL_DO}")
print(f"DEL_TL:  {DEL_TL}")
print(f"DEL_BE:  {DEL_BE}")
print(f"DEL_DB:  {DEL_DB}")
print(f"DEL_REV: {DEL_REV}")
```

**Registrar:**
```
DEL_DO:  ________________________________
DEL_TL:  ________________________________
DEL_BE:  ________________________________
DEL_DB:  ________________________________
DEL_REV: ________________________________
```

---

## 7. PASO 5: VINCULAR DELIVERIES AL SPRINT S1

> **CRÍTICO:** Las tareas NO tienen campo `sprintId` directo. Heredan el sprint a través del Delivery. Sin este paso, las tareas quedan sin sprint visible en el dashboard.

```python
def link_delivery_to_sprint(delivery_id):
    body = {"sprintId": SPRINT_S1_ID}
    req = urllib.request.Request(
        f'{BASE_URL}/api/deliveries/{delivery_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
    urllib.request.urlopen(req)
    time.sleep(0.05)

for d in [DEL_DO, DEL_TL, DEL_BE, DEL_DB, DEL_REV]:
    link_delivery_to_sprint(d)
print("Deliveries vinculados a Sprint S1 ✅")
```

---

## 8. PASO 6: CREAR TAREAS DO (Environment Setup)

```python
tasks_do = [
    ("4.1.1", "Development Environment", 5, "MEDIUM", "3B.8.1 Infra Plan (completado ✅)"),
    ("4.1.2", "Environment Setup Guide", 3, "LOW", "4.1.1"),
    ("4.1.3", "Environment Variables", 3, "LOW", "3B.8.5 Env Matrix (completado ✅)"),
    ("4.1.4", "Docker Compose", 5, "MEDIUM", "3B.8.1 Infra Plan (completado ✅)"),
    ("4.1.5", "Makefile/Scripts", 3, "LOW", "4.1.4"),
]

do_ids = {}
for cat_id, name, hours, complexity, deps in tasks_do:
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (ID catálogo: {cat_id})\nSprint: S1\nRol: DO\nEstimación: {hours}h / {hours} SP\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": DO,
        "estimatedHours": hours,
        "priorityId": PRI_MED,
        "complexity": complexity,
        "category": "deployment"
    }
    req = urllib.request.Request(
        f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    resp = json.loads(urllib.request.urlopen(req).read())
    do_ids[cat_id] = resp['data']['id']
    print(f"T_{cat_id}: {do_ids[cat_id]}")
    time.sleep(0.1)

T_4_1_1 = do_ids["4.1.1"]
T_4_1_2 = do_ids["4.1.2"]
T_4_1_3 = do_ids["4.1.3"]
T_4_1_4 = do_ids["4.1.4"]
T_4_1_5 = do_ids["4.1.5"]
```

**Registrar:**
```
T_4_1_1: ________________________________
T_4_1_2: ________________________________
T_4_1_3: ________________________________
T_4_1_4: ________________________________
T_4_1_5: ________________________________
```

---

## 9. PASO 7: CREAR TAREAS TL (Dev Tooling)

```python
tasks_tl = [
    ("4.1.6",  "IDE Configuration",        2, "LOW", "—"),
    ("4.1.8",  "Git Configuration",         2, "LOW", "—"),
    ("4.1.9",  "Linter Configuration",      2, "LOW", "3B.2.1 Folder Structure (completado ✅)"),
    ("4.1.10", "Formatter Configuration",   2, "LOW", "3B.2.1 Folder Structure (completado ✅)"),
    ("4.1.7",  "Pre-commit Hooks",          2, "LOW", "4.1.9 Linter, 4.1.10 Formatter"),
]

tl_ids = {}
for cat_id, name, hours, complexity, deps in tasks_tl:
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (ID catálogo: {cat_id})\nSprint: S1\nRol: TL\nEstimación: {hours}h / {hours} SP\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": TL,
        "estimatedHours": hours,
        "priorityId": PRI_MED,
        "complexity": complexity,
        "category": "documentation"
    }
    req = urllib.request.Request(
        f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    resp = json.loads(urllib.request.urlopen(req).read())
    tl_ids[cat_id] = resp['data']['id']
    print(f"T_{cat_id}: {tl_ids[cat_id]}")
    time.sleep(0.1)

T_4_1_6  = tl_ids["4.1.6"]
T_4_1_7  = tl_ids["4.1.7"]
T_4_1_8  = tl_ids["4.1.8"]
T_4_1_9  = tl_ids["4.1.9"]
T_4_1_10 = tl_ids["4.1.10"]
```

**Registrar:**
```
T_4_1_6:  ________________________________
T_4_1_7:  ________________________________
T_4_1_8:  ________________________________
T_4_1_9:  ________________________________
T_4_1_10: ________________________________
```

---

## 10. PASO 8: CREAR TAREAS BE (Error Handling + Logging)

```python
tasks_be = [
    ("4.3.14", "Error Handling — AppError + MEM-ERR-xxx", 8, "HIGH",
     "3B.4.5 Error Codes (completado ✅)\nDetalle: AppError class + jerarquía MEM-ERR-xxx según 3B.4.5"),
    ("4.3.15", "Logging — Winston + correlationId", 5, "MEDIUM",
     "—\nDetalle: Winston logger + correlationId + structured logs JSON"),
]

be_ids = {}
for cat_id, name, hours, complexity, deps in tasks_be:
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (ID catálogo: {cat_id})\nSprint: S1\nRol: BE\nEstimación: {hours}h / {hours} SP\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": BE,
        "estimatedHours": hours,
        "priorityId": PRI_HIGH if complexity == "HIGH" else PRI_MED,
        "complexity": complexity,
        "category": "development"
    }
    req = urllib.request.Request(
        f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    resp = json.loads(urllib.request.urlopen(req).read())
    be_ids[cat_id] = resp['data']['id']
    print(f"T_{cat_id}: {be_ids[cat_id]}")
    time.sleep(0.1)

T_4_3_14 = be_ids["4.3.14"]
T_4_3_15 = be_ids["4.3.15"]
```

**Registrar:**
```
T_4_3_14: ________________________________
T_4_3_15: ________________________________
```

---

## 11. PASO 9: CREAR TAREAS DB (Migration + Schema + Constraints)

```python
tasks_db = [
    ("4.2.1", "Initial Migration — 29 entidades", 8, "HIGH",
     "3B.3.2 Schema Prisma (completado ✅)\nDetalle: 29 entidades del ERD, 10 catálogos, constraints básicos"),
    ("4.2.2", "Schema Migrations Setup", 8, "HIGH",
     "4.2.1\nDetalle: prisma migrate dev workflow, naming conventions, rollback docs"),
    ("4.2.6", "Constraints — unique en Turn/Block", 3, "LOW",
     "4.2.1\nDetalle: @@unique constraints en Turn y Block según D-MEM-41"),
]

db_ids = {}
for cat_id, name, hours, complexity, deps in tasks_db:
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (ID catálogo: {cat_id})\nSprint: S1\nRol: DB\nEstimación: {hours}h / {hours} SP\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": DB,
        "estimatedHours": hours,
        "priorityId": PRI_HIGH if complexity == "HIGH" else PRI_MED,
        "complexity": complexity,
        "category": "development"
    }
    req = urllib.request.Request(
        f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    resp = json.loads(urllib.request.urlopen(req).read())
    db_ids[cat_id] = resp['data']['id']
    print(f"T_{cat_id}: {db_ids[cat_id]}")
    time.sleep(0.1)

T_4_2_1 = db_ids["4.2.1"]
T_4_2_2 = db_ids["4.2.2"]
T_4_2_6 = db_ids["4.2.6"]
```

**Registrar:**
```
T_4_2_1: ________________________________
T_4_2_2: ________________________________
T_4_2_6: ________________________________
```

---

## 12. PASO 10: CREAR TAREAS DE VALIDACIÓN + CIERRE + APR

```python
# TL-S1-CR: Code Review
body = {
    "title": "TL-S1-CR: Code Review PRs Sprint S1",
    "description": "Revisar PRs de DO, BE, DB para Sprint S1.\nUsar CODE_REVIEW_GUIDE.md como referencia.",
    "assigneeId": TL,
    "estimatedHours": 3,
    "priorityId": PRI_MED,
    "complexity": "MEDIUM",
    "category": "review"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
TL_S1_CR = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"TL_S1_CR: {TL_S1_CR}")
time.sleep(0.1)

# AR-S1: Integration Audit
body = {
    "title": "AR-S1: Integration Audit Sprint S1",
    "description": "Auditar: schema Prisma vs ERD 3B.3.1, error codes vs 3B.4.5, Docker compose vs 3B.8.1.\nUsar INTEGRATION_AUDIT_CHECKLIST.md como referencia.",
    "assigneeId": AR,
    "estimatedHours": 2,
    "priorityId": PRI_MED,
    "complexity": "MEDIUM",
    "category": "review"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
AR_S1 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"AR_S1: {AR_S1}")
time.sleep(0.1)

# CIERRE-S1
body = {
    "title": "CIERRE-S1: Cierre Sprint 1 — Infra & BD Foundation",
    "description": "Tarea de cierre formal del Sprint S1. Requiere firmas TL + AR. Usar CLOSURE_S1.md como guía.",
    "assigneeId": TL,
    "estimatedHours": 2,
    "priorityId": PRI_HIGH,
    "complexity": "MEDIUM",
    "category": "review"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
CIERRE_S1 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"CIERRE_S1: {CIERRE_S1}")
time.sleep(0.1)

# APR-S1: Aprobación PM
body = {
    "title": "APR-S1: Aprobación final Sprint S1",
    "description": "Aprobación PM tras 2 firmas (TL + AR) y verificación M1.",
    "assigneeId": PM_ID,
    "estimatedHours": 1,
    "priorityId": PRI_HIGH,
    "complexity": "LOW",
    "category": "review"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
APR_S1 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"APR_S1: {APR_S1}")
```

**Registrar:**
```
TL_S1_CR:  ________________________________
AR_S1:     ________________________________
CIERRE_S1: ________________________________
APR_S1:    ________________________________
```

---

## 13. PASO 11: ASOCIAR TAREAS A DELIVERIES

> **CRÍTICO:** Sin este paso, las tareas no aparecen en el sprint. La asociación Task → Delivery → Sprint es la cadena que las hace visibles en el dashboard y métricas MGP.

```python
def assign_task_to_delivery(delivery_id, task_id):
    body = {"assignedBy": TL}
    req = urllib.request.Request(
        f'{BASE_URL}/api/deliveries/{delivery_id}/tasks/{task_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

# DO (5 tareas) → DEL_DO
for t in [T_4_1_1, T_4_1_2, T_4_1_3, T_4_1_4, T_4_1_5]:
    assign_task_to_delivery(DEL_DO, t)
print("DO → DEL_DO ✅")

# TL Tooling (5 tareas) → DEL_TL
for t in [T_4_1_6, T_4_1_7, T_4_1_8, T_4_1_9, T_4_1_10]:
    assign_task_to_delivery(DEL_TL, t)
print("TL → DEL_TL ✅")

# BE (2 tareas) → DEL_BE
for t in [T_4_3_14, T_4_3_15]:
    assign_task_to_delivery(DEL_BE, t)
print("BE → DEL_BE ✅")

# DB (3 tareas) → DEL_DB
for t in [T_4_2_1, T_4_2_2, T_4_2_6]:
    assign_task_to_delivery(DEL_DB, t)
print("DB → DEL_DB ✅")

# Validación + Cierre + APR (4 tareas) → DEL_REV
for t in [TL_S1_CR, AR_S1, CIERRE_S1, APR_S1]:
    assign_task_to_delivery(DEL_REV, t)
print("REV → DEL_REV ✅")

# SETUP también al DEL_REV
assign_task_to_delivery(DEL_REV, SETUP_ID)
print("SETUP → DEL_REV ✅")

print("Todas las tareas asociadas a Deliveries ✅")
```

---

## 14. PASO 12: REGISTRAR DEPENDENCIAS

```python
def add_dep(task_id, depends_on_id):
    body = {"dependsOnTaskId": depends_on_id}
    req = urllib.request.Request(
        f'{BASE_URL}/api/tasks/{task_id}/dependencies',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

print("Registrando dependencias...")

# DO chain
add_dep(T_4_1_1, SETUP_ID)
add_dep(T_4_1_2, T_4_1_1)
add_dep(T_4_1_3, SETUP_ID)
add_dep(T_4_1_4, SETUP_ID)
add_dep(T_4_1_5, T_4_1_4)

# TL chain
add_dep(T_4_1_6, SETUP_ID)
add_dep(T_4_1_8, SETUP_ID)
add_dep(T_4_1_9, SETUP_ID)
add_dep(T_4_1_10, SETUP_ID)
add_dep(T_4_1_7, T_4_1_9)
add_dep(T_4_1_7, T_4_1_10)

# BE chain
add_dep(T_4_3_14, SETUP_ID)
add_dep(T_4_3_15, SETUP_ID)

# DB chain (DB necesita Docker Compose para PostgreSQL)
add_dep(T_4_2_1, T_4_1_4)
add_dep(T_4_2_2, T_4_2_1)
add_dep(T_4_2_6, T_4_2_1)

# Validación chain
add_dep(TL_S1_CR, T_4_1_5)
add_dep(TL_S1_CR, T_4_1_7)
add_dep(TL_S1_CR, T_4_3_14)
add_dep(TL_S1_CR, T_4_3_15)
add_dep(TL_S1_CR, T_4_2_2)
add_dep(TL_S1_CR, T_4_2_6)
add_dep(AR_S1, TL_S1_CR)
add_dep(CIERRE_S1, AR_S1)
add_dep(APR_S1, CIERRE_S1)

print("Dependencias registradas ✅")
```

---

## 15. PASO 13: GENERAR CONTEXTO

Crear documento **CONTEXTO_S1.md**:

```markdown
# CONTEXTO: Sprint S1 — Infra & BD Foundation

**Generado por:** TL-Agent
**Fecha:** [FECHA]

## 1. Estructura VTT

| Entidad | ID |
|---------|-----|
| Release R1 | {RELEASE_ID} |
| Sprint S1 | {SPRINT_S1_ID} |

## 2. Deliveries

| Delivery | ID |
|----------|-----|
| DO-S1: Environment Setup | {DEL_DO} |
| TL-S1: Dev Tooling | {DEL_TL} |
| BE-S1: Foundation | {DEL_BE} |
| DB-S1: Migration + Schema | {DEL_DB} |
| REV-S1: Validación + Cierre | {DEL_REV} |

## 3. Tareas

| ID Catálogo | Título | VTT ID | Rol | Horas | Delivery |
|-------------|--------|--------|:---:|:-----:|----------|
| 4.1.1 | Development Environment | {T_4_1_1} | DO | 5 | DEL_DO |
| 4.1.2 | Environment Setup Guide | {T_4_1_2} | DO | 3 | DEL_DO |
| 4.1.3 | Environment Variables | {T_4_1_3} | DO | 3 | DEL_DO |
| 4.1.4 | Docker Compose | {T_4_1_4} | DO | 5 | DEL_DO |
| 4.1.5 | Makefile/Scripts | {T_4_1_5} | DO | 3 | DEL_DO |
| 4.1.6 | IDE Configuration | {T_4_1_6} | TL | 2 | DEL_TL |
| 4.1.7 | Pre-commit Hooks | {T_4_1_7} | TL | 2 | DEL_TL |
| 4.1.8 | Git Configuration | {T_4_1_8} | TL | 2 | DEL_TL |
| 4.1.9 | Linter Configuration | {T_4_1_9} | TL | 2 | DEL_TL |
| 4.1.10 | Formatter Configuration | {T_4_1_10} | TL | 2 | DEL_TL |
| 4.3.14 | Error Handling | {T_4_3_14} | BE | 8 | DEL_BE |
| 4.3.15 | Logging | {T_4_3_15} | BE | 5 | DEL_BE |
| 4.2.1 | Initial Migration | {T_4_2_1} | DB | 8 | DEL_DB |
| 4.2.2 | Schema Migrations | {T_4_2_2} | DB | 8 | DEL_DB |
| 4.2.6 | Constraints | {T_4_2_6} | DB | 3 | DEL_DB |
| — | TL Code Review | {TL_S1_CR} | TL | 3 | DEL_REV |
| — | AR Integration Audit | {AR_S1} | AR | 2 | DEL_REV |
| — | CIERRE-S1 | {CIERRE_S1} | TL | 2 | DEL_REV |
| — | APR-S1 | {APR_S1} | PM | 1 | DEL_REV |

## 4. Resumen

| Categoría | Tareas | Horas |
|-----------|:------:|:-----:|
| DO (Environment) | 5 | 19h |
| TL (Dev Tooling) | 5 | 10h |
| BE (Error + Logging) | 2 | 13h |
| DB (Migration + Schema) | 3 | 19h |
| Validación + Cierre + APR | 4 | 8h |
| **Total** | **19** | **69h** |
```

---

## 16. CHECKLIST DE VERIFICACIÓN

> **Nota:** El TL NO marca SETUP-S1 como completado automáticamente. Lo hace tras verificar el review gate y subir attachments.

```markdown
## Setup S1 — Verificación Final

### Estructura VTT
[ ] Release R1 existe
[ ] Sprint S1 creado y vinculado a R1
[ ] 5 Deliveries creados
[ ] 5 Deliveries vinculados a Sprint S1

### Tareas DO (5) → DEL_DO
[ ] [4.1.1] Development Environment
[ ] [4.1.2] Environment Setup Guide
[ ] [4.1.3] Environment Variables
[ ] [4.1.4] Docker Compose
[ ] [4.1.5] Makefile/Scripts

### Tareas TL (5) → DEL_TL
[ ] [4.1.6] IDE Configuration
[ ] [4.1.7] Pre-commit Hooks
[ ] [4.1.8] Git Configuration
[ ] [4.1.9] Linter Configuration
[ ] [4.1.10] Formatter Configuration

### Tareas BE (2) → DEL_BE
[ ] [4.3.14] Error Handling
[ ] [4.3.15] Logging

### Tareas DB (3) → DEL_DB
[ ] [4.2.1] Initial Migration
[ ] [4.2.2] Schema Migrations
[ ] [4.2.6] Constraints

### Validación (4) → DEL_REV
[ ] TL-S1-CR: Code Review
[ ] AR-S1: Integration Audit
[ ] CIERRE-S1
[ ] APR-S1: Aprobación PM

### Asociaciones Task → Delivery
[ ] 5 tareas DO → DEL_DO
[ ] 5 tareas TL → DEL_TL
[ ] 2 tareas BE → DEL_BE
[ ] 3 tareas DB → DEL_DB
[ ] 4 tareas REV → DEL_REV
[ ] SETUP → DEL_REV

### Dependencias
[ ] DO: SETUP → 4.1.1 → 4.1.2; SETUP → 4.1.3; SETUP → 4.1.4 → 4.1.5
[ ] TL: SETUP → 4.1.6, 4.1.8, 4.1.9, 4.1.10; 4.1.9+4.1.10 → 4.1.7
[ ] BE: SETUP → 4.3.14, 4.3.15
[ ] DB: 4.1.4 → 4.2.1 → 4.2.2, 4.2.6
[ ] Val: deliverables → TL Review → AR Audit → CIERRE → APR

### Documentación
[ ] CONTEXTO_S1.md generado
[ ] Agentes notificados
```

---

## 17. HISTORIAL DE VERSIONES

| Versión | Fecha | Autor | Cambios |
|---------|-------|-------|---------|
| 1.0 | 2026-05-12 | PJM-Agent | Versión inicial — sin Release/Sprint/Deliveries |
| 2.0 | 2026-05-12 | PJM-Agent | Corregido: agregado Release R1, Sprint S1, 5 Deliveries, vinculación Delivery→Sprint, asociación Task→Delivery, APR-S1. Removido auto-completar SETUP. |

---

**FIN DEL SETUP S1**
