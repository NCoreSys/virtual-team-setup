# SETUP: Sprint S4 — FE Features + Context SLA

**Documento:** SETUP_S4.md
**Versión:** 1.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-12
**Sprint:** S4 — FE Features + Context SLA
**Propósito:** Instrucciones para crear estructura y tareas del Sprint S4 en VTT

---

## 0. RESUMEN EJECUTIVO

Al completar este setup:

- ✅ Sprint S4 creado en VTT (vinculado a Release R1)
- ✅ 4 Deliveries creados y vinculados a Sprint S4
- ✅ 19 tareas creadas y asociadas (14 deliverables + 1 TL + 4 validación/cierre)
- ✅ Dependencias configuradas (cross-sprint con S3 + intra-sprint)

**Último sprint de Fase 4 (Development).** Milestone M4 valida SLA GET /context <500ms.

**Tiempo estimado:** 1.5 horas
**Prerrequisito:** Sprint S3 completado (CIERRE-S3 = task_completed ✅)

---

## 1. PRERREQUISITOS

| # | Prerrequisito | Estado |
|---|---------------|--------|
| 1 | Sprint S3 cerrado (APR-S3 completado) | ⬜ |
| 2 | RELEASE_ID y CONTEXTO_S3.md disponibles | ⬜ |
| 3 | IDs de tareas S3 para dependencias cross-sprint | ⬜ |
| 4 | HANDOFF_TL_S4.md y CLOSURE_S4.md disponibles | ⬜ |

---

## 2. CONSTANTES DE SESIÓN

```python
import urllib.request, json, time, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://77.42.88.106:3000"
PROJECT_ID = "d0fc276d-e764-4a83-96e9-d65f086ed803"
PHASE_DEV = "c5f9f305-de20-4d09-b939-39a84654362c"

# Auth
req = urllib.request.Request(
    f'{BASE_URL}/api/auth/service-token',
    data=json.dumps({
        'userId': '92225290-6b6b-4c1f-a940-dcb4262507aa',
        'serviceKey': 'hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d'
    }).encode(),
    headers={'Content-Type': 'application/json'}, method='POST')
TOKEN = json.loads(urllib.request.urlopen(req).read())['data']['token']
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

# Agentes
TL = "92225290-6b6b-4c1f-a940-dcb4262507aa"
BE = "ebbe3cee-abed-4b3b-860d-0a81f632b08a"
FE = "d23c9cd9-a156-433b-8900-94add5488eec"
AR = "e9403c25-c1f8-4b64-b2ef-f447d53115e2"
DL = "b3a09269-cded-468c-a475-15a48f203cb0"
PM_ID = "350831b2-e1ae-4dbe-b2eb-7e023ec2e103"

PRI_HIGH = "1a617554-6319-4c56-826f-8ef49a0ff9cc"
PRI_MED  = "d0b619ef-27e7-42d8-8879-41030a602eed"

# === RECUPERAR DE CONTEXTO_S3 ===
RELEASE_ID  = "________________________________"
T_4_4_1_S3  = "________________________________"  # [4.4.1] Components (S3)
T_4_4_3_S3  = "________________________________"  # [4.4.3] Layouts (S3)
T_4_4_4_S3  = "________________________________"  # [4.4.4] Hooks (S3)
T_4_4_5_S3  = "________________________________"  # [4.4.5] State Management (S3)
T_4_4_6_S3  = "________________________________"  # [4.4.6] API Client FE (S3)
T_4_3_1_S3  = "________________________________"  # [4.3.1] API Endpoints (S3)
T_4_5_1_S3  = "________________________________"  # [4.5.1] Integration Code (S3)
T_4_3_2_S2  = "________________________________"  # [4.3.2] Services (S2)
CIERRE_S3   = "________________________________"
```

---

## 3. PASO 1: CREAR SPRINT S4

```python
body = {
    "number": 4,
    "name": "S4 — FE Features + Context SLA",
    "goal": "GET /context <500ms p95 en staging, 8 pantallas FE renderizan, unit tests BE passing",
    "startDate": "2026-07-13T00:00:00Z",
    "endDate": "2026-07-26T00:00:00Z"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/releases/{RELEASE_ID}/sprints',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SPRINT_S4_ID = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SPRINT_S4_ID: {SPRINT_S4_ID}")
```

**Registrar:**
```
SPRINT_S4_ID: ________________________________
```

---

## 4. PASO 2: CREAR TAREA SETUP

```python
body = {
    "title": "SETUP-S4: Setup Sprint 4 — FE Features + Context SLA",
    "description": "Configuración del Sprint S4. Último sprint de Fase 4.",
    "assigneeId": TL, "estimatedHours": 1, "priorityId": PRI_MED,
    "complexity": "LOW", "category": "documentation"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SETUP_S4 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SETUP_S4: {SETUP_S4}")
```

**Registrar:**
```
SETUP_S4: ________________________________
```

---

## 5. PASO 3: CREAR 4 DELIVERIES

```python
def create_delivery(name, order):
    body = {"phaseId": PHASE_DEV, "name": name, "order": order, "createdBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    return json.loads(urllib.request.urlopen(req).read())['data']['id']

DEL_FE_S4  = create_delivery("FE-S4: Pages + Tests + Responsive",          1)
DEL_BE_S4  = create_delivery("BE-S4: Tests + Docs + Error Handling Integ", 2)
DEL_TL_S4  = create_delivery("TL-S4: Reviews + SLA Validation",            3)
DEL_REV_S4 = create_delivery("REV-S4: Validación + Cierre",                4)

print(f"DEL_FE_S4:  {DEL_FE_S4}")
print(f"DEL_BE_S4:  {DEL_BE_S4}")
print(f"DEL_TL_S4:  {DEL_TL_S4}")
print(f"DEL_REV_S4: {DEL_REV_S4}")
```

**Registrar:**
```
DEL_FE_S4:  ________________________________
DEL_BE_S4:  ________________________________
DEL_TL_S4:  ________________________________
DEL_REV_S4: ________________________________
```

---

## 6. PASO 4: VINCULAR DELIVERIES AL SPRINT S4

```python
for d in [DEL_FE_S4, DEL_BE_S4, DEL_TL_S4, DEL_REV_S4]:
    body = {"sprintId": SPRINT_S4_ID}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{d}',
        data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
    urllib.request.urlopen(req)
    time.sleep(0.05)
print("Deliveries vinculados a Sprint S4 ✅")
```

---

## 7. PASO 5: CREAR TAREAS FE (Pages + Tests + Responsive)

```python
tasks_fe = [
    ("4.4.2", "Pages — 8 pantallas (Dashboard, AgentTimeline, ConversationsList, ConversationViewer, CostReportProject, CostReportAgent, ImportManual, Health)", 13, "HIGH",
     "4.4.1 Components (S3), 4.4.6 API Client (S3), 4.4.3 Layouts (S3)\nDetalle: 8 pantallas con data fetching, cursor-based pagination, filtros, renders JSONL"),
    ("4.4.9", "Utils FE", 2, "LOW",
     "SETUP-S4\nDetalle: Utilidades frontend: formatters, date helpers, path utils"),
    ("4.4.15", "Responsive Implementation", 5, "MEDIUM",
     "4.4.1 Components (S3), 4.4.3 Layouts (S3)\nDetalle: Media queries + breakpoints para 8 pantallas según 3A.4.9"),
    ("4.4.10", "Unit Tests FE", 5, "MEDIUM",
     "4.4.4 Hooks (S3), 4.4.9 Utils\nDetalle: Tests unitarios de hooks, utils, state management"),
    ("4.4.11", "Component Tests", 5, "MEDIUM",
     "4.4.1 Components (S3)\nDetalle: Testing Library — tests de componentes con props, events, renders"),
    ("4.4.13", "Frontend README", 2, "LOW",
     "4.4.2 Pages\nDetalle: Documentación del frontend: setup, estructura, componentes, hooks"),
]

fe_ids = {}
for cat_id, name, hours, complexity, deps in tasks_fe:
    pri = PRI_HIGH if complexity in ("HIGH", "VERY HIGH") else PRI_MED
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (ID catálogo: {cat_id})\nSprint: S4\nRol: FE\nEstimación: {hours}h / {hours} SP\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": FE, "estimatedHours": hours, "priorityId": pri,
        "complexity": complexity, "category": "development"
    }
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    fe_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {fe_ids[cat_id]}")
    time.sleep(0.1)

T_4_4_2  = fe_ids["4.4.2"]
T_4_4_9  = fe_ids["4.4.9"]
T_4_4_15 = fe_ids["4.4.15"]
T_4_4_10 = fe_ids["4.4.10"]
T_4_4_11 = fe_ids["4.4.11"]
T_4_4_13 = fe_ids["4.4.13"]
```

**Registrar:**
```
T_4_4_2:  ________________________________
T_4_4_9:  ________________________________
T_4_4_15: ________________________________
T_4_4_10: ________________________________
T_4_4_11: ________________________________
T_4_4_13: ________________________________
```

---

## 8. PASO 6: CREAR TAREAS BE (Tests + Docs + Error Handling Integ)

```python
tasks_be = [
    ("4.5.8", "Error Handling Integration", 5, "MEDIUM",
     "4.5.1 Integration Code (S3)\nDetalle: Error handling específico para integraciones externas (Runtime, PB, HM)"),
    ("4.5.9", "Retry Logic", 5, "MEDIUM",
     "4.5.8\nDetalle: Retry con backoff exponencial para integraciones fallidas"),
    ("4.5.6", "Integration Tests", 8, "HIGH",
     "4.5.1 Integration Code (S3)\nDetalle: Tests de integración para 3 integraciones externas + contratos"),
    ("4.5.7", "Integration Docs", 3, "LOW",
     "4.5.1 Integration Code (S3)\nDetalle: Documentación de cada integración: contrato, auth, error handling, retry"),
    ("4.3.11", "API Documentation — Swagger", 5, "MEDIUM",
     "4.3.1 API Endpoints (S3)\nDetalle: Swagger UI auto-generado desde decorators. 11 endpoints documentados"),
    ("4.3.12", "Postman Collection — actualizada", 3, "LOW",
     "4.3.1 API Endpoints (S3), 3B.4.10 Postman (completado ✅)\nDetalle: Collection actualizada con endpoints reales + examples"),
    ("4.3.9", "Unit Tests BE", 8, "HIGH",
     "4.3.2 Services (S2)\nDetalle: Tests unitarios de 5 services + repositories + middlewares. Target: ≥80% coverage"),
]

be_ids = {}
for cat_id, name, hours, complexity, deps in tasks_be:
    pri = PRI_HIGH if complexity in ("HIGH", "VERY HIGH") else PRI_MED
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (ID catálogo: {cat_id})\nSprint: S4\nRol: BE\nEstimación: {hours}h / {hours} SP\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": BE, "estimatedHours": hours, "priorityId": pri,
        "complexity": complexity, "category": "development"
    }
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    be_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {be_ids[cat_id]}")
    time.sleep(0.1)

T_4_5_8  = be_ids["4.5.8"]
T_4_5_9  = be_ids["4.5.9"]
T_4_5_6  = be_ids["4.5.6"]
T_4_5_7  = be_ids["4.5.7"]
T_4_3_11 = be_ids["4.3.11"]
T_4_3_12 = be_ids["4.3.12"]
T_4_3_9  = be_ids["4.3.9"]
```

**Registrar:**
```
T_4_5_8:  ________________________________
T_4_5_9:  ________________________________
T_4_5_6:  ________________________________
T_4_5_7:  ________________________________
T_4_3_11: ________________________________
T_4_3_12: ________________________________
T_4_3_9:  ________________________________
```

---

## 9. PASO 7: CREAR TAREAS TL + VALIDACIÓN + CIERRE + APR

```python
# TL-S4-REV
body = {
    "title": "TL-S4-REV: Reviews + SLA Validation Sprint S4",
    "description": "Revisar PRs BE y FE. Validar GET /context <500ms p95 en dev local. Último gate de Fase 4.",
    "assigneeId": TL, "estimatedHours": 4, "priorityId": PRI_HIGH,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
TL_S4_REV = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"TL_S4_REV: {TL_S4_REV}")
time.sleep(0.1)

# AR-S4
body = {
    "title": "AR-S4: Integration Audit Sprint S4",
    "description": "Auditar: 8 pantallas vs wireframes, SLA <500ms, unit tests coverage ≥80%, integration tests vs 3B.1.6.",
    "assigneeId": AR, "estimatedHours": 3, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
AR_S4 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"AR_S4: {AR_S4}")
time.sleep(0.1)

# DL-S4-REV
body = {
    "title": "DL-S4-REV: Visual Review 8 Pantallas Sprint S4",
    "description": "DL revisa 8 pantallas vs mockups 3A.5.x. Responsive vs 3A.4.9 breakpoints.",
    "assigneeId": DL, "estimatedHours": 3, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
DL_S4_REV = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"DL_S4_REV: {DL_S4_REV}")
time.sleep(0.1)

# CIERRE-S4
body = {
    "title": "CIERRE-S4: Cierre Sprint 4 — FE Features + Context SLA (Fin Fase 4)",
    "description": "Cierre formal S4 y Fase 4 Development. Requiere firmas TL + AR + DL. Usar CLOSURE_S4.md.",
    "assigneeId": TL, "estimatedHours": 2, "priorityId": PRI_HIGH,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
CIERRE_S4 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"CIERRE_S4: {CIERRE_S4}")
time.sleep(0.1)

# APR-S4
body = {
    "title": "APR-S4: Aprobación final Sprint S4 (Fin Fase 4)",
    "description": "Aprobación PM tras firmas TL + AR + DL y verificación M4. Cierra Fase 4 Development.",
    "assigneeId": PM_ID, "estimatedHours": 1, "priorityId": PRI_HIGH,
    "complexity": "LOW", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEV}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
APR_S4 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"APR_S4: {APR_S4}")
```

**Registrar:**
```
TL_S4_REV: ________________________________
AR_S4:     ________________________________
DL_S4_REV: ________________________________
CIERRE_S4: ________________________________
APR_S4:    ________________________________
```

---

## 10. PASO 8: ASOCIAR TAREAS A DELIVERIES

```python
def assign_task_to_delivery(delivery_id, task_id):
    body = {"assignedBy": TL}
    req = urllib.request.Request(
        f'{BASE_URL}/api/deliveries/{delivery_id}/tasks/{task_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

# FE (6 tareas) → DEL_FE_S4
for t in [T_4_4_2, T_4_4_9, T_4_4_15, T_4_4_10, T_4_4_11, T_4_4_13]:
    assign_task_to_delivery(DEL_FE_S4, t)
print("FE → DEL_FE_S4 ✅")

# BE (7 tareas) → DEL_BE_S4
for t in [T_4_5_8, T_4_5_9, T_4_5_6, T_4_5_7, T_4_3_11, T_4_3_12, T_4_3_9]:
    assign_task_to_delivery(DEL_BE_S4, t)
print("BE → DEL_BE_S4 ✅")

# TL (1 tarea) → DEL_TL_S4
assign_task_to_delivery(DEL_TL_S4, TL_S4_REV)
print("TL → DEL_TL_S4 ✅")

# REV (4 tareas + SETUP) → DEL_REV_S4
for t in [AR_S4, DL_S4_REV, CIERRE_S4, APR_S4, SETUP_S4]:
    assign_task_to_delivery(DEL_REV_S4, t)
print("REV → DEL_REV_S4 ✅")

print("Todas las tareas asociadas a Deliveries ✅")
```

---

## 11. PASO 9: REGISTRAR DEPENDENCIAS

```python
def add_dep(task_id, depends_on_id):
    body = {"dependsOnTaskId": depends_on_id}
    req = urllib.request.Request(f'{BASE_URL}/api/tasks/{task_id}/dependencies',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

print("Registrando dependencias S4...")

# === CROSS-SPRINT: S3 → S4 ===
add_dep(SETUP_S4, CIERRE_S3)

# === FE chain ===
add_dep(T_4_4_2, T_4_4_1_S3)       # Pages ← Components (S3)
add_dep(T_4_4_2, T_4_4_6_S3)       # Pages ← API Client (S3)
add_dep(T_4_4_2, T_4_4_3_S3)       # Pages ← Layouts (S3)
add_dep(T_4_4_9, SETUP_S4)         # Utils ← SETUP
add_dep(T_4_4_15, T_4_4_2)         # Responsive ← Pages (responsive de las 8 pantallas)
add_dep(T_4_4_15, T_4_4_1_S3)      # Responsive ← Components (S3)
add_dep(T_4_4_10, T_4_4_4_S3)      # Unit Tests FE ← Hooks (S3)
add_dep(T_4_4_10, T_4_4_9)         # Unit Tests FE ← Utils
add_dep(T_4_4_11, T_4_4_1_S3)      # Component Tests ← Components (S3)
add_dep(T_4_4_13, T_4_4_2)         # README ← Pages

# === BE chain ===
add_dep(T_4_5_8, T_4_5_1_S3)       # Error Handling Integ ← Integration Code (S3)
add_dep(T_4_5_9, T_4_5_8)          # Retry Logic ← Error Handling Integ
add_dep(T_4_5_6, T_4_5_1_S3)       # Integration Tests ← Integration Code (S3)
add_dep(T_4_5_7, T_4_5_1_S3)       # Integration Docs ← Integration Code (S3)
add_dep(T_4_3_11, T_4_3_1_S3)      # Swagger ← API Endpoints (S3)
add_dep(T_4_3_12, T_4_3_1_S3)      # Postman ← API Endpoints (S3)
add_dep(T_4_3_9, T_4_3_2_S2)       # Unit Tests BE ← Services (S2)

# === Validación chain ===
add_dep(TL_S4_REV, T_4_4_2)        # TL Review ← Pages
add_dep(TL_S4_REV, T_4_4_15)       # TL Review ← Responsive
add_dep(TL_S4_REV, T_4_4_10)       # TL Review ← Unit Tests FE
add_dep(TL_S4_REV, T_4_4_11)       # TL Review ← Component Tests
add_dep(TL_S4_REV, T_4_5_9)        # TL Review ← Retry Logic
add_dep(TL_S4_REV, T_4_5_6)        # TL Review ← Integration Tests
add_dep(TL_S4_REV, T_4_3_9)        # TL Review ← Unit Tests BE
add_dep(TL_S4_REV, T_4_3_11)       # TL Review ← Swagger
add_dep(DL_S4_REV, T_4_4_2)        # DL Review ← Pages
add_dep(DL_S4_REV, T_4_4_15)       # DL Review ← Responsive
add_dep(AR_S4, TL_S4_REV)          # AR ← TL Review
add_dep(CIERRE_S4, AR_S4)          # CIERRE ← AR
add_dep(CIERRE_S4, DL_S4_REV)      # CIERRE ← DL Review
add_dep(APR_S4, CIERRE_S4)         # APR ← CIERRE

print("Dependencias S4 registradas ✅")
```

---

## 12. PASO 10: GENERAR CONTEXTO

```markdown
# CONTEXTO: Sprint S4 — FE Features + Context SLA

**Generado por:** TL-Agent
**Fecha:** [FECHA]

## 1. Estructura VTT

| Entidad | ID |
|---------|-----|
| Release R1 | {RELEASE_ID} |
| Sprint S4 | {SPRINT_S4_ID} |

## 2. Deliveries

| Delivery | ID |
|----------|-----|
| FE-S4: Pages + Tests + Responsive | {DEL_FE_S4} |
| BE-S4: Tests + Docs + Error Handling Integ | {DEL_BE_S4} |
| TL-S4: Reviews + SLA Validation | {DEL_TL_S4} |
| REV-S4: Validación + Cierre | {DEL_REV_S4} |

## 3. Tareas

| ID Cat | Título | VTT ID | Rol | Horas | Delivery |
|--------|--------|--------|:---:|:-----:|----------|
| 4.4.2 | Pages — 8 pantallas | {T_4_4_2} | FE | 13 | DEL_FE_S4 |
| 4.4.9 | Utils FE | {T_4_4_9} | FE | 2 | DEL_FE_S4 |
| 4.4.15 | Responsive | {T_4_4_15} | FE | 5 | DEL_FE_S4 |
| 4.4.10 | Unit Tests FE | {T_4_4_10} | FE | 5 | DEL_FE_S4 |
| 4.4.11 | Component Tests | {T_4_4_11} | FE | 5 | DEL_FE_S4 |
| 4.4.13 | Frontend README | {T_4_4_13} | FE | 2 | DEL_FE_S4 |
| 4.5.8 | Error Handling Integ | {T_4_5_8} | BE | 5 | DEL_BE_S4 |
| 4.5.9 | Retry Logic | {T_4_5_9} | BE | 5 | DEL_BE_S4 |
| 4.5.6 | Integration Tests | {T_4_5_6} | BE | 8 | DEL_BE_S4 |
| 4.5.7 | Integration Docs | {T_4_5_7} | BE | 3 | DEL_BE_S4 |
| 4.3.11 | Swagger | {T_4_3_11} | BE | 5 | DEL_BE_S4 |
| 4.3.12 | Postman Collection | {T_4_3_12} | BE | 3 | DEL_BE_S4 |
| 4.3.9 | Unit Tests BE | {T_4_3_9} | BE | 8 | DEL_BE_S4 |
| — | TL Reviews + SLA | {TL_S4_REV} | TL | 4 | DEL_TL_S4 |
| — | AR Audit | {AR_S4} | AR | 3 | DEL_REV_S4 |
| — | DL Visual Review | {DL_S4_REV} | DL | 3 | DEL_REV_S4 |
| — | CIERRE-S4 | {CIERRE_S4} | TL | 2 | DEL_REV_S4 |
| — | APR-S4 | {APR_S4} | PM | 1 | DEL_REV_S4 |

## 4. Resumen

| Categoría | Tareas | Horas |
|-----------|:------:|:-----:|
| FE (Pages+Tests+Responsive) | 6 | 32h |
| BE (Tests+Docs+ErrorHandling) | 7 | 37h |
| TL (Reviews+SLA) | 1 | 4h |
| Validación + Cierre + APR | 4 | 9h |
| **Total** | **18** | **82h** |
```

---

## 13. CHECKLIST DE VERIFICACIÓN

```markdown
## Setup S4 — Verificación Final

### Estructura VTT
[ ] Sprint S4 creado y vinculado a R1
[ ] 4 Deliveries creados y vinculados a Sprint S4

### Tareas FE (6) → DEL_FE_S4
[ ] [4.4.2] Pages — 8 pantallas
[ ] [4.4.9] Utils FE
[ ] [4.4.15] Responsive Implementation
[ ] [4.4.10] Unit Tests FE
[ ] [4.4.11] Component Tests
[ ] [4.4.13] Frontend README

### Tareas BE (7) → DEL_BE_S4
[ ] [4.5.8] Error Handling Integration
[ ] [4.5.9] Retry Logic
[ ] [4.5.6] Integration Tests
[ ] [4.5.7] Integration Docs
[ ] [4.3.11] API Documentation — Swagger
[ ] [4.3.12] Postman Collection
[ ] [4.3.9] Unit Tests BE

### Validación (5) → DEL_TL_S4 + DEL_REV_S4
[ ] TL-S4-REV
[ ] AR-S4
[ ] DL-S4-REV
[ ] CIERRE-S4
[ ] APR-S4

### Dependencias cross-sprint
[ ] SETUP-S4 ← CIERRE-S3
[ ] 4.4.2 ← 4.4.1 + 4.4.6 + 4.4.3 (S3)
[ ] 4.5.8, 4.5.6, 4.5.7 ← 4.5.1 (S3)
[ ] 4.3.11, 4.3.12 ← 4.3.1 (S3)
[ ] 4.3.9 ← 4.3.2 (S2)

### Dependencias intra-sprint
[ ] FE: 4.4.2 → 4.4.15, 4.4.13; 4.4.9 + 4.4.4(S3) → 4.4.10
[ ] BE: 4.5.8 → 4.5.9
[ ] Val: BE+FE → TL; FE visual → DL; TL+DL → AR → CIERRE → APR
```

---

**FIN DEL SETUP S4**
