# SETUP: Sprint S5 — Testing Phase 1

**Documento:** SETUP_S5.md
**Versión:** 1.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-12
**Sprint:** S5 — Testing Phase 1
**Propósito:** Instrucciones para crear estructura y tareas del Sprint S5 en VTT

---

## 0. RESUMEN EJECUTIVO

Al completar este setup:

- ✅ Sprint S5 creado en VTT (vinculado a Release R1)
- ✅ 4 Deliveries creados y vinculados a Sprint S5
- ✅ 13 tareas creadas y asociadas (7 deliverables + 1 TL + 5 validación/cierre)
- ✅ Dependencias configuradas (cross-sprint con S3/S4 + intra-sprint)

**Primer sprint de Fase 5.** Primer sprint con QA. Sin FE → 2 firmas (TL + AR).

**Tiempo estimado:** 1.5 horas
**Prerrequisito:** Sprint S4 completado (APR-S4 = task_completed ✅, Fase 4 cerrada)

---

## 1. PRERREQUISITOS

| # | Prerrequisito | Estado |
|---|---------------|--------|
| 1 | Sprint S4 cerrado (Fase 4 Development cerrada) | ⬜ |
| 2 | RELEASE_ID y CONTEXTO_S4.md disponibles | ⬜ |
| 3 | IDs de tareas S3/S4 para dependencias cross-sprint | ⬜ |
| 4 | HANDOFF_TL_S5.md y CLOSURE_S5.md disponibles | ⬜ |

---

## 2. CONSTANTES DE SESIÓN

```python
import urllib.request, json, time, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://77.42.88.106:3000"
PROJECT_ID = "d0fc276d-e764-4a83-96e9-d65f086ed803"
PHASE_TEST = "________________________________"  # Phase ID de Fase 5 Testing

# Auth
req = urllib.request.Request(
    f'{BASE_URL}/api/auth/service-token',
    data=json.dumps({
        'userId': '92225290-6b6b-4c1f-a940-dcb4262507aa',
        'serviceKey': 'hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d'
    }).encode(),
    headers={'Content-Type': 'application/json'}, method='POST')
TOKEN = json.loads(urllib.request.urlopen(req).read())['data']['token']
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

# Agentes
TL = "92225290-6b6b-4c1f-a940-dcb4262507aa"
QA = "613c9538-658c-45fe-a6d7-c1ea9ff04b78"
DO = "322e3745-9756-4a7c-af11-44b33edef44d"
DB = "6fae26f0-fc87-42d3-9a9e-eb6b1dbe6dd7"
AR = "e9403c25-c1f8-4b64-b2ef-f447d53115e2"
PM_ID = "350831b2-e1ae-4dbe-b2eb-7e023ec2e103"

PRI_HIGH = "1a617554-6319-4c56-826f-8ef49a0ff9cc"
PRI_MED  = "d0b619ef-27e7-42d8-8879-41030a602eed"

# === RECUPERAR DE CONTEXTO_S4 / S3 ===
RELEASE_ID   = "________________________________"
T_4_3_1_S3   = "________________________________"  # API Endpoints (S3) — para contract tests
T_4_3_10_S4  = "________________________________"  # Integration Tests BE (S4) — base para QA
T_4_1_1_S1   = "________________________________"  # Dev Environment (S1) — base para test env
T_4_2_1_S1   = "________________________________"  # Initial Migration (S1) — base para test DB
T_4_2_3_S2   = "________________________________"  # Seed Data (S2) — base para test seeding
CIERRE_S4    = "________________________________"
```

---

## 3. PASO 1: CREAR SPRINT S5

```python
body = {
    "number": 5,
    "name": "S5 — Testing Phase 1",
    "goal": "Functional tests pass, Integration tests pass, Test environment operativo",
    "startDate": "2026-07-27T00:00:00Z",
    "endDate": "2026-08-09T00:00:00Z"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/releases/{RELEASE_ID}/sprints',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SPRINT_S5_ID = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SPRINT_S5_ID: {SPRINT_S5_ID}")
```

**Registrar:**
```
SPRINT_S5_ID: ________________________________
```

---

## 4. PASO 2: CREAR TAREA SETUP

```python
body = {
    "title": "SETUP-S5: Setup Sprint 5 — Testing Phase 1",
    "description": "Configuración del Sprint S5. Primer sprint Fase 5. Primer sprint con QA.",
    "assigneeId": TL, "estimatedHours": 1, "priorityId": PRI_MED,
    "complexity": "LOW", "category": "documentation"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SETUP_S5 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SETUP_S5: {SETUP_S5}")
```

**Registrar:**
```
SETUP_S5: ________________________________
```

---

## 5. PASO 3: CREAR 4 DELIVERIES

```python
def create_delivery(name, order):
    body = {"phaseId": PHASE_TEST, "name": name, "order": order, "createdBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    return json.loads(urllib.request.urlopen(req).read())['data']['id']

DEL_QA_S5    = create_delivery("QA-S5: Planning + Cases + Functional + Integration", 1)
DEL_INFRA_S5 = create_delivery("INFRA-S5: Test Environment + DB (DO+DB)",           2)
DEL_TL_S5    = create_delivery("TL-S5: Coordinación Testing",                        3)
DEL_REV_S5   = create_delivery("REV-S5: Validación + Cierre",                        4)

print(f"DEL_QA_S5:    {DEL_QA_S5}")
print(f"DEL_INFRA_S5: {DEL_INFRA_S5}")
print(f"DEL_TL_S5:    {DEL_TL_S5}")
print(f"DEL_REV_S5:   {DEL_REV_S5}")
```

**Registrar:**
```
DEL_QA_S5:    ________________________________
DEL_INFRA_S5: ________________________________
DEL_TL_S5:    ________________________________
DEL_REV_S5:   ________________________________
```

---

## 6. PASO 4: VINCULAR DELIVERIES AL SPRINT S5

```python
for d in [DEL_QA_S5, DEL_INFRA_S5, DEL_TL_S5, DEL_REV_S5]:
    body = {"sprintId": SPRINT_S5_ID}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{d}',
        data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
    urllib.request.urlopen(req)
    time.sleep(0.05)
print("Deliveries vinculados a Sprint S5 ✅")
```

---

## 7. PASO 5: CREAR TAREAS QA (Planning + Cases + Functional + Integration)

```python
tasks_qa = [
    ("5.1.1", "Test Plan", 5, "MEDIUM",
     "2.3.4 Use Cases (completado ✅)\nDetalle: Plan de testing completo para Memory Service R1"),
    ("5.1.2-5", "Test Strategy + Scope + Schedule + Resources", 9, "MEDIUM",
     "5.1.1\nDetalle: 5.1.2 Strategy, 5.1.3 Scope, 5.1.4 Schedule, 5.1.5 Resource Allocation"),
    ("5.2.1-4", "Test Cases Document + IDs + Data + Expected Results", 18, "HIGH",
     "5.1.1, 5.1.3 Scope\nDetalle: 5.2.1 Document, 5.2.2 IDs, 5.2.3 Test Data, 5.2.4 Expected Results. 11 endpoints + 8 pantallas"),
    ("5.4.1-5", "Functional Test Results + Log + Defects + Summary + Evidence", 17, "HIGH",
     "5.2.1-4, 5.3.1 Test Environment\nDetalle: 5.4.1 Results, 5.4.2 Log, 5.4.3 Defects, 5.4.4 Summary, 5.4.5 Evidence"),
    ("5.5.1-4", "Integration Test Suite + Results + API Contracts + Coverage", 18, "HIGH",
     "4.3.10 Integration Tests BE (S4), 5.3.1 Test Environment\nDetalle: 5.5.1 Suite, 5.5.2 Results, 5.5.3 API Contract Tests, 5.5.4 Coverage"),
]

qa_ids = {}
for cat_id, name, hours, complexity, deps in tasks_qa:
    pri = PRI_HIGH if complexity == "HIGH" else PRI_MED
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (IDs catálogo: {cat_id})\nSprint: S5\nRol: QA\nEstimación: {hours}h\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": QA, "estimatedHours": hours, "priorityId": pri,
        "complexity": complexity, "category": "testing"
    }
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    qa_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {qa_ids[cat_id]}")
    time.sleep(0.1)

T_5_1_1  = qa_ids["5.1.1"]
T_5_1_25 = qa_ids["5.1.2-5"]
T_5_2_14 = qa_ids["5.2.1-4"]
T_5_4_15 = qa_ids["5.4.1-5"]
T_5_5_14 = qa_ids["5.5.1-4"]
```

**Registrar:**
```
T_5_1_1:  ________________________________
T_5_1_25: ________________________________
T_5_2_14: ________________________________
T_5_4_15: ________________________________
T_5_5_14: ________________________________
```

---

## 8. PASO 6: CREAR TAREAS INFRA (DO + DB)

```python
# 5.3.1 Test Environment (DO)
body = {
    "title": "[5.3.1] Test Environment",
    "description": "Deliverable: Test Environment (ID catálogo: 5.3.1)\nSprint: S5\nRol: DO\nEstimación: 5h\nComplejidad: MEDIUM\nDependencias: 3B.8.5 Env Matrix (completado ✅), 4.1.1 Dev Environment (S1)\nDetalle: Ambiente de testing separado con BD de prueba, configuración aislada",
    "assigneeId": DO, "estimatedHours": 5, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "deployment"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_5_3_1 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_5_3_1: {T_5_3_1}")
time.sleep(0.1)

# 5.3.2-4 Test Database + Seeding + Docs (DB)
body = {
    "title": "[5.3.2-4] Test Database + Seeding + Docs",
    "description": "Deliverable: Test Database + Seeding + Environment Docs (IDs catálogo: 5.3.2, 5.3.3, 5.3.4)\nSprint: S5\nRol: DB\nEstimación: 8h\nComplejidad: MEDIUM\nDependencias: 5.3.1, 4.2.1 Initial Migration (S1), 4.2.3 Seed Data (S2)\nDetalle: BD de prueba con datos representativos, seeding automático, documentación del ambiente",
    "assigneeId": DB, "estimatedHours": 8, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "testing"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_5_3_24 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_5_3_24: {T_5_3_24}")
```

**Registrar:**
```
T_5_3_1:  ________________________________
T_5_3_24: ________________________________
```

---

## 9. PASO 7: CREAR TAREAS TL + VALIDACIÓN + CIERRE + APR

```python
# TL-S5-REV
body = {
    "title": "TL-S5-REV: Coordinación Testing Sprint S5",
    "description": "Coordinar QA, DO, DB. Revisar test plan y resultados. Verificar cobertura funcional + integration.",
    "assigneeId": TL, "estimatedHours": 4, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
TL_S5_REV = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"TL_S5_REV: {TL_S5_REV}")
time.sleep(0.1)

# AR-S5
body = {
    "title": "AR-S5: Integration Audit Sprint S5",
    "description": "Auditar: Test plan vs 2.3.4 use cases, integration tests vs 3B.4.2 contratos, test coverage vs scope.",
    "assigneeId": AR, "estimatedHours": 3, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
AR_S5 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"AR_S5: {AR_S5}")
time.sleep(0.1)

# CIERRE-S5
body = {
    "title": "CIERRE-S5: Cierre Sprint 5 — Testing Phase 1",
    "description": "Cierre formal S5. Requiere firmas TL + AR. Usar CLOSURE_S5.md.",
    "assigneeId": TL, "estimatedHours": 2, "priorityId": PRI_HIGH,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
CIERRE_S5 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"CIERRE_S5: {CIERRE_S5}")
time.sleep(0.1)

# APR-S5
body = {
    "title": "APR-S5: Aprobación final Sprint S5",
    "description": "Aprobación PM tras firmas TL + AR y verificación M5.",
    "assigneeId": PM_ID, "estimatedHours": 1, "priorityId": PRI_HIGH,
    "complexity": "LOW", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
APR_S5 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"APR_S5: {APR_S5}")
```

**Registrar:**
```
TL_S5_REV: ________________________________
AR_S5:     ________________________________
CIERRE_S5: ________________________________
APR_S5:    ________________________________
```

---

## 10. PASO 8: ASOCIAR TAREAS A DELIVERIES

```python
def assign_task_to_delivery(delivery_id, task_id):
    body = {"assignedBy": TL}
    req = urllib.request.Request(
        f'{BASE_URL}/api/deliveries/{delivery_id}/tasks/{task_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

# QA (5 tareas) → DEL_QA_S5
for t in [T_5_1_1, T_5_1_25, T_5_2_14, T_5_4_15, T_5_5_14]:
    assign_task_to_delivery(DEL_QA_S5, t)
print("QA → DEL_QA_S5 ✅")

# INFRA (2 tareas) → DEL_INFRA_S5
for t in [T_5_3_1, T_5_3_24]:
    assign_task_to_delivery(DEL_INFRA_S5, t)
print("INFRA → DEL_INFRA_S5 ✅")

# TL (1 tarea) → DEL_TL_S5
assign_task_to_delivery(DEL_TL_S5, TL_S5_REV)
print("TL → DEL_TL_S5 ✅")

# REV (3 tareas + SETUP) → DEL_REV_S5
for t in [AR_S5, CIERRE_S5, APR_S5, SETUP_S5]:
    assign_task_to_delivery(DEL_REV_S5, t)
print("REV → DEL_REV_S5 ✅")
```

---

## 11. PASO 9: REGISTRAR DEPENDENCIAS

```python
def add_dep(task_id, depends_on_id):
    body = {"dependsOnTaskId": depends_on_id}
    req = urllib.request.Request(f'{BASE_URL}/api/tasks/{task_id}/dependencies',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

print("Registrando dependencias S5...")

# === CROSS-SPRINT: S4 → S5 ===
add_dep(SETUP_S5, CIERRE_S4)

# === QA chain ===
add_dep(T_5_1_1, SETUP_S5)           # Test Plan ← SETUP
add_dep(T_5_1_25, T_5_1_1)           # Strategy+Scope+Schedule ← Test Plan
add_dep(T_5_2_14, T_5_1_25)          # Test Cases ← Strategy+Scope
add_dep(T_5_4_15, T_5_2_14)          # Functional Results ← Test Cases
add_dep(T_5_4_15, T_5_3_1)           # Functional Results ← Test Environment
add_dep(T_5_5_14, T_5_3_1)           # Integration Suite ← Test Environment
add_dep(T_5_5_14, T_4_3_1_S3)        # Integration Suite ← API Endpoints (S3, contratos)

# === INFRA chain ===
add_dep(T_5_3_1, SETUP_S5)           # Test Environment ← SETUP
add_dep(T_5_3_24, T_5_3_1)           # Test DB+Seeding ← Test Environment

# === Validación chain ===
add_dep(TL_S5_REV, T_5_4_15)         # TL Review ← Functional Results
add_dep(TL_S5_REV, T_5_5_14)         # TL Review ← Integration Suite
add_dep(TL_S5_REV, T_5_3_24)         # TL Review ← Test DB
add_dep(AR_S5, TL_S5_REV)            # AR ← TL Review
add_dep(CIERRE_S5, AR_S5)            # CIERRE ← AR
add_dep(APR_S5, CIERRE_S5)           # APR ← CIERRE

print("Dependencias S5 registradas ✅")
```

---

## 12. CHECKLIST DE VERIFICACIÓN

```markdown
## Setup S5 — Verificación Final

### Estructura VTT
[ ] Sprint S5 creado y vinculado a R1
[ ] 4 Deliveries creados y vinculados

### Tareas QA (5) → DEL_QA_S5
[ ] [5.1.1] Test Plan
[ ] [5.1.2-5] Test Strategy + Scope + Schedule + Resources
[ ] [5.2.1-4] Test Cases + IDs + Data + Expected Results
[ ] [5.4.1-5] Functional Test Results + Log + Defects + Summary
[ ] [5.5.1-4] Integration Test Suite + Results + Contracts + Coverage

### Tareas INFRA (2) → DEL_INFRA_S5
[ ] [5.3.1] Test Environment (DO)
[ ] [5.3.2-4] Test Database + Seeding + Docs (DB)

### Validación (4) → DEL_TL_S5 + DEL_REV_S5
[ ] TL-S5-REV
[ ] AR-S5
[ ] CIERRE-S5
[ ] APR-S5

### Dependencias
[ ] SETUP-S5 ← CIERRE-S4
[ ] QA: 5.1.1 → 5.1.2-5 → 5.2.1-4 → 5.4.1-5
[ ] QA: 5.5.1-4 ← 5.3.1 + 4.3.1(S3)
[ ] INFRA: 5.3.1 → 5.3.2-4
[ ] Val: QA+INFRA → TL → AR → CIERRE → APR
```

---

**FIN DEL SETUP S5**
