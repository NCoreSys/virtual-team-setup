# SETUP: Sprint S6 — Testing Phase 2 + Docs

**Documento:** SETUP_S6.md
**Versión:** 1.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Fecha:** 2026-05-12
**Sprint:** S6 — Testing Phase 2 + Docs
**Propósito:** Instrucciones para crear estructura y tareas del Sprint S6 en VTT

---

## 0. RESUMEN EJECUTIVO

Al completar este setup:

- ✅ Sprint S6 creado en VTT (vinculado a Release R1)
- ✅ 4 Deliveries creados y vinculados a Sprint S6
- ✅ 14 tareas creadas y asociadas (9 deliverables agrupados + 1 TL + 4 validación/cierre)
- ✅ Dependencias configuradas

**Sprint de alta densidad — paralelo intenso.** 3 agentes simultáneos: QA (E2E + perf + security), BE (bug fixes + integration tests), TL (UAT + docs + code review). Sin FE → 2 firmas (TL + AR).

**Tiempo estimado:** 1.5 horas
**Prerrequisito:** Sprint S5 completado (CIERRE-S5 = task_completed ✅)

---

## 1. CONSTANTES DE SESIÓN

```python
import urllib.request, json, time, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://77.42.88.106:3000"
PROJECT_ID = "d0fc276d-e764-4a83-96e9-d65f086ed803"
PHASE_TEST = "________________________________"

# Auth
req = urllib.request.Request(
    f'{BASE_URL}/api/auth/service-token',
    data=json.dumps({
        'userId': '92225290-6b6b-4c1f-a940-dcb4262507aa',
        'serviceKey': 'hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d'
    }).encode(),
    headers={'Content-Type': 'application/json'}, method='POST')
TOKEN = json.loads(urllib.request.urlopen(req).read())['data']['token']
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

TL = "92225290-6b6b-4c1f-a940-dcb4262507aa"
BE = "ebbe3cee-abed-4b3b-860d-0a81f632b08a"
QA = "613c9538-658c-45fe-a6d7-c1ea9ff04b78"
AR = "e9403c25-c1f8-4b64-b2ef-f447d53115e2"
PM_ID = "350831b2-e1ae-4dbe-b2eb-7e023ec2e103"

PRI_HIGH = "1a617554-6319-4c56-826f-8ef49a0ff9cc"
PRI_MED  = "d0b619ef-27e7-42d8-8879-41030a602eed"

# === RECUPERAR DE CONTEXTO_S5 ===
RELEASE_ID  = "________________________________"
T_5_3_1_S5  = "________________________________"  # Test Environment (S5)
T_5_4_15_S5 = "________________________________"  # Functional Results (S5) — defects para bug fixes
CIERRE_S5   = "________________________________"
```

---

## 2. PASO 1: CREAR SPRINT S6

```python
body = {
    "number": 6,
    "name": "S6 — Testing Phase 2 + Docs",
    "goal": "Load test GET /context <500ms p95 con 50 VU, Security sign-off, UAT sign-off",
    "startDate": "2026-08-10T00:00:00Z",
    "endDate": "2026-08-23T00:00:00Z"
}
req = urllib.request.Request(
    f'{BASE_URL}/api/releases/{RELEASE_ID}/sprints',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SPRINT_S6_ID = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SPRINT_S6_ID: {SPRINT_S6_ID}")
```

**Registrar:**
```
SPRINT_S6_ID: ________________________________
```

---

## 3. PASO 2: CREAR TAREA SETUP + 4 DELIVERIES + VINCULAR

```python
# SETUP
body = {
    "title": "SETUP-S6: Setup Sprint 6 — Testing Phase 2 + Docs",
    "description": "Configuración del Sprint S6. Alta densidad — paralelo intenso QA+BE+TL.",
    "assigneeId": TL, "estimatedHours": 1, "priorityId": PRI_MED,
    "complexity": "LOW", "category": "documentation"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SETUP_S6 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SETUP_S6: {SETUP_S6}")

# Deliveries
def create_delivery(name, order):
    body = {"phaseId": PHASE_TEST, "name": name, "order": order, "createdBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    return json.loads(urllib.request.urlopen(req).read())['data']['id']

DEL_QA_S6   = create_delivery("QA-S6: E2E + Performance + Security + Unit Tests", 1)
DEL_BE_S6   = create_delivery("BE-S6: Bug Fixes + Integration Tests",             2)
DEL_TL_S6   = create_delivery("TL-S6: UAT + Docs + Code Review",                 3)
DEL_REV_S6  = create_delivery("REV-S6: Validación + Cierre",                      4)

for d in [DEL_QA_S6, DEL_BE_S6, DEL_TL_S6, DEL_REV_S6]:
    body = {"sprintId": SPRINT_S6_ID}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{d}',
        data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
    urllib.request.urlopen(req)
    time.sleep(0.05)
print("Deliveries vinculados ✅")
```

**Registrar:**
```
SETUP_S6:   ________________________________
DEL_QA_S6:  ________________________________
DEL_BE_S6:  ________________________________
DEL_TL_S6:  ________________________________
DEL_REV_S6: ________________________________
```

---

## 4. PASO 3: CREAR TAREAS QA

```python
tasks_qa = [
    ("5.6.1-5", "E2E Test Suite + Results + Critical Path + Visual Regression + Docs", 19, "HIGH",
     "5.3.1 Test Environment (S5), 2.6.2 Happy Path Flows (completado ✅)\nDetalle: Playwright E2E, critical paths, visual regression screenshots"),
    ("5.7.1-6", "Load Test Plan + Results + Stress + Metrics + Bottleneck + Recommendations", 24, "HIGH",
     "3B.4.2 Endpoints (completado ✅), 5.3.1 Test Environment (S5)\nDetalle: k6 con 50 VU. SLA GET /context <500ms p95. Stress test. Bottleneck analysis"),
    ("5.8.1-7", "Security Test Plan + PenTest + Scan + OWASP + Findings + Remediation + Sign-off", 24, "HIGH",
     "3B.7.1 Security Plan (completado ✅), 3B.7.6 OWASP (completado ✅)\nDetalle: Pentesting, vulnerability scan, OWASP compliance, security sign-off"),
    ("4.6.1-7", "Unit Tests QA — Coverage + Mock Factories + Fixtures + Utils", 30, "HIGH",
     "4.3.9 Unit Tests BE (S4)\nDetalle: QA expande coverage BE+FE. Mock factories, fixtures, test utils. Target ≥80%"),
]

qa_ids = {}
for cat_id, name, hours, complexity, deps in tasks_qa:
    body = {
        "title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (IDs catálogo: {cat_id})\nSprint: S6\nRol: QA\nEstimación: {hours}h\nComplejidad: {complexity}\nDependencias: {deps}",
        "assigneeId": QA, "estimatedHours": hours, "priorityId": PRI_HIGH,
        "complexity": complexity, "category": "testing"
    }
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    qa_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {qa_ids[cat_id]}")
    time.sleep(0.1)

T_5_6_15 = qa_ids["5.6.1-5"]
T_5_7_16 = qa_ids["5.7.1-6"]
T_5_8_17 = qa_ids["5.8.1-7"]
T_4_6_17 = qa_ids["4.6.1-7"]
```

**Registrar:**
```
T_5_6_15: ________________________________
T_5_7_16: ________________________________
T_5_8_17: ________________________________
T_4_6_17: ________________________________
```

---

## 5. PASO 4: CREAR TAREAS BE

```python
# 5.11.1-3 Bug Fixes + Regression + Report
body = {
    "title": "[5.11.1-3] Bug Fixes + Regression Tests + Bug Report",
    "description": "Deliverable: Bug Fixes (IDs: 5.11.1, 5.11.2, 5.11.3)\nSprint: S6\nRol: BE+QA\nEstimación: 15h\nComplejidad: HIGH\nDependencias: 5.4.3 Defects (S5)\nDetalle: Fix bugs P0/P1/P2 de S5 functional testing. Regression tests por fix. Report consolidado",
    "assigneeId": BE, "estimatedHours": 15, "priorityId": PRI_HIGH,
    "complexity": "HIGH", "category": "development"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_5_11_13 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_5_11_13: {T_5_11_13}")
time.sleep(0.1)

# 4.3.10 Integration Tests BE
body = {
    "title": "[4.3.10] Integration Tests BE",
    "description": "Deliverable: Integration Tests BE (ID: 4.3.10)\nSprint: S6\nRol: BE\nEstimación: 8h\nComplejidad: HIGH\nDependencias: 4.3.1 Endpoints (S3), 4.2.4 Test Data (S2)\nDetalle: Tests de integración BE adicionales — end-to-end con BD real",
    "assigneeId": BE, "estimatedHours": 8, "priorityId": PRI_HIGH,
    "complexity": "HIGH", "category": "development"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_4_3_10 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_4_3_10: {T_4_3_10}")
```

**Registrar:**
```
T_5_11_13: ________________________________
T_4_3_10:  ________________________________
```

---

## 6. PASO 5: CREAR TAREAS TL (UAT + Docs + Code Review)

```python
# 5.10.1-5 UAT
body = {
    "title": "[5.10.1-5] UAT Plan + Cases + Results + Feedback + Sign-off",
    "description": "Deliverable: UAT (IDs: 5.10.1-5.10.5)\nSprint: S6\nRol: TL\nEstimación: 13h\nComplejidad: HIGH\nDependencias: 5.4.4 Pass/Fail Summary (S5), 5.3.1 Test Environment (S5)\nDetalle: UAT plan, test cases para PO, ejecución, feedback, sign-off formal",
    "assigneeId": TL, "estimatedHours": 13, "priorityId": PRI_HIGH,
    "complexity": "HIGH", "category": "testing"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_5_10_15 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_5_10_15: {T_5_10_15}")
time.sleep(0.1)

# 4.7.1-8 Technical Docs
body = {
    "title": "[4.7.1-8] Technical Docs — READMEs + Contributing + Changelog",
    "description": "Deliverable: Technical Docs (IDs: 4.7.1-4.7.8)\nSprint: S6\nRol: TL+BE\nEstimación: 24h\nComplejidad: MEDIUM\nDetalle: Main README, Backend README, Frontend README, API Docs, Code Comments, Architecture Docs, Contributing Guide, Changelog",
    "assigneeId": TL, "estimatedHours": 24, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "documentation"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_4_7_18 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_4_7_18: {T_4_7_18}")
time.sleep(0.1)

# 4.8.1-4 Code Review bulk
body = {
    "title": "[4.8.1-4] Code Review — PR Reviews + Quality + Debt + Refactoring",
    "description": "Deliverable: Code Review (IDs: 4.8.1-4.8.4)\nSprint: S6\nRol: TL\nEstimación: 22h\nComplejidad: HIGH\nDetalle: Bulk PR reviews acumulados, code quality report, technical debt log, refactoring plan",
    "assigneeId": TL, "estimatedHours": 22, "priorityId": PRI_HIGH,
    "complexity": "HIGH", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_4_8_14 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_4_8_14: {T_4_8_14}")
```

**Registrar:**
```
T_5_10_15: ________________________________
T_4_7_18:  ________________________________
T_4_8_14:  ________________________________
```

---

## 7. PASO 6: CREAR TAREAS VALIDACIÓN + CIERRE + APR

```python
# TL-S6-REV
body = {
    "title": "TL-S6-REV: Coordinación Sprint S6",
    "description": "Coordinar paralelo QA+BE+TL. Verificar security sign-off, UAT sign-off, load test SLA.",
    "assigneeId": TL, "estimatedHours": 4, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
TL_S6_REV = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"TL_S6_REV: {TL_S6_REV}")
time.sleep(0.1)

# AR-S6
body = {
    "title": "AR-S6: Integration Audit Sprint S6",
    "description": "Auditar: E2E coverage vs critical paths, load test vs SLA, security vs 3B.7.1, UAT sign-off válido.",
    "assigneeId": AR, "estimatedHours": 3, "priorityId": PRI_MED,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
AR_S6 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"AR_S6: {AR_S6}")
time.sleep(0.1)

# CIERRE-S6
body = {
    "title": "CIERRE-S6: Cierre Sprint 6 — Testing Phase 2 (Fin Fase 5)",
    "description": "Cierre formal S6 y Fase 5. Requiere firmas TL + AR. Usar CLOSURE_S6.md.",
    "assigneeId": TL, "estimatedHours": 2, "priorityId": PRI_HIGH,
    "complexity": "MEDIUM", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
CIERRE_S6 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"CIERRE_S6: {CIERRE_S6}")
time.sleep(0.1)

# APR-S6
body = {
    "title": "APR-S6: Aprobación final Sprint S6 (Fin Fase 5)",
    "description": "Aprobación PM. Cierra Fase 5 Testing. Habilita Fase 6 Deploy.",
    "assigneeId": PM_ID, "estimatedHours": 1, "priorityId": PRI_HIGH,
    "complexity": "LOW", "category": "review"
}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_TEST}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
APR_S6 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"APR_S6: {APR_S6}")
```

**Registrar:**
```
TL_S6_REV: ________________________________
AR_S6:     ________________________________
CIERRE_S6: ________________________________
APR_S6:    ________________________________
```

---

## 8. PASO 7: ASOCIAR TAREAS A DELIVERIES

```python
def assign_task_to_delivery(delivery_id, task_id):
    body = {"assignedBy": TL}
    req = urllib.request.Request(
        f'{BASE_URL}/api/deliveries/{delivery_id}/tasks/{task_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

# QA (4) → DEL_QA_S6
for t in [T_5_6_15, T_5_7_16, T_5_8_17, T_4_6_17]:
    assign_task_to_delivery(DEL_QA_S6, t)
print("QA → DEL_QA_S6 ✅")

# BE (2) → DEL_BE_S6
for t in [T_5_11_13, T_4_3_10]:
    assign_task_to_delivery(DEL_BE_S6, t)
print("BE → DEL_BE_S6 ✅")

# TL (3) → DEL_TL_S6
for t in [T_5_10_15, T_4_7_18, T_4_8_14]:
    assign_task_to_delivery(DEL_TL_S6, t)
print("TL → DEL_TL_S6 ✅")

# REV (4 + SETUP) → DEL_REV_S6
for t in [TL_S6_REV, AR_S6, CIERRE_S6, APR_S6, SETUP_S6]:
    assign_task_to_delivery(DEL_REV_S6, t)
print("REV → DEL_REV_S6 ✅")
```

---

## 9. PASO 8: REGISTRAR DEPENDENCIAS

```python
def add_dep(task_id, depends_on_id):
    body = {"dependsOnTaskId": depends_on_id}
    req = urllib.request.Request(f'{BASE_URL}/api/tasks/{task_id}/dependencies',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

print("Registrando dependencias S6...")

# Cross-sprint
add_dep(SETUP_S6, CIERRE_S5)

# QA (paralelo entre sí, dependen de test env S5)
add_dep(T_5_6_15, T_5_3_1_S5)        # E2E ← Test Environment (S5)
add_dep(T_5_7_16, T_5_3_1_S5)        # Performance ← Test Environment (S5)
add_dep(T_5_8_17, SETUP_S6)          # Security ← SETUP
add_dep(T_4_6_17, SETUP_S6)          # Unit Tests QA ← SETUP

# BE
add_dep(T_5_11_13, T_5_4_15_S5)      # Bug Fixes ← Functional Results/Defects (S5)
add_dep(T_4_3_10, SETUP_S6)          # Integration Tests BE ← SETUP

# TL
add_dep(T_5_10_15, T_5_4_15_S5)      # UAT ← Functional pass (S5)
add_dep(T_5_10_15, T_5_11_13)        # UAT ← Bug Fixes (P0/P1 fixed first)
add_dep(T_4_7_18, SETUP_S6)          # Tech Docs ← SETUP
add_dep(T_4_8_14, SETUP_S6)          # Code Review ← SETUP

# Validación
add_dep(TL_S6_REV, T_5_6_15)         # Coord ← E2E
add_dep(TL_S6_REV, T_5_7_16)         # Coord ← Performance
add_dep(TL_S6_REV, T_5_8_17)         # Coord ← Security
add_dep(TL_S6_REV, T_5_10_15)        # Coord ← UAT
add_dep(TL_S6_REV, T_5_11_13)        # Coord ← Bug Fixes
add_dep(TL_S6_REV, T_4_6_17)         # Coord ← Unit Tests QA
add_dep(TL_S6_REV, T_4_3_10)         # Coord ← Integration Tests BE
add_dep(TL_S6_REV, T_4_7_18)         # Coord ← Tech Docs
add_dep(TL_S6_REV, T_4_8_14)         # Coord ← Code Review
add_dep(AR_S6, TL_S6_REV)
add_dep(CIERRE_S6, AR_S6)
add_dep(APR_S6, CIERRE_S6)

print("Dependencias S6 registradas ✅")
```

---

## 10. CHECKLIST DE VERIFICACIÓN

```markdown
## Setup S6 — Verificación Final

### Estructura VTT
[ ] Sprint S6 creado y vinculado a R1
[ ] 4 Deliveries creados y vinculados

### Tareas QA (4) → DEL_QA_S6
[ ] [5.6.1-5] E2E Tests
[ ] [5.7.1-6] Performance Tests
[ ] [5.8.1-7] Security Tests
[ ] [4.6.1-7] Unit Tests QA

### Tareas BE (2) → DEL_BE_S6
[ ] [5.11.1-3] Bug Fixes + Regression
[ ] [4.3.10] Integration Tests BE

### Tareas TL (3) → DEL_TL_S6
[ ] [5.10.1-5] UAT
[ ] [4.7.1-8] Technical Docs
[ ] [4.8.1-4] Code Review

### Validación (4) → DEL_REV_S6
[ ] TL-S6-REV, AR-S6, CIERRE-S6, APR-S6
```

---

**FIN DEL SETUP S6**
