# SETUP: Sprint S7 — Deploy Staging

**Documento:** SETUP_S7.md
**Versión:** 1.0
**De:** PJM-Agent
**Para:** TL (Tech Lead)
**Sprint:** S7 — Deploy Staging
**Prerrequisito:** Sprint S6 completado, Fase 5 cerrada (APR-S6 ✅)

---

## 0. RESUMEN EJECUTIVO

- ✅ Sprint S7 creado en VTT (vinculado a Release R1)
- ✅ 4 Deliveries creados y vinculados
- ✅ 14 tareas creadas y asociadas (8 deliverables agrupados + 1 TL + 5 validación/cierre)
- ✅ Dependencias configuradas

**Primer sprint de Fase 6.** DO es el rol dominante. Sin FE → 2 firmas (TL + AR).

---

## 1. CONSTANTES DE SESIÓN

```python
import urllib.request, json, time, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://77.42.88.106:3000"
PROJECT_ID = "d0fc276d-e764-4a83-96e9-d65f086ed803"
PHASE_DEPLOY = "________________________________"  # Phase ID Fase 6 Deploy

# Auth
req = urllib.request.Request(
    f'{BASE_URL}/api/auth/service-token',
    data=json.dumps({
        'userId': '92225290-6b6b-4c1f-a940-dcb4262507aa',
        'serviceKey': 'hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d'
    }).encode(),
    headers={'Content-Type': 'application/json'}, method='POST')
TOKEN = json.loads(urllib.request.urlopen(req).read())['data']['token']
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

TL = "92225290-6b6b-4c1f-a940-dcb4262507aa"
DO = "322e3745-9756-4a7c-af11-44b33edef44d"
DB = "6fae26f0-fc87-42d3-9a9e-eb6b1dbe6dd7"
QA = "613c9538-658c-45fe-a6d7-c1ea9ff04b78"
AR = "e9403c25-c1f8-4b64-b2ef-f447d53115e2"
PM_ID = "350831b2-e1ae-4dbe-b2eb-7e023ec2e103"

PRI_HIGH = "1a617554-6319-4c56-826f-8ef49a0ff9cc"
PRI_MED  = "d0b619ef-27e7-42d8-8879-41030a602eed"

RELEASE_ID = "________________________________"
CIERRE_S6  = "________________________________"
```

---

## 2. CREAR SPRINT + SETUP + DELIVERIES

```python
# Sprint S7
body = {
    "number": 7,
    "name": "S7 — Deploy Staging",
    "goal": "Staging live en 77.42.88.106, smoke tests OK, CI/CD activo",
    "startDate": "2026-08-24T00:00:00Z",
    "endDate": "2026-09-06T00:00:00Z"
}
req = urllib.request.Request(f'{BASE_URL}/api/releases/{RELEASE_ID}/sprints',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SPRINT_S7_ID = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"SPRINT_S7_ID: {SPRINT_S7_ID}")

# SETUP
body = {"title": "SETUP-S7: Setup Sprint 7 — Deploy Staging",
    "description": "Configuración S7. Primer sprint Fase 6.", "assigneeId": TL,
    "estimatedHours": 1, "priorityId": PRI_MED, "complexity": "LOW", "category": "documentation"}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SETUP_S7 = json.loads(urllib.request.urlopen(req).read())['data']['id']

# Deliveries
def create_delivery(name, order):
    body = {"phaseId": PHASE_DEPLOY, "name": name, "order": order, "createdBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    return json.loads(urllib.request.urlopen(req).read())['data']['id']

DEL_DO_S7   = create_delivery("DO-S7: Infra + CI/CD + Staging Deploy", 1)
DEL_DB_S7   = create_delivery("DB-S7: Migration Run Staging",          2)
DEL_QA_S7   = create_delivery("QA-S7: Smoke Testing",                  3)
DEL_REV_S7  = create_delivery("REV-S7: Validación + Cierre",           4)

for d in [DEL_DO_S7, DEL_DB_S7, DEL_QA_S7, DEL_REV_S7]:
    body = {"sprintId": SPRINT_S7_ID}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{d}',
        data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
    urllib.request.urlopen(req)
    time.sleep(0.05)
```

**Registrar:**
```
SPRINT_S7_ID: ________________________________
SETUP_S7:     ________________________________
DEL_DO_S7:    ________________________________
DEL_DB_S7:    ________________________________
DEL_QA_S7:    ________________________________
DEL_REV_S7:   ________________________________
```

---

## 3. CREAR TAREAS

```python
# DO tasks
tasks_do = [
    ("6.1.1-4", "Infrastructure Ready + Servers + Network + Security Groups", 16, "HIGH", "deployment"),
    ("6.1.6+8", "Database Ready + SSL Certificates", 8, "MEDIUM", "deployment"),
    ("6.2.1", "CI Pipeline — GitHub Actions 4 repos", 8, "HIGH", "deployment"),
    ("6.2.2", "CD Pipeline — deploy automático staging/prod", 8, "HIGH", "deployment"),
    ("6.2.3-6", "Build Scripts + Deploy Scripts + Env Configs + CI/CD Docs", 13, "MEDIUM", "deployment"),
    ("6.3.1-2", "Staging Deploy + URL", 7, "MEDIUM", "deployment"),
    ("6.3.4", "Health Check staging", 2, "LOW", "deployment"),
]

do_ids = {}
for cat_id, name, hours, complexity, category in tasks_do:
    body = {"title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (IDs: {cat_id})\nSprint: S7\nRol: DO\nEstimación: {hours}h\nComplejidad: {complexity}",
        "assigneeId": DO, "estimatedHours": hours,
        "priorityId": PRI_HIGH if complexity == "HIGH" else PRI_MED,
        "complexity": complexity, "category": category}
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    do_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {do_ids[cat_id]}")
    time.sleep(0.1)

T_6_1_14 = do_ids["6.1.1-4"]
T_6_1_68 = do_ids["6.1.6+8"]
T_6_2_1  = do_ids["6.2.1"]
T_6_2_2  = do_ids["6.2.2"]
T_6_2_36 = do_ids["6.2.3-6"]
T_6_3_12 = do_ids["6.3.1-2"]
T_6_3_4  = do_ids["6.3.4"]

# DB task
body = {"title": "[6.3.3] Migration Run en staging",
    "description": "Deliverable: Migration Run (ID: 6.3.3)\nSprint: S7\nRol: DB\nEstimación: 3h",
    "assigneeId": DB, "estimatedHours": 3, "priorityId": PRI_MED,
    "complexity": "LOW", "category": "development"}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_6_3_3 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_6_3_3: {T_6_3_3}")
time.sleep(0.1)

# QA+TL task
body = {"title": "[6.4.1-3] Smoke Test Results + Critical Paths + Sign-off",
    "description": "Deliverable: Smoke Testing (IDs: 6.4.1-6.4.3)\nSprint: S7\nRol: QA+TL\nEstimación: 6h",
    "assigneeId": QA, "estimatedHours": 6, "priorityId": PRI_HIGH,
    "complexity": "MEDIUM", "category": "testing"}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
T_6_4_13 = json.loads(urllib.request.urlopen(req).read())['data']['id']
print(f"T_6_4_13: {T_6_4_13}")
time.sleep(0.1)

# TL + AR + CIERRE + APR
body = {"title": "TL-S7-REV: Coordinación Deploy", "assigneeId": TL, "estimatedHours": 2,
    "priorityId": PRI_MED, "complexity": "MEDIUM", "category": "review",
    "description": "Coordinar DO, DB, QA. Verificar staging live + smoke tests."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
TL_S7_REV = json.loads(urllib.request.urlopen(req).read())['data']['id']
time.sleep(0.1)

body = {"title": "AR-S7: Integration Audit Sprint S7", "assigneeId": AR, "estimatedHours": 2,
    "priorityId": PRI_MED, "complexity": "MEDIUM", "category": "review",
    "description": "Auditar: infra vs 3B.8.1, CI/CD vs 3B.8.1, staging vs smoke tests."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
AR_S7 = json.loads(urllib.request.urlopen(req).read())['data']['id']
time.sleep(0.1)

body = {"title": "CIERRE-S7: Cierre Sprint 7 — Deploy Staging", "assigneeId": TL,
    "estimatedHours": 2, "priorityId": PRI_HIGH, "complexity": "MEDIUM", "category": "review",
    "description": "Cierre formal S7. Firmas TL + AR. Usar CLOSURE_S7.md."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
CIERRE_S7 = json.loads(urllib.request.urlopen(req).read())['data']['id']
time.sleep(0.1)

body = {"title": "APR-S7: Aprobación final Sprint S7", "assigneeId": PM_ID,
    "estimatedHours": 1, "priorityId": PRI_HIGH, "complexity": "LOW", "category": "review",
    "description": "Aprobación PM tras firmas TL + AR y verificación M6."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
APR_S7 = json.loads(urllib.request.urlopen(req).read())['data']['id']
```

**Registrar:**
```
T_6_1_14:  ________________________________
T_6_1_68:  ________________________________
T_6_2_1:   ________________________________
T_6_2_2:   ________________________________
T_6_2_36:  ________________________________
T_6_3_12:  ________________________________
T_6_3_3:   ________________________________
T_6_3_4:   ________________________________
T_6_4_13:  ________________________________
TL_S7_REV: ________________________________
AR_S7:     ________________________________
CIERRE_S7: ________________________________
APR_S7:    ________________________________
```

---

## 4. ASOCIAR TAREAS A DELIVERIES

```python
def assign_task_to_delivery(delivery_id, task_id):
    body = {"assignedBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{delivery_id}/tasks/{task_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

for t in [T_6_1_14, T_6_1_68, T_6_2_1, T_6_2_2, T_6_2_36, T_6_3_12, T_6_3_4]:
    assign_task_to_delivery(DEL_DO_S7, t)
assign_task_to_delivery(DEL_DB_S7, T_6_3_3)
assign_task_to_delivery(DEL_QA_S7, T_6_4_13)
for t in [TL_S7_REV, AR_S7, CIERRE_S7, APR_S7, SETUP_S7]:
    assign_task_to_delivery(DEL_REV_S7, t)
print("Tareas asociadas ✅")
```

---

## 5. REGISTRAR DEPENDENCIAS

```python
def add_dep(task_id, depends_on_id):
    body = {"dependsOnTaskId": depends_on_id}
    req = urllib.request.Request(f'{BASE_URL}/api/tasks/{task_id}/dependencies',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

add_dep(SETUP_S7, CIERRE_S6)
add_dep(T_6_1_14, SETUP_S7)
add_dep(T_6_1_68, T_6_1_14)
add_dep(T_6_2_1, T_6_1_14)
add_dep(T_6_2_2, T_6_2_1)
add_dep(T_6_2_36, T_6_2_1)
add_dep(T_6_3_12, T_6_2_2)
add_dep(T_6_3_12, T_6_1_68)
add_dep(T_6_3_3, T_6_3_12)
add_dep(T_6_3_4, T_6_3_3)
add_dep(T_6_4_13, T_6_3_4)
add_dep(TL_S7_REV, T_6_4_13)
add_dep(TL_S7_REV, T_6_2_36)
add_dep(AR_S7, TL_S7_REV)
add_dep(CIERRE_S7, AR_S7)
add_dep(APR_S7, CIERRE_S7)
print("Dependencias S7 registradas ✅")
```

---

**FIN DEL SETUP S7**
