# SETUP: Sprint S8 — Deploy Prod + Operations Inicio

**Documento:** SETUP_S8.md
**Versión:** 1.0
**Sprint:** S8 — Deploy Producción + Operations Inicio
**Prerrequisito:** Sprint S7 completado (APR-S7 ✅)

---

## 0. RESUMEN EJECUTIVO

- ✅ Sprint S8 creado en VTT (último sprint de Release R1)
- ✅ 3 Deliveries creados y vinculados
- ✅ 12 tareas creadas y asociadas (7 deliverables agrupados + 1 TL + 4 validación/cierre)

**Último sprint.** Cierra Fase 6 + inicia Fase 7. Roles: DO + TL. 2 firmas (TL + AR).

---

## 1. CONSTANTES DE SESIÓN

```python
import urllib.request, json, time, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://77.42.88.106:3000"
PROJECT_ID = "d0fc276d-e764-4a83-96e9-d65f086ed803"
PHASE_DEPLOY = "________________________________"
PHASE_OPS    = "________________________________"  # Phase ID Fase 7 Operations

# Auth (same as previous sprints)
req = urllib.request.Request(
    f'{BASE_URL}/api/auth/service-token',
    data=json.dumps({
        'userId': '92225290-6b6b-4c1f-a940-dcb4262507aa',
        'serviceKey': 'hBCGEKm41BijI6jJ-s91KTMfv4pZ4a06d4a06d'
    }).encode(),
    headers={'Content-Type': 'application/json'}, method='POST')
TOKEN = json.loads(urllib.request.urlopen(req).read())['data']['token']
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

TL = "92225290-6b6b-4c1f-a940-dcb4262507aa"
DO = "322e3745-9756-4a7c-af11-44b33edef44d"
AR = "e9403c25-c1f8-4b64-b2ef-f447d53115e2"
PM_ID = "350831b2-e1ae-4dbe-b2eb-7e023ec2e103"

PRI_HIGH = "1a617554-6319-4c56-826f-8ef49a0ff9cc"
PRI_MED  = "d0b619ef-27e7-42d8-8879-41030a602eed"

RELEASE_ID = "________________________________"
CIERRE_S7  = "________________________________"
```

---

## 2. CREAR SPRINT + SETUP + DELIVERIES

```python
body = {
    "number": 8,
    "name": "S8 — Deploy Prod + Operations Inicio",
    "goal": "Producción live, monitoring activo, rollback probado, equipo en operations",
    "startDate": "2026-09-07T00:00:00Z",
    "endDate": "2026-09-20T00:00:00Z"
}
req = urllib.request.Request(f'{BASE_URL}/api/releases/{RELEASE_ID}/sprints',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SPRINT_S8_ID = json.loads(urllib.request.urlopen(req).read())['data']['id']

body = {"title": "SETUP-S8: Setup Sprint 8 — Deploy Prod + Ops", "assigneeId": TL,
    "estimatedHours": 1, "priorityId": PRI_MED, "complexity": "LOW", "category": "documentation",
    "description": "Configuración S8. Último sprint R1."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
SETUP_S8 = json.loads(urllib.request.urlopen(req).read())['data']['id']

def create_delivery(name, order, phase_id):
    body = {"phaseId": phase_id, "name": name, "order": order, "createdBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    return json.loads(urllib.request.urlopen(req).read())['data']['id']

DEL_DO_S8  = create_delivery("DO-S8: Prod Deploy + Monitoring + Rollback", 1, PHASE_DEPLOY)
DEL_TL_S8  = create_delivery("TL-S8: Ops Setup + Support + Release",      2, PHASE_OPS)
DEL_REV_S8 = create_delivery("REV-S8: Validación + Cierre",               3, PHASE_DEPLOY)

for d in [DEL_DO_S8, DEL_TL_S8, DEL_REV_S8]:
    body = {"sprintId": SPRINT_S8_ID}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{d}',
        data=json.dumps(body).encode(), headers=HEADERS, method='PATCH')
    urllib.request.urlopen(req)
    time.sleep(0.05)
```

**Registrar:**
```
SPRINT_S8_ID: ________________________________
SETUP_S8:     ________________________________
DEL_DO_S8:    ________________________________
DEL_TL_S8:    ________________________________
DEL_REV_S8:   ________________________________
```

---

## 3. CREAR TAREAS

```python
# DO tasks
tasks_do = [
    ("6.5.1-6", "Production Deploy + URL + DNS + SSL + Release Notes + Log", 13, "HIGH", "deployment"),
    ("6.6.1-2", "Monitoring Dashboard + Alerts", 8, "MEDIUM", "deployment"),
    ("6.6.6", "Post-Deploy Report 24h", 2, "LOW", "documentation"),
    ("6.7.1-5", "Rollback Plan + Scripts + Tested + Runbook + Criteria", 13, "HIGH", "deployment"),
]

do_ids = {}
for cat_id, name, hours, complexity, category in tasks_do:
    body = {"title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (IDs: {cat_id})\nSprint: S8\nRol: DO\nEstimación: {hours}h",
        "assigneeId": DO, "estimatedHours": hours,
        "priorityId": PRI_HIGH if complexity == "HIGH" else PRI_MED,
        "complexity": complexity, "category": category}
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    do_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {do_ids[cat_id]}")
    time.sleep(0.1)

T_6_5_16 = do_ids["6.5.1-6"]
T_6_6_12 = do_ids["6.6.1-2"]
T_6_6_6  = do_ids["6.6.6"]
T_6_7_15 = do_ids["6.7.1-5"]

# TL tasks (Ops)
tasks_tl = [
    ("7.1.1-4", "Uptime + Performance + Error + Weekly Reports", 12, "MEDIUM", "documentation"),
    ("7.2.1+3+4", "Support Process + SLA Definitions + Metrics", 7, "MEDIUM", "documentation"),
    ("7.3.1+3", "Hotfix Process + Bug Tracking", 4, "LOW", "documentation"),
]

tl_ids = {}
for cat_id, name, hours, complexity, category in tasks_tl:
    body = {"title": f"[{cat_id}] {name}",
        "description": f"Deliverable: {name} (IDs: {cat_id})\nSprint: S8\nRol: TL\nEstimación: {hours}h",
        "assigneeId": TL, "estimatedHours": hours,
        "priorityId": PRI_MED, "complexity": complexity, "category": category}
    req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_OPS}/tasks',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    tl_ids[cat_id] = json.loads(urllib.request.urlopen(req).read())['data']['id']
    print(f"T_{cat_id}: {tl_ids[cat_id]}")
    time.sleep(0.1)

T_7_1_14  = tl_ids["7.1.1-4"]
T_7_2_134 = tl_ids["7.2.1+3+4"]
T_7_3_13  = tl_ids["7.3.1+3"]

# Validation
body = {"title": "TL-S8-REV: Release Sign-off + Coordinación", "assigneeId": TL,
    "estimatedHours": 3, "priorityId": PRI_HIGH, "complexity": "MEDIUM", "category": "review",
    "description": "Release sign-off. Verificar producción live + monitoring + rollback."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
TL_S8_REV = json.loads(urllib.request.urlopen(req).read())['data']['id']
time.sleep(0.1)

body = {"title": "AR-S8: Integration Audit Sprint S8", "assigneeId": AR,
    "estimatedHours": 2, "priorityId": PRI_MED, "complexity": "MEDIUM", "category": "review",
    "description": "Auditar: prod vs staging, monitoring vs 3B.8.11, rollback plan vs 3B.8.8."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
AR_S8 = json.loads(urllib.request.urlopen(req).read())['data']['id']
time.sleep(0.1)

body = {"title": "CIERRE-S8: Cierre Sprint 8 — Release R1", "assigneeId": TL,
    "estimatedHours": 2, "priorityId": PRI_HIGH, "complexity": "MEDIUM", "category": "review",
    "description": "Cierre final R1. Firmas TL + AR. CLOSURE_S8.md."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
CIERRE_S8 = json.loads(urllib.request.urlopen(req).read())['data']['id']
time.sleep(0.1)

body = {"title": "APR-S8: Aprobación final Release R1", "assigneeId": PM_ID,
    "estimatedHours": 1, "priorityId": PRI_HIGH, "complexity": "LOW", "category": "review",
    "description": "Aprobación PM. Cierra Release R1 Memory Service."}
req = urllib.request.Request(f'{BASE_URL}/api/phases/{PHASE_DEPLOY}/tasks',
    data=json.dumps(body).encode(), headers=HEADERS, method='POST')
APR_S8 = json.loads(urllib.request.urlopen(req).read())['data']['id']
```

---

## 4. ASOCIAR + DEPENDENCIAS

```python
def assign_task_to_delivery(delivery_id, task_id):
    body = {"assignedBy": TL}
    req = urllib.request.Request(f'{BASE_URL}/api/deliveries/{delivery_id}/tasks/{task_id}',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

for t in [T_6_5_16, T_6_6_12, T_6_6_6, T_6_7_15]:
    assign_task_to_delivery(DEL_DO_S8, t)
for t in [T_7_1_14, T_7_2_134, T_7_3_13]:
    assign_task_to_delivery(DEL_TL_S8, t)
for t in [TL_S8_REV, AR_S8, CIERRE_S8, APR_S8, SETUP_S8]:
    assign_task_to_delivery(DEL_REV_S8, t)

def add_dep(task_id, depends_on_id):
    body = {"dependsOnTaskId": depends_on_id}
    req = urllib.request.Request(f'{BASE_URL}/api/tasks/{task_id}/dependencies',
        data=json.dumps(body).encode(), headers=HEADERS, method='POST')
    urllib.request.urlopen(req)
    time.sleep(0.05)

add_dep(SETUP_S8, CIERRE_S7)
add_dep(T_6_5_16, SETUP_S8)
add_dep(T_6_6_12, T_6_5_16)
add_dep(T_6_6_6, T_6_5_16)
add_dep(T_6_7_15, SETUP_S8)
add_dep(T_7_1_14, T_6_6_12)
add_dep(T_7_2_134, T_6_5_16)
add_dep(T_7_3_13, T_6_5_16)
add_dep(TL_S8_REV, T_6_5_16)
add_dep(TL_S8_REV, T_6_6_12)
add_dep(TL_S8_REV, T_6_7_15)
add_dep(TL_S8_REV, T_7_1_14)
add_dep(TL_S8_REV, T_7_2_134)
add_dep(TL_S8_REV, T_7_3_13)
add_dep(AR_S8, TL_S8_REV)
add_dep(CIERRE_S8, AR_S8)
add_dep(APR_S8, CIERRE_S8)
print("S8 configurado ✅")
```

---

**FIN DEL SETUP S8**
