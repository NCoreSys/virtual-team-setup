# ASSIGNMENT — MS-019: Non-Functional Requirements

| Campo | Valor |
|-------|-------|
| **Task ID** | MS-019 |
| **Título** | Non-Functional Requirements |
| **Asignado a** | AR — `ar@memory-service.vtt.ai` / `e9403c25-c1f8-4b64-b2ef-f447d53115e2` |
| **Fase** | Analysis (Phase 4) |
| **Prioridad** | MEDIUM |
| **Complejidad** | HIGH |
| **Horas estimadas** | 4h |
| **Fecha asignación** | 2026-05-05 |
| **Asignado por** | SA Reviewer |

---

## Contexto

MS-018 (Functional Requirements) está completado. La fase Analysis continúa con MS-019 asignado al AR — el rol natural para esta tarea porque los NFRs del Memory Service son directamente derivados de las decisiones de arquitectura que el AR ya tomó (AR-OBS-01..02, Q-01..Q-05) y de los riesgos técnicos identificados en su review del SPEC.

MS-019 puede ejecutarse en paralelo con MS-020 (Use Cases, SA). El AR DEBE completar esta tarea antes de que MS-024 (Acceptance Criteria) pueda cerrarse.

---

## Qué producir

6 documentos en `phases/02-analysis/deliverables/non-functional-requirements/`:

| Doc | Nombre | Descripción |
|-----|--------|-------------|
| `2.2.1_nfr_document.md` | NFR Document | Marco general: categorías, numeración NFR-XXX, metodología de medición |
| `2.2.2_performance_requirements.md` | Performance Requirements | SLA <500ms p95 GET /context + benchmarks k6 + otros endpoints |
| `2.2.3_security_requirements.md` | Security Requirements | SERVICE_KEY, OWASP Top 10, Zod validation, headers, LIM-05 |
| `2.2.4_scalability_requirements.md` | Scalability Requirements | Rate limiting Redis, connection_limit=20, límites R1, scale-out |
| `2.2.5_availability_requirements.md` | Availability Requirements | Uptime 99%, RTO/RPO single-node, backup storage |
| `2.2.6_usability_requirements.md` | Usability Requirements | Desktop-only, carga <2s, accesibilidad básica |

---

## NFRs críticos que DEBEN quedar documentados

### NFR-PERF-01 — GET /context SLA contractual (MUST)

Este es el NFR más crítico del sistema. El AR debe documentarlo explícitamente en 2.2.2:

- **Métrica:** p95 < 500ms bajo carga normal (10 usuarios concurrentes, 60s)
- **Comportamiento al fallar:** retorna `504 MEM-ERR-504` — fail-fast, NO modo degradado (D-MEM-07 + D-MEM-37)
- **Prioridad:** Must — es SLA contractual con Prompt Builder v1.3 (PB espera síncronamente)
- **Estrategias de soporte:** catalog cache en startup (DEC-01 TL), partial indexes + GIN, connection pool 20

### NFR-SEC-01 — SERVICE_KEY autenticación (MUST)

Documentar en 2.2.3 qué endpoints requieren SERVICE_KEY y cuáles son públicos R1:

| Auth | Endpoints |
|------|-----------|
| SERVICE_KEY Bearer | POST /import, POST /import-review, GET /context |
| Público R1 | POST /upload, GET /conversations, GET /conversations/:id/content, GET /agents/:id/timeline, GET /projects/:id/cost-report, GET /agents/:id/cost-report, GET /dashboard/stats, GET /health |

### NFR-AVAIL-01 — Single-node constraint (MUST documentar limitación)

El servidor Hetzner `77.42.88.106` es un nodo único. No hay HA automático en R1. El AR debe documentar:
- Uptime objetivo: 99% (no 99.9% — single node sin cluster)
- RTO estimado: ~30min (restart manual Hetzner)
- RPO: depende de frecuencia de backups DO (coordinar con DO)
- Plan R2: HA con segundo nodo o failover automático

---

## Ambigüedades abiertas que el AR debe resolver en esta tarea

**AMB-NFR-01 — Rate limit por SERVICE_KEY vs por IP:**
D-MEM-22 dice "rate limit via Redis" pero no especifica si es por IP, por SERVICE_KEY, o por endpoint. El AR debe tomar esta decisión y documentarla en 2.2.4. Opciones:
- Opción A: Por SERVICE_KEY (más granular para control por consumidor)
- Opción B: Por IP (más simple, no distingue consumidores)
- Opciones C: Por endpoint + SERVICE_KEY (más fino, más complejo)

**AMB-NFR-02 — Uptime SLA exacto para R1:**
No está definido en SPEC v1.9. El AR debe proponer el % de uptime adecuado considerando que es single-node Hetzner. Debe documentarse como target interno (no SLA hacia usuario externo, ya que es herramienta interna).

---

## Referencias obligatorias

| Documento | Ruta | Qué extraer |
|-----------|------|-------------|
| **SPEC v1.9** ⭐ | `Release2.0/01-PM/SPEC_MEMORY_SERVICE_v1.9_CONSOLIDADO.md` | D-MEM-01..43 decisiones congeladas, §8 contratos API, §16 Docker/infra |
| **AR Review propio** | `Release2.0/02-AR/AR_REVIEW_SPEC_MEMORY_SERVICE_v1.md` | Q-01..Q-05 preguntas resueltas, AR-OBS-01..02 — coherencia con decisiones propias |
| **TL Review** | `Release2.0/04-TL/TL_REVIEW_SPEC_MEMORY_SERVICE_v1.md` | AMB-01..07, DEC-01..05, TL-01..09 riesgos para <500ms, catalog cache startup |
| **ADDENDUM Integración** | `Release2.0/01-PM/ADDENDUM_INTEGRACION_MEMORY_SERVICE_v1.1.md` | D-INT-01..05, SLAs cross-service con Runtime v1.1 y Prompt Builder v1.3 |
| **CIERRE PM** | `Release2.0/01-PM/CIERRE_PM_HANDOFF_PJM_MEMORY_SERVICE_R1.md` | R1-R12 riesgos, LIM-01..10 limitaciones documentadas |
| **HO Fase 2** | `Release2.0/PJM/HO_FASE_2_ANALYSIS_MEMORY_SERVICE.md` | Descripción entregables 2.2.1..2.2.6, criterios de aceptación de la fase |

---

## Workflow

1. Mover MS-019 a `task_in_progress`
2. Leer referencias (mínimo SPEC v1.9 + AR Review propio + TL Review + ADDENDUM)
3. Resolver AMB-NFR-01 y AMB-NFR-02 antes de escribir
4. Producir los 6 documentos en `phases/02-analysis/deliverables/non-functional-requirements/`
5. Crear devlog en `knowledge/development-log/2026-05-05_MS-019_non-functional-requirements.md`
6. Crear code logic en `knowledge/code-logic/MS-019_NON_FUNCTIONAL_REQUIREMENTS.LOGIC.md`
7. Mover a `task_in_review` cuando estén los 6 docs
8. Notificar al SA Reviewer para revisión

---

## Criterios de aceptación

- [ ] 6 archivos creados en `phases/02-analysis/deliverables/non-functional-requirements/`
- [ ] 2.2.2 especifica `<500ms p95` para GET /context con condición k6 y resultado de fallo (MEM-ERR-504)
- [ ] 2.2.2 documenta el comportamiento fail-fast explícitamente (no modo degradado, no retry)
- [ ] 2.2.3 tabla completa de auth por endpoint (SERVICE_KEY vs público)
- [ ] 2.2.4 resuelve AMB-NFR-01 con decisión documentada sobre rate limit
- [ ] 2.2.5 especifica uptime objetivo R1, RTO estimado, y limitación single-node documentada
- [ ] 2.2.5 resuelve AMB-NFR-02 con % de uptime propuesto
- [ ] 2.2.6 especifica "desktop only" como constraint R1 con referencia a LIM-08
- [ ] Todos los NFRs tienen ID, métrica cuantitativa, método de verificación y prioridad MoSCoW
- [ ] Ningún NFR contradice D-MEM-01..43 ni D-INT-01..05

---

**Documento:** ASSIGNMENT_MS-019_non-functional-requirements.md
**Versión:** 1.0
**Generado por:** SA Reviewer — 2026-05-05
