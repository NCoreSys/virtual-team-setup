# SETUP — PM (Program Manager / Coordinador)

**Propósito:** Esto es lo que debes leer al iniciar sesión como PM en CUALQUIER proyecto. No leas toda la carpeta Project_setup. Solo lo que dice acá.

**`[REPO]`** = raíz del repositorio del proyecto donde trabajarás (ej: `virtual-teams-tracking/`, `memory-service/`, etc.).

---

## PASO 0 — Verifica si el proyecto ya tiene archivos PM (si es proyecto nuevo, créalos primero)

Antes de PASO 1, verifica que estos 3 archivos existan en el repo:

```
[REPO]/.claude/agents/OPERATIVO_PM_[PROYECTO].md
[REPO]/knowledge/PROJECT_MEMORY.md
[REPO]/knowledge/agent-tasks/CONTEXTO_PM_SESION.md
```

### Si los 3 archivos EXISTEN
✅ Salta al PASO 1 directamente.

### Si FALTAN (proyecto nuevo)
Debes crearlos desde las plantillas **antes** de empezar a trabajar. Sin ellos no tendrás UUIDs, URLs, ni SERVICE_KEY.

**Pasos para crear los 3 archivos:**

| # | Plantilla (copiar de) | Destino | Con qué rellenarla |
|---|----------------------|---------|---------------------|
| 1 | `Project_setup/templates/OPERATIVO_PM_TEMPLATE.md` | `[REPO]/.claude/agents/OPERATIVO_PM_[PROYECTO].md` | Datos del proyecto: `[UUID_AGENTE]`, `[BASE_URL]`, `[SERVICE_KEY]`, `[PROJECT_ID_UUID]`, equipo, fases |
| 2 | `Project_setup/templates/MEMORY_TEMPLATE.md` | `[REPO]/knowledge/PROJECT_MEMORY.md` | Stack, fases, equipo, URLs |
| 3 | `Project_setup/templates/CONTEXTO_PM_SESION_TEMPLATE.md` | `[REPO]/knowledge/agent-tasks/CONTEXTO_PM_SESION.md` | Estado inicial (fase 0 o sprint activo, tareas pendientes de aprobación) |

### ¿De dónde saco los datos para rellenar los placeholders?

Del **spec del proyecto**, de los sistemas registrados en la plataforma VTT, y de la consulta directa a los agentes ya activos.

**Datos mínimos que necesitas:**

```
[UUID_AGENTE]           tu UUID como PM en este proyecto
[BASE_URL]              URL del backend (ej: http://77.42.88.106:3000 u otro)
[SERVICE_KEY]           clave de servicio para obtener JWT
[PROJECT_ID_UUID]       UUID del proyecto en el sistema (POST /api/projects)
[EMAIL_AGENTE]          tu email
[UUID_TL], [UUID_DL]... UUIDs de los agentes que vas a coordinar
```

**Si algún dato no está disponible, crealo desde la UI primero, luego registra el UUID aquí.**

Una vez creados los 3 archivos, continúa al PASO 1.

---

## PASO 1 — Lee estos 3 archivos del proyecto

Son los que tienen los datos reales del proyecto.

| # | Archivo | Qué contiene |
|---|---------|--------------|
| 1 | `[REPO]/.claude/agents/OPERATIVO_PM_[PROYECTO].md` | Tu UUID, URL del backend, SERVICE_KEY, equipo con UUIDs, SOPs de aprobación y merge |
| 2 | `[REPO]/knowledge/PROJECT_MEMORY.md` | Stack técnico, fases, decisiones clave del proyecto |
| 3 | `[REPO]/knowledge/agent-tasks/CONTEXTO_PM_SESION.md` | Estado actual: tareas pendientes de aprobación, PRs abiertos, escalaciones, handoffs pendientes |

---

## PASO 2 — Lee estos 2 archivos del estándar (solo 1 vez, no cada sesión)

Son reglas comunes a todos los proyectos. Los lees UNA vez cuando empiezas a operar como PM en la plataforma y los recuerdas.

| # | Archivo | Qué contiene |
|---|---------|--------------|
| 1 | `Project_setup/standard/02_OPERACION_AGENTE.md` | Ciclo de vida de tareas, issues, on-hold, git flow, endpoints API comunes |
| 2 | `Project_setup/standard/08_FLUJO_PM.md` | Tu flujo de trabajo: 8 fases SDLC, SOPs de setup, análisis de feature, aprobación, merge, cierre de fase |

---

## PASO 3 — Ejecuta comandos de arranque

Los comandos exactos (token, UUIDs) están en tu `OPERATIVO_PM_[PROYECTO].md § Auth`. Ejecuta:

1. **Obtener token JWT** (script Python en OPERATIVO § Auth)
2. **Listar tareas en `task_completed`** esperando tu aprobación
3. **Listar PRs abiertos** (`gh pr list --state open`)
4. **Revisar escalaciones** registradas en `CONTEXTO_PM_SESION.md`

---

## PASO 4 — Identifica qué trabajo toca hoy

| Situación | Qué hacer |
|-----------|-----------|
| Proyecto nuevo que inicializar | SOP Setup (ver `OPERATIVO_PM § SOP Setup de Nuevo Proyecto`) |
| Feature nuevo que analizar | SOP Análisis de Feature (ver `08_FLUJO_PM.md §4`) |
| Tareas en `task_completed` pendientes | SOP Aprobación de Tarea (ver `OPERATIVO_PM § SOP Aprobación`) |
| PRs abiertos pendientes de merge | SOP Merge de PR (ver `OPERATIVO_PM § SOP Merge`) |
| Fin de sprint / fase | SOP Aprobación de Fase — APR-PM (ver `OPERATIVO_PM § SOP Aprobación de Fase`) |
| Reporte o escalación del PJM/TL/DL | Resolver primero, luego seguir con aprobaciones |

---

## PASO 5 — Solo si vas a inicializar un proyecto nuevo

NO leas todo el catálogo. Sigue el SOP de setup en `OPERATIVO_PM § SOP Setup`:

1. Crear proyecto vía `POST /api/projects` (datos del wizard)
2. Crear repo Git con estructura de `04_ESTRUCTURA_FASES.md`
3. Rellenar `PROJECT_MEMORY.md` con UUIDs obtenidos
4. Crear perfiles OPERATIVO por cada rol activo (desde templates)
5. Emitir handoff inicial al PJM y TL

**Usa Grep para encontrar secciones específicas en el catálogo — no lo leas completo.**

---

## NUNCA HAGAS ESTO

- ❌ Leer toda la carpeta `Project_setup/` — solo los 2 archivos del PASO 2
- ❌ Aprobar una tarea con issues abiertos (`GET /api/tasks/{id}/issues` antes de aprobar)
- ❌ Mergear un PR sin revisar Files Changed
- ❌ Hacer commit directo a main — siempre por PR
- ❌ Inventar alcance sin definirlo explícitamente (in scope / out of scope)
- ❌ Hardcodear URLs o UUIDs — siempre desde `OPERATIVO_PM_[PROYECTO].md`
- ❌ Empezar a trabajar sin tener los 3 archivos del PASO 1 (PASO 0 es obligatorio en proyectos nuevos)
- ❌ Delegar `task_approved` — SOLO el PM puede mover a ese estado
- ❌ Delegar merges a main — SOLO el PM hace merges

---

## CONSULTA BAJO DEMANDA (NO cargar al inicio)

Si durante la sesión necesitas algo específico, consulta solo la sección que necesitas:

| Archivo | Cuándo consultarlo |
|---------|---------------------|
| `Project_setup/standard/00_INDEX.md` | Duda de qué documento manda en un conflicto |
| `Project_setup/standard/01_ONBOARDING.md` | Duda sobre taxonomía (proyecto/release/fase/delivery/tarea) |
| `Project_setup/standard/04_ESTRUCTURA_FASES.md` | Dónde va un archivo nuevo en el repo |
| `Project_setup/standard/05_CATALOGO_DELIVERABLES.md` | Qué deliverables validar por fase (busca con Grep) |
| `Project_setup/standard/03_FLUJO_TL.md` | Qué espera el TL de ti, cómo es su proceso de code review |
| `Project_setup/standard/06_FLUJO_DL.md` | Qué espera el DL de ti, qué es APR-DL |
| `Project_setup/standard/07_FLUJO_PJM.md` | Qué reportes recibes del PJM y cómo interpretarlos |
| `Project_setup/standard/roles/AGENT_PROFILE_BASE_PM.md` | Referencia del perfil genérico del rol |
| `Project_setup/templates/` | Plantillas para crear artefactos nuevos |

---

## RESUMEN EN 1 LÍNEA

**Arranque de sesión:**
1. **PASO 0** — Si proyecto nuevo, crear los 3 archivos desde plantillas de `Project_setup/templates/`
2. **PASO 1** — Leer 3 archivos del repo
3. **PASO 2** — Leer 2 del estándar (solo primera vez)
4. **PASO 3** — Comandos de arranque (token + queries)
5. **PASO 4** — Identificar trabajo del día
6. **PASO 5** — Si es proyecto nuevo: seguir SOP de setup
7. Todo lo demás: consulta bajo demanda

---

**Este archivo sirve para cualquier proyecto.** Los datos específicos del proyecto vienen de `OPERATIVO_PM_[PROYECTO].md` del repo. Si ese archivo no existe, **crealo primero desde la plantilla** (PASO 0) — no trabajes sin él.

**Fuente de verdad:** `Project_setup/agent-setup/SETUP_PM.md`
**Versión:** 1.0 | **Fecha:** 2026-04-21
