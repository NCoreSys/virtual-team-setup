# SETUP — Solution Analyst Ejecutor (SA)

**Propósito:** Lo que debes leer al iniciar sesión como SA ejecutor en CUALQUIER proyecto.

**`[REPO]`** = raíz del repositorio del proyecto donde trabajarás.

---

## PASO 0 — Verifica que existan los archivos del SA

Antes de empezar, verifica que estos 3 archivos existan:

```
[REPO]/.claude/agents/OPERATIVO_SA_MEMORY-SERVICE.md
[REPO]/knowledge/PROJECT_MEMORY.md
[REPO]/knowledge/agent-tasks/CONTEXTO_SA_EJECUTOR_SESION.md
```

Si faltan → pedirlos al PM antes de operar.

---

## PASO 1 — Lee estos 3 archivos del proyecto

| # | Archivo | Qué contiene |
|---|---------|--------------|
| 1 | `[REPO]/.claude/agents/OPERATIVO_SA_MEMORY-SERVICE.md` | Tu UUID, SERVICE_KEY, flujo completo de ejecución |
| 2 | `[REPO]/knowledge/PROJECT_MEMORY.md` | Stack, fases, decisiones D-MEM-XX cerradas |
| 3 | `[REPO]/knowledge/agent-tasks/CONTEXTO_SA_EJECUTOR_SESION.md` | Fase activa, estado del proyecto |

---

## PASO 2 — Lee estos 2 archivos del estándar (solo 1 vez)

| # | Archivo | Qué contiene |
|---|---------|--------------|
| 1 | `00-agent-setup/03.standard/02_OPERACION_AGENTE.md` | Ciclo de vida de tareas, git flow, endpoints comunes |
| 2 | `00-agent-setup/03.standard/11_GUIA_AGENTES_MODELO_DINAMICO_V4.md` | API VTT completa — endpoints, catálogos, devlog gate |

---

## PASO 3 — Ejecuta comandos de arranque

1. Obtener token JWT (script en OPERATIVO § Auth)
2. Consultar tus tareas asignadas en VTT
3. Identificar qué tarea ejecutar (pending o in_progress)
4. Leer el ASSIGNMENT de la tarea desde sus attachments en VTT

---

## PASO 4 — Ejecuta la tarea

Seguir el flujo de 9 pasos del OPERATIVO § 7:

| Situación | Qué hacer |
|-----------|-----------|
| Tarea en task_pending asignada a mí | Leer ASSIGNMENT → mover a in_progress → ejecutar |
| Tarea en task_in_progress | Continuar desde donde quedó |
| Sin tareas asignadas | Reportar al PM |
| Blocker durante ejecución | Mover a task_on_hold → notificar al PM |

---

## NUNCA HAGAS ESTO

- ❌ Empezar sin leer el ASSIGNMENT completo
- ❌ Inventar contenido que no esté respaldado por SPEC v1.9 o KICKOFF
- ❌ Entregar con TODOs, placeholders o secciones vacías
- ❌ Mover a task_completed (eso es del SA Reviewer)
- ❌ Auto-revisarte

---

**Fuente de verdad:** `00-agent-setup/01.agent-setup/SETUP_SA.md`
**Versión:** 1.0 | **Fecha:** 2026-05-05
