# ASSIGNMENT — MS-023: User Flows

| Campo | Valor |
|-------|-------|
| **Task ID** | MS-023 |
| **Título** | User Flows |
| **Asignado a** | UX — `ux@memory-service.vtt.ai` / `a75a1dae-754a-4b6f-a3ff-db8d51f6a91b` |
| **Fase** | Analysis (Phase 4) |
| **Prioridad** | MEDIUM |
| **Complejidad** | MEDIUM |
| **Horas estimadas** | 4h |
| **Fecha asignación** | 2026-05-05 |
| **Asignado por** | SA Reviewer |

---

## Contexto

MS-020 (Use Cases) está completado. MS-023 puede ejecutarse en paralelo con MS-021 y MS-022. El UX diseña los flujos de usuario de la interfaz standalone Memory Service UI (puerto 3003, desktop-only per LIM-08). Este output es input directo para el DL en Fase 3A (wireframes y diseño de pantallas).

---

## Qué producir

7 documentos en `phases/02-analysis/deliverables/user-flows/`:

| Doc | Nombre | Descripción |
|-----|--------|-------------|
| `2.6.1_user_flow_diagrams.md` | User Flow Diagrams | Diagramas Mermaid por pantalla UI |
| `2.6.2_happy_path_flows.md` | Happy Path Flows | Flujos sin errores por caso de uso |
| `2.6.3_error_flows.md` | Error Flows | Qué ve el usuario ante errores |
| `2.6.4_edge_case_flows.md` | Edge Case Flows | Lista vacía, sin costo, storage falla |
| `2.6.5_user_journey_maps.md` | User Journey Maps | Journey completo TL y PM |
| `2.6.6_task_flows.md` | Task Flows | Flujos por tarea concreta de usuario |
| `2.6.7_navigation_map.md` | Navigation Map | Mapa de navegación entre pantallas |

---

## Las 8 pantallas de la UI R1

El UX debe diseñar flujos para estas pantallas:

| Pantalla | Endpoint principal | Actor principal |
|----------|-------------------|-----------------|
| Dashboard | GET /dashboard/stats | TL, PM |
| Conversations List | GET /conversations | TL |
| Conversation Viewer | GET /conversations/:id/content | TL |
| Agent Timeline | GET /agents/:id/timeline | TL |
| Project Cost Report | GET /projects/:id/cost-report | PM |
| Agent Cost Report | GET /agents/:id/cost-report | PM |
| Manual Upload | POST /upload | Cualquier rol |
| Health Status | GET /health | Admin / DO |

---

## Ambigüedades que el UX DEBE resolver en los User Flows

**AMB-UX-01 — Comportamiento de import asíncrono en UI:**
POST /upload crea la conversación y comienza el procesamiento. Si hay error interno durante el procesamiento, el estado queda en PROCESSING (no ERROR inmediato — AMB-07). El UX debe definir:
- ¿Qué ve el usuario mientras la conversación está en PROCESSING?
- ¿La UI hace polling del estado? ¿Cada cuánto?
- ¿Cuándo muestra el estado final (IMPORTED o ERROR)?
- Decisión recomendada: mostrar estado "Procesando..." con refresh manual o auto-poll cada 30s

**AMB-UX-02 — Visualización de ALREADY_INDEXED desde Upload:**
Si el usuario sube el mismo archivo dos veces, el sistema retorna `{ status: ALREADY_INDEXED }`. El UX debe decidir:
- ¿Se muestra como error (rojo) o como info (azul)?
- ¿Se redirige al Conversation Viewer de la conversación existente?
- Decisión recomendada: mostrar como info ("Esta conversación ya fue importada") con link a la existente

**AMB-UX-03 — Health parcial: un componente falla:**
GET /health puede retornar: `{ status: "degraded", db: "up", storage: "up", redis: "down" }`. El UX debe definir:
- ¿Cómo se visualiza el estado parcial? (semáforos por componente)
- ¿Qué acciones puede hacer el admin desde esta pantalla?

**AMB-UX-04 (TL §2.9) — Definición de "agente activo" en Dashboard:**
El stat `activeAgents` del dashboard necesita una ventana temporal definida. La definición debe ser consistente con lo que el SA decida en MS-021 (US-026) y MS-022 (AMB-BR-03). El UX debe mostrar esta ventana en la UI (ej: "Agentes activos (últimos 7 días)") y coordinar con el SA.

---

## Flujos obligatorios en 2.6.2 (Happy Path)

### FP-01: Ver timeline de agente
```
Dashboard → [Search/Select agente] → Agent Timeline →
  → Lista cronológica de sesiones →
  → Click sesión → Conversation Viewer →
  → Visualiza JSONL completo (cargado desde /storage/)
```

### FP-02: Importar conversación manual
```
[Nav] → Manual Upload →
  → Seleccionar archivo JSONL →
  → Completar: agentId, projectId, taskId, sourceCode →
  → POST /upload →
  → Estado: "Importando..." →
  → { status: IMPORTED } → Redirect a Conversation Viewer
```

### FP-03: Ver Cost Report de proyecto
```
Dashboard o nav → Project Cost Report →
  → Seleccionar projectId →
  → GET /projects/:id/cost-report →
  → Tabla: agente | inputTokens | outputTokens | costUSD →
  → Filtro groupBy: semana/mes →
  → Total project cost en header
```

### FP-04: Verificar Health
```
[Nav admin] → Health Status →
  → GET /health →
  → Estado: OK / DEGRADED / DOWN →
  → Detalle: bd=UP, storage=UP, redis=UP
```

---

## Flujos de error obligatorios en 2.6.3

| Error | Trigger | Qué ve el usuario |
|-------|---------|-------------------|
| Import error | POST /upload → catch → PROCESSING | Spinner + "En proceso. El sistema reintentará automáticamente." |
| Storage falla | GET /content → /storage/ no encontrado | "No se pudo cargar el contenido. Contacta al administrador." |
| Health degradado | GET /health → componente DOWN | Semáforo rojo en componente afectado + descripción del fallo |
| Lista vacía | GET /conversations → 0 resultados | Empty state: "No hay conversaciones que coincidan con los filtros" |
| Context timeout | (interno, no expuesto en UI) | N/A — solo visible en logs |

---

## Edge cases obligatorios en 2.6.4

1. Lista de conversaciones con 0 resultados (filtro muy restrictivo)
2. Agente sin conversaciones CLAUDE_SDK (cost report = $0.00 total)
3. Archivo JSONL en /storage/ corrompido o no encontrado
4. Dashboard con 0 conversaciones (primera ejecución del sistema)
5. Upload de archivo duplicado → ALREADY_INDEXED

---

## Referencias obligatorias

| Documento | Ruta | Qué extraer |
|-----------|------|-------------|
| **SPEC v1.9** ⭐ | `Release2.0/01-PM/SPEC_MEMORY_SERVICE_v1.9_CONSOLIDADO.md` | §8 contratos API: responses por endpoint, estructuras de datos |
| **MS-020 Use Cases** ⭐ | `docs/analysis/use-cases/` | UC-007 (upload), UC-008 (content), UC-011 (timeline), UC-015 (dashboard) |
| **MS-018 FR** | `docs/analysis/functional-requirements/` | Features exactas R1 |
| **CIERRE PM** | `Release2.0/01-PM/CIERRE_PM_HANDOFF_PJM_MEMORY_SERVICE_R1.md` | LIM-08 (desktop only), UI-01..04 sprints |
| **HO Fase 2** | `Release2.0/PJM/HO_FASE_2_ANALYSIS_MEMORY_SERVICE.md` | Criterios 2.6.1..2.6.7 |

---

## Workflow

1. Mover MS-023 a `task_in_progress`
2. Leer SPEC v1.9 §8 + MS-020 Use Cases + MS-018 FR
3. Resolver AMB-UX-01..04 antes de escribir diagramas
4. Producir los 7 documentos en `phases/02-analysis/deliverables/user-flows/`
5. Crear devlog en `knowledge/development-log/2026-05-05_MS-023_user-flows.md`
6. Crear code logic en `knowledge/code-logic/MS-023_USER_FLOWS.LOGIC.md`
7. Mover a `task_in_review`
8. Notificar al SA Reviewer para revisión

---

## Criterios de aceptación

- [ ] 7 archivos creados en `phases/02-analysis/deliverables/user-flows/`
- [ ] 2.6.1 incluye diagramas Mermaid para las 8 pantallas UI
- [ ] 2.6.2 documenta FP-01..FP-04 (timeline, upload, cost report, health)
- [ ] 2.6.3 documenta mínimo 4 flujos de error con mensaje de UI para el usuario
- [ ] 2.6.4 documenta mínimo 5 edge cases incluyendo ALREADY_INDEXED y lista vacía
- [ ] 2.6.5 incluye journey completo del TL y del PM (inicio a fin)
- [ ] 2.6.7 mapa de navegación completo con rutas entre todas las pantallas
- [ ] AMB-UX-01 resuelta: comportamiento de UI con PROCESSING definido (polling, mensaje)
- [ ] AMB-UX-02 resuelta: ALREADY_INDEXED mostrado como info con link a conversación existente o equivalente
- [ ] AMB-UX-03 resuelta: health parcial visualizado con semáforos por componente
- [ ] AMB-UX-04 coordinado con SA: ventana temporal de "agente activo" visible en UI
- [ ] Flujos son consistentes con los Use Cases de MS-020 y las User Stories de MS-021
- [ ] Ningún flujo asume features fuera del scope R1 (LIM-08: desktop only)

---

**Documento:** ASSIGNMENT_MS-023_user-flows.md
**Versión:** 1.0
**Generado por:** SA Reviewer — 2026-05-05
